#!/usr/bin/env python3
"""
Fallback on Error - Fallback on error.
"""

import json
import datetime
import fcntl
from pathlib import Path


ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
FALLBACK_FILE = Path("/root/.hermes/state/fallback_on_error.json")
LOG_FILE = Path("/root/.hermes/logs/fallback_on_error.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_errors():
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            return fh.readlines()
    except Exception:
        return []


def should_fallback(line):
    """Determine if this error should trigger fallback."""
    fallback_triggers = [
        "connection refused",
        "timeout",
        "unavailable",
        "500",
        "502",
        "503",
        "504",
    ]
    lower = line.lower()
    return any(t in lower for t in fallback_triggers)


def main():
    log("=== Fallback on Error started ===")

    errors = read_errors()
    fallback_count = 0

    for line in errors[-50:]:
        if should_fallback(line):
            fallback_count += 1

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_errors": len(errors),
        "fallback_triggers": fallback_count,
        "fallback_recommended": fallback_count >= 3,
    }

    FALLBACK_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(FALLBACK_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    if fallback_count >= 3:
        log(f"ALERT: {fallback_count} fallback triggers detected")

    log(f"=== Fallback on Error: {fallback_count} triggers ===")


if __name__ == "__main__":
    main()
