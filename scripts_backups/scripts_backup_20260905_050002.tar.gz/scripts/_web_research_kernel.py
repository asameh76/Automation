#!/usr/bin/env python3
"""KB Web Research via hermes_tools kernel microservice."""
import json, sys, os

KERNEL_PY = "/root/hermes-bot-v2/venv/bin/python"
KERNEL_SCRIPT = "/root/.hermes/scripts/_kernel_research.py"

def run_in_kernel(query):
    """Run research via execute_code kernel."""
    script = f"""
import json
from hermes_tools import web_search, web_extract
import re

def extract_commands(content):
    commands = []
    for cmd in re.findall(r'`([^`\\n]{{5,150}})`', content):
        if any(x in cmd for x in ["sudo ","systemctl","docker ","nginx ","redis","psql","chmod ","apt ","yum ","pip ","service ","kill ","pkill"]):
            commands.append(cmd.strip()[:120])
    return list(dict.fromkeys(commands))[:8]

SOURCES = {{
    "stackoverflow": "site:stackoverflow.com {{q}}",
    "serverfault": "site:serverfault.com {{q}}",
    "digitalocean": "site:digitalocean.com/community {{q}}",
    "github": "site:github.com {{q}} error fix",
    "reddit": "site:reddit.com/r/sysadmin {{q}}",
}}

results = {{}}
for src, tmpl in SOURCES.items():
    try:
        r = web_search(tmpl.format(q="{query}"), limit=3)
        items = r.get('data',{{}}).get('web',[])
        if items:
            results[src] = items
    except Exception:
        pass

commands = []
solution = ""
for src in ['stackoverflow','serverfault','digitalocean']:
    if src in results and results[src]:
        try:
            url = results[src][0]['url']
            r = web_extract([url], char_limit=6000)
            content = r['results'][0]['content']
            commands.extend(extract_commands(content))
            paras = [p.strip() for p in content.split('\\n') if len(p.strip()) > 60]
            if not solution and paras:
                solution = paras[0][:200]
        except Exception:
            pass

seen = set()
unique = []
for c in commands:
    if c[:50] not in seen:
        seen.add(c[:50])
        unique.append(c)

print(json.dumps({{
    "sources": list(results.keys()),
    "count": sum(len(v) for v in results.values()),
    "commands": unique[:8],
    "solution": solution
}}))
"""
    # Write script to temp file
    with open(KERNEL_SCRIPT, "w") as f:
        f.write(script)

    # Run via kernel python
    result = os.popen(f"{KERNEL_PY} {KERNEL_SCRIPT} 2>/dev/null").read()

    # Clean up
    os.remove(KERNEL_SCRIPT)

    try:
        return json.loads(result)
    except Exception:
        return {"sources": [], "count": 0, "commands": [], "solution": ""}

if __name__ == "__main__":
    query = sys.argv[1] if len(sys.argv) > 1 else "error"
    result = run_in_kernel(query)
    print(json.dumps(result, indent=2))
