#!/usr/bin/env python3
"""
KB Code Introspect - Code introspection.
"""

import json
import os
import subprocess
import datetime
from pathlib import Path


SCRIPTS_DIR = Path("/root/.hermes/scripts")
INTROSPECT_FILE = Path("/root/.hermes/state/kb_code_introspect.json")
LOG_FILE = Path("/root/.hermes/logs/kb_code_introspect.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def introspect_script(path):
    """Introspect a single script."""
    try:
        result = subprocess.run(
            ["python3", "-m", "py_compile", str(path)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return {
            "name": path.name,
            "valid": result.returncode == 0,
            "size": path.stat().st_size,
        }
    except Exception as e:
        return {
            "name": path.name,
            "valid": False,
            "error": str(e),
        }


def main():
    log("=== KB Code Introspect started ===")

    scripts = []
    for f in SCRIPTS_DIR.glob("kb_*.py"):
        scripts.append(introspect_script(f))

    for f in SCRIPTS_DIR.glob("fallback*.py"):
        scripts.append(introspect_script(f))

    valid = sum(1 for s in scripts if s.get("valid"))
    invalid = sum(1 for s in scripts if not s.get("valid"))

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total": len(scripts),
        "valid": valid,
        "invalid": invalid,
        "scripts": scripts,
    }

    INTROSPECT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(INTROSPECT_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Code Introspect: {valid}/{len(scripts)} valid ===")


if __name__ == "__main__":
    main()
