#!/usr/bin/env python3
"""
System Empowerment Report — What the system can do, what it monitors,
what it fixes automatically, and what's still manual.
Run weekly or on-demand. Delivers a human-readable capability summary.
"""
import json, subprocess, os, sys
from pathlib import Path
from datetime import datetime

HERMES    = Path("/root/.hermes")
KB_FILE   = HERMES / "error-knowledge-base.json"
STATE_DIR = HERMES / "state"
OUT_FILE  = STATE_DIR / "empowerment_report.json"
LOG_FILE  = HERMES / "logs/empowerment_report.log"

def log(msg):
    print(f"[EMPOWER {datetime.now().strftime('%H:%M:%S')}] {msg}")

def run(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return r.stdout.strip()

def load_json(path):
    try:
        return json.load(open(path))
    except:
        return {}

def kb_stats():
    kb = load_json(KB_FILE)
    errors = kb.get("errors", [])
    v_types = ['verified','manual_verified','canary_verified','cross_verified','self_healed']
    total   = len(errors)
    verified = sum(1 for e in errors if e.get("verified") in v_types)
    health  = round(verified * 100 / max(total, 1), 1)
    return total, verified, health

def cron_jobs_summary():
    jobs_data = load_json(STATE_DIR / "cron_state.json")
    if not jobs_data:
        return "?"
    jobs = jobs_data.get("jobs", [])
    active   = sum(1 for j in jobs if j.get("enabled") and not j.get("paused_at"))
    scripts  = [j.get("name","?") for j in jobs if j.get("script")]
    return f"{active}/{len(jobs)} active"

def gemgyms_status():
    code = run("curl -s -o /dev/null -w '%{http_code}' https://gemgyms.com --max-time 8 --fail 2>/dev/null || echo '---'")
    ssl   = run("echo | openssl s_client -connect gemgyms.com:443 -servername gemgyms.com 2>/dev/null | grep NotAfter | head -1")
    days_left = "?"
    if "NotAfter" in ssl:
        try:
            from datetime import datetime as dt
            date_str = ssl.split("NotAfter:")[1].strip()
            exp = dt.strptime(date_str, "%b %d %H:%M:%S %Y %GMT")
            days_left = (exp - dt.now()).days
        except:
            pass
    return f"HTTP {code}", f"{days_left} days"

def woocommerce_status():
    ck = os.getenv("WOOCOMMERCE_CK","")
    cs = os.getenv("WOOCOMMERCE_CS","")
    url = os.getenv("WOOCOMMERCE_URL","https://gemgyms.com")
    if not ck: return "No creds"
    resp = run(f"curl -s '{url}/wp-json/wc/v3/products?consumer_key={ck}&consumer_secret={cs}&per_page=1' --max-time 10")
    if '"id"' in resp:
        try:
            data = json.loads(resp)
            total = int(data[0].get('headers',{}).get('X-WP-Total','?')) if isinstance(data, list) else '?'
            return f"OK ({total} products)"
        except:
            return "OK"
    return "FAIL"

def services_status():
    svcs = ["hermes-gateway.service","caddy.service","postiz.service"]
    results = []
    for s in svcs:
        out = run(f"systemctl is-active {s} 2>/dev/null || echo 'not-found'")
        results.append(f"{s.replace('.service','')}: {'✅' if out=='active' else '❌'}")
    return " | ".join(results)

def recent_fixes():
    kb = load_json(KB_FILE)
    errors = kb.get("errors", [])
    auto_fixed = [e for e in errors if e.get("auto_fixed") == True or e.get("auto_fixed") == "true"]
    week_ago = (datetime.now().timestamp() - 7*86400)
    recent = [
        e for e in auto_fixed
        if e.get("last_seen","") and
        str(e.get("last_seen","")) >= str(datetime.fromtimestamp(week_ago).date())
    ]
    return len(auto_fixed), len(recent)

def main():
    log("=== Building Empowerment Report ===")

    total, verified, health = kb_stats()
    auto_fixed_total, auto_fixed_week = recent_fixes()
    cron_summary = cron_jobs_summary()
    http_code, ssl_days = gemgyms_status()
    woo = woocommerce_status()
    svcs = services_status()

    kb_state = load_json(STATE_DIR / "kb_self_audit_state.json")
    runs = kb_state.get("runs", [])
    last_run = runs[-1] if runs else {}

    # Audit gaps
    audit_gaps = kb_state.get("gaps_found", [])
    unresolved = [g for g in audit_gaps if g not in kb_state.get("gaps_fixed", [])][-5:]

    report = {
        "generated": datetime.now().isoformat(),
        "kb": {
            "total_entries": total,
            "verified": verified,
            "health_pct": health,
            "auto_fixes_total": auto_fixed_total,
            "auto_fixes_this_week": auto_fixed_week,
        },
        "monitoring": {
            "cron_jobs": cron_summary,
            "gemgyms_http": http_code,
            "ssl_days_left": ssl_days,
            "woocommerce": woo,
            "services": svcs,
        },
        "last_self_audit": last_run,
        "unresolved_gaps": unresolved,
    }

    with open(OUT_FILE, "w") as f:
        json.dump(report, f, indent=2, default=str)

    # Human-readable output
    print()
    print("=" * 50)
    print("  🤖 SYSTEM EMPOWERMENT REPORT")
    print("=" * 50)
    print(f"  KB Health:      {health}% ({verified}/{total} verified)")
    print(f"  Auto-fixes:     {auto_fixed_week} this week ({auto_fixed_total} total)")
    print(f"  Crons:          {cron_summary}")
    print(f"  gemgyms.com:    {http_code} | SSL: {ssl_days}")
    print(f"  WooCommerce:    {woo}")
    print(f"  Services:       {svcs}")
    print("-" * 50)
    print(f"  Last audit:     {last_run.get('ts','?')}")
    if unresolved:
        print(f"  ⚠️  Unresolved gaps: {len(unresolved)}")
        for g in unresolved:
            print(f"    · {g.get('check','?')}: {g.get('status','?')}")
    print("=" * 50)

    log("Done. Report saved.")

if __name__ == "__main__":
    main()
