#!/usr/bin/env python3
"""
KB Self-Modify — detect and rewrite outdated/broken scripts in /root/.hermes/scripts/.

Detects these patterns:
  1. `kb.get("knowledge_base", [])`  → should use `errors` (current KB schema)
  2. `stdev = statistics.stdev(values) if stdev > 0` → NameError bug;
       references `stdev` before assignment; should be `len(values) >= 2`
  3. `datetime.datetime.now()` when module is imported as `import datetime`
       (unnecessary qualification; just `datetime.now()` works)
  4. Duplicate shebang in auto-generated scripts (`#!/bin/sh\n#!/usr/bin/env python3`)
  5. `write_kb(kb) if anomalies else None` outside the loop — logic error
  6. Generated scripts without file-locking on KB reads/writes

Refactors to current KB schema:
  - Uses `errors[]` as the primary key (with `knowledge_base` fallback for
    backward-compat during migration)
  - Adds fcntl.LOCK_EX/LOCK_UN around all KB writes
  - Uses `datetime.now()` (not `datetime.datetime.now()`)
  - Fixes the zscore NameError bug

Usage
-----
  python3 kb_self_modify.py [--dry-run]    # default: show what would change
  python3 kb_self_modify.py --apply         # actually rewrite the files
  python3 kb_self_modify.py --report        # show all issues without modifying
  python3 kb_self_modify.py --list           # list all detected issues
"""

import json
import re
import sys
import ast
import argparse
import fcntl
from pathlib import Path
from datetime import datetime

# ── Paths ────────────────────────────────────────────────────────────────────
SCRIPTS_DIR = Path("/root/.hermes/scripts")
KB_PATH = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE = Path("/root/.hermes/state/kb_self_modify.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_modify.log")

# Scripts known to be currently generated / up-to-date (skip these)
SKIP_SCRIPTS = {
    "kb_self_modify.py",   # this file
    "kb_self_generation.py",  # generates other scripts; has its own patterns
}

# ── Issue definitions ─────────────────────────────────────────────────────────

class Issue:
    def __init__(self, pattern, replacement, reason, severity="error"):
        self.pattern = pattern      # regex string
        self.replacement = replacement
        self.reason = reason
        self.severity = severity   # "error" | "warning" | "style"

    def __repr__(self):
        return f"<Issue {self.severity}: {self.reason}>"


ISSUE_SPECS = [
    # ── 1. kb.get("knowledge_base", []) — outdated schema key ──────────────
    Issue(
        pattern=r'kb\.get\(\s*["\']knowledge_base["\']\s*,\s*\[\]\s*\)',
        replacement='kb.get("errors", [])',
        reason=(
            'Outdated KB schema key "knowledge_base" — '
            'current schema uses "errors". '
            'Also add knowledge_base→errors migration fallback.'
        ),
        severity="error",
    ),

    # ── 2. stdev NameError bug in zscore functions ─────────────────────────
    #    BAD:  stdev = statistics.stdev(values) if stdev > 0 else 1
    #    GOOD: stdev = statistics.stdev(values) if len(values) >= 2 else 1
    Issue(
        pattern=r'(\s*stdev\s*=\s*statistics\.stdev\(values\))\s+if\s+stdev\s*>\s*0\s+else\s+1',
        replacement=r'\1 if len(values) >= 2 else 1',
        reason=(
            'NameError bug: "stdev" referenced before assignment in zscore(). '
            'Guard should be "len(values) >= 2" (statistics.stdev requires n>=2), '
            'not "stdev > 0".'
        ),
        severity="error",
    ),

    # ── 3. datetime.datetime.now() when module is `import datetime` ───────
    Issue(
        pattern=r'datetime\.datetime\.now\(\)',
        replacement='datetime.now()',
        reason=(
            'Unnecessary qualification: `datetime.datetime.now()` when `import datetime` '
            'is in scope. Use `datetime.now()` directly.'
        ),
        severity="style",
    ),

    # ── 4. Duplicate shebang (auto-generated script header) ─────────────────
    Issue(
        pattern=r'^#!.*\n#!/usr/bin/env python3',
        replacement='#!/usr/bin/env python3',
        reason=(
            'Duplicate shebang: auto-generated script starts with two shebang lines. '
            'Remove the first (non-Python) shebang.'
        ),
        severity="warning",
    ),

    # ── 5. write_kb(kb) if anomalies else None — outside loop (logic bug) ─
    #    Pattern: a line that says `write_kb(kb) if anomalies else None` that
    #    is NOT indented inside a for/if block for anomalies
    Issue(
        pattern=r'^    write_kb\(kb\)\s+if\s+anomalies\s+else\s+None',
        replacement='        write_kb(kb) if anomalies else None',
        reason=(
            'Logic error: `write_kb(kb) if anomalies else None` appears to be '
            'outside the anomalies loop. It should be indented inside the '
            'anomalies block so KB is only written when anomalies were found.'
        ),
        severity="error",
    ),

    # ── 6. Missing file locking on KB writes ────────────────────────────────
    #    Detect write_kb that doesn't use fcntl.LOCK_EX
    #    (matched on `def write_kb` whose body lacks LOCK_EX)
    Issue(
        pattern=r'(?<!fcntl\.flock\(.*LOCK_EX)',
        replacement='',  # handled specially — see fix_write_kb_locking
        reason=(
            'write_kb() lacks fcntl.LOCK_EX locking — may cause data loss '
            'under concurrent execution.'
        ),
        severity="error",
    ),
]


# ── Logging ──────────────────────────────────────────────────────────────────

def log(msg):
    ts = datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


# ── KB helpers ────────────────────────────────────────────────────────────────

def read_kb():
    if not KB_PATH.exists():
        return None
    try:
        with open(KB_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def get_kb_schema():
    """Return the primary entry list key for the current KB schema."""
    kb = read_kb()
    if kb is None:
        return "errors"   # assume current schema
    # Heuristic: prefer the key with more entries
    errors_len = len(kb.get("errors", []))
    kb_len = len(kb.get("knowledge_base", []))
    return "errors" if errors_len >= kb_len else "knowledge_base"


# ── Pattern detection ────────────────────────────────────────────────────────

def detect_issues(script_path):
    """
    Return a dict mapping issue reason → list of (lineno, line_text) matches.
    """
    try:
        source = script_path.read_text()
    except Exception as e:
        return {}

    issues = {}
    lines = source.split("\n")

    for spec in ISSUE_SPECS:
        key = spec.reason
        issues[key] = []

        # Special handling for knowledge_base migration: also record if
        # the script has `knowledge_base` but not `errors` fallback
        if '"knowledge_base"' in spec.pattern:
            for i, line in enumerate(lines, 1):
                if re.search(spec.pattern, line):
                    issues[key].append((i, line))

        elif "stdev" in spec.pattern:
            for i, line in enumerate(lines, 1):
                if re.search(spec.pattern, line):
                    issues[key].append((i, line))

        elif "datetime.datetime.now" in spec.pattern:
            for i, line in enumerate(lines, 1):
                if re.search(spec.pattern, line):
                    issues[key].append((i, line))

        elif "duplicate shebang" in spec.reason.lower():
            for i, line in enumerate(lines, 1):
                if re.search(spec.pattern, line):
                    issues[key].append((i, line))

        elif "write_kb.*anomalies" in spec.pattern:
            for i, line in enumerate(lines, 1):
                if re.search(spec.pattern, line):
                    issues[key].append((i, line))

    return {k: v for k, v in issues.items() if v}


def detect_write_kb_locking(script_path):
    """Check if write_kb uses fcntl.LOCK_EX. Return True if missing locking."""
    try:
        source = script_path.read_text()
    except Exception:
        return False

    # Find write_kb function body
    m = re.search(
        r'def write_kb\([^)]*\):(.*?)(?=\ndef |\nclass |\Z)',
        source, re.DOTALL
    )
    if not m:
        return False
    body = m.group(1)
    return "LOCK_EX" not in body and "fcntl.flock" in source


def detect_kb_schema_fallback(script_path):
    """Check if script reads knowledge_base without also falling back to errors."""
    try:
        source = script_path.read_text()
    except Exception:
        return False
    has_kb = 'kb.get("knowledge_base"' in source or "kb.get('knowledge_base'" in source
    has_errors = 'kb.get("errors"' in source or "kb.get('errors'" in source
    return has_kb and not has_errors


# ── AST-based fixes ──────────────────────────────────────────────────────────

def fix_kb_schema_usage(source):
    """
    Replace kb.get("knowledge_base", []) with kb.get("errors", []).
    Also add a comment noting the knowledge_base fallback was removed.
    """
    fixed_lines = []
    changes = 0

    for line in source.split("\n"):
        new_line = re.sub(
            r'kb\.get\(\s*["\']knowledge_base["\']\s*,\s*\[\]\s*\)',
            'kb.get("errors", [])  # [kb_self_modify: was knowledge_base — schema updated to errors]',
            line
        )
        if new_line != line:
            changes += 1
        fixed_lines.append(new_line)

    return "\n".join(fixed_lines), changes


def fix_zscore_stdev_bug(source):
    """Fix the NameError in zscore(): stdev > 0 → len(values) >= 2."""
    fixed_lines = []
    changes = 0

    for line in source.split("\n"):
        new_line = re.sub(
            r'(\s*stdev\s*=\s*statistics\.stdev\(values\))\s+if\s+stdev\s*>\s*0\s+else\s+1',
            r'\1 if len(values) >= 2 else 1  # [kb_self_modify: fixed NameError — stdev guard]',
            line
        )
        if new_line != line:
            changes += 1
        fixed_lines.append(new_line)

    return "\n".join(fixed_lines), changes


def fix_datetime_qualification(source):
    """Replace datetime.datetime.now() with datetime.now()."""
    fixed_lines = []
    changes = 0

    for line in source.split("\n"):
        new_line = re.sub(r'datetime\.datetime\.now\(\)', 'datetime.now()', line)
        if new_line != line:
            changes += 1
        fixed_lines.append(new_line)

    return "\n".join(fixed_lines), changes


def fix_duplicate_shebang(source):
    """Remove duplicate shebang lines at the top of auto-generated scripts."""
    lines = source.split("\n")
    # Find first non-shebang line
    first_real_line = 0
    for i, line in enumerate(lines):
        if line and not line.startswith("#!"):
            first_real_line = i
            break
    else:
        first_real_line = len(lines)

    # Check if there are 2+ shebang lines before the first real line
    shebang_lines = [l for l in lines[:first_real_line] if l.startswith("#!")]
    if len(shebang_lines) < 2:
        return source, 0

    # Keep only the last shebang (which should be the Python shebang)
    # Remove all shebangs then re-add just the Python one
    new_lines = [l for l in lines if not l.startswith("#!")]
    new_lines = ["#!/usr/bin/env python3", ""] + new_lines
    return "\n".join(new_lines), 1


def fix_write_kb_locking(source, script_path):
    """
    Add fcntl.LOCK_EX/LOCK_UN to write_kb if missing.
    Rewrites the function to use file locking.
    """
    name = script_path.stem

    # Find the write_kb function
    m = re.search(
        r'(def write_kb\([^)]*\):.*?)((?=\ndef |\nclass |\Z))',
        source, re.DOTALL
    )
    if not m:
        return source, 0

    func_body = m.group(1)
    after = m.group(2)

    # Already has locking
    if "LOCK_EX" in func_body:
        return source, 0

    # Build new locked version
    new_func_body = func_body.replace(
        "def write_kb(kb):",
        f"def write_kb(kb):\n    # [kb_self_modify: added file locking]"
    )

    # Check current locking style
    has_fcntl_import = "import fcntl" in source or "from fcntl import" in source

    if "fcntl.flock" in func_body:
        # Has flock but not LOCK_EX — already using flock correctly
        return source, 0

    # Add locking wrapper
    locked_body = """def write_kb(kb):
    # [kb_self_modify: added file locking]
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
"""
    # Replace the old write_kb with the locked version
    new_source = source[:m.start()] + locked_body + source[m.end():]

    # Add fcntl import if missing
    if not has_fcntl_import:
        # Add after other imports
        import_line = "import fcntl\n"
        if "import json" in new_source:
            new_source = new_source.replace("import json\n", "import fcntl\nimport json\n", 1)
        elif "import subprocess" in new_source:
            new_source = new_source.replace("import subprocess\n", "import fcntl\nimport subprocess\n", 1)
        else:
            # Prepend
            new_source = import_line + new_source

    return new_source, 1


def fix_anomalies_write_kb_position(source):
    """
    Find `write_kb(kb) if anomalies else None` that appears at the wrong
    indentation level and is clearly outside the anomalies loop. Move it
    inside the loop or remove the redundant conditional.
    """
    lines = source.split("\n")
    changed = False

    for i, line in enumerate(lines):
        if re.match(r'^    write_kb\(kb\)\s+if\s+anomalies\s+else\s+None', line):
            # This line should be inside the loop — re-indent it
            lines[i] = "        " + line.strip()
            changed = True

    return "\n".join(lines), 1 if changed else 0


# ── Knowledge-base schema migration ─────────────────────────────────────────

def add_kb_migration_fallback(source, script_path):
    """
    If the script reads `kb.get("knowledge_base", [])` but has no `errors`
    fallback, add a helper that returns the best available key.

    Adds a `get_kb_entries(kb)` helper after the read_kb() definition.
    """
    has_kb_ref = 'kb.get("knowledge_base"' in source or "kb.get('knowledge_base'" in source
    has_errors_ref = 'kb.get("errors"' in source or "kb.get('errors'" in source
    has_get_entries = "def get_kb_entries" in source

    if not (has_kb_ref and not has_errors_ref and not has_get_entries):
        return source, 0

    helper = '''
def get_kb_entries(kb):
    """Return the current KB entry list, migrating from legacy knowledge_base key."""
    # Primary key is errors[]; knowledge_base is a legacy key being phased out
    if kb.get("errors"):
        return kb["errors"]
    entries = kb.get("knowledge_base", [])
    if not entries:
        # Empty legacy key — migrate to errors
        kb["errors"] = []
        return kb["errors"]
    return entries

'''

    # Insert after the last `def read_kb` or at the imports
    insert_pos = source.find("\ndef get_kb_entries")
    if insert_pos != -1:
        return source, 0   # already has it

    # Insert after read_kb definition
    read_kb_match = re.search(r'(def read_kb\(\):.*?)(?=\n\ndef |\n\nclass |\Z)', source, re.DOTALL)
    if read_kb_match:
        end = read_kb_match.end()
        source = source[:end] + helper + source[end:]
        return source, 1

    return source, 0


# ── Main fix dispatch ─────────────────────────────────────────────────────────

FIXES = [
    ("KB schema: knowledge_base → errors", fix_kb_schema_usage),
    ("zscore stdev NameError fix",          fix_zscore_stdev_bug),
    ("datetime.datetime.now() → datetime.now()", fix_datetime_qualification),
    ("Duplicate shebang removal",           fix_duplicate_shebang),
    ("write_kb() file locking",              fix_write_kb_locking),
    ("anomalies write_kb position fix",     fix_anomalies_write_kb_position),
    ("KB migration helper (get_kb_entries)", add_kb_migration_fallback),
]


def process_script(script_path, dry_run=True, report_only=False):
    """Scan a script, apply all applicable fixes, return a report dict."""
    if script_path.name in SKIP_SCRIPTS:
        return None

    if script_path.suffix != ".py":
        return None

    try:
        source = script_path.read_text()
    except Exception as e:
        return {"error": str(e), "script": script_path.name}

    original_source = source
    report = {
        "script": script_path.name,
        "path": str(script_path),
        "fixes": [],
        "issues": [],
        "changed": False,
    }

    for fix_name, fix_fn in FIXES:
        try:
            if fix_name == "write_kb() file locking":
                new_source, n = fix_fn(source, script_path)
            elif fix_name == "KB migration helper (get_kb_entries)":
                new_source, n = fix_fn(source, script_path)
            else:
                new_source, n = fix_fn(source)
        except Exception as e:
            report["issues"].append({
                "fix": fix_name,
                "error": str(e),
                "severity": "internal_error",
            })
            continue

        if n > 0:
            report["fixes"].append({
                "fix": fix_name,
                "count": n,
            })
            source = new_source

    report["changed"] = source != original_source

    if report["changed"] and not dry_run and not report_only:
        script_path.write_text(source)
        report["applied"] = True

    return report


def run_all(scripts_dir, dry_run=True, report_only=False):
    """Process all .py scripts in scripts_dir."""
    log(f"=== kb_self_modify started (dry_run={dry_run}, report_only={report_only}) ===")

    scripts = sorted(scripts_dir.glob("*.py"))
    results = []

    for script_path in scripts:
        result = process_script(script_path, dry_run=dry_run, report_only=report_only)
        if result:
            results.append(result)

    # Summary
    total_fixes = sum(len(r["fixes"]) for r in results)
    total_changed = sum(1 for r in results if r.get("changed"))
    total_issues = sum(len(r.get("issues", [])) for r in results)

    summary = {
        "timestamp": datetime.now().isoformat(),
        "dry_run": dry_run,
        "scripts_scanned": len(scripts),
        "scripts_with_fixes": total_changed,
        "total_fixes_applied": total_fixes,
        "total_issues": total_issues,
        "results": results,
    }

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(summary, fh, indent=2)

    log(f"=== kb_self_modify done: {total_changed}/{len(scripts)} scripts need changes, "
        f"{total_fixes} fixes, {total_issues} issues ===")

    return summary


# ── CLI ──────────────────────────────────────────────────────────────────────

def print_report(summary):
    print("\n" + "=" * 70)
    print("KB SELF-MODIFY REPORT")
    print("=" * 70)
    print(f"Scanned : {summary['scripts_scanned']} scripts")
    print(f"Needs fix: {summary['scripts_with_fixes']}")
    print(f"Fixes   : {summary['total_fixes_applied']}")
    print(f"Issues  : {summary['total_issues']}")
    print("-" * 70)

    for r in summary["results"]:
        if not r.get("fixes") and not r.get("issues"):
            continue

        print(f"\n  {r['script']}")
        if r.get("error"):
            print(f"    ERROR: {r['error']}")
            continue

        for fix in r.get("fixes", []):
            print(f"    [{fix['count']}×] {fix['fix']}")

        for iss in r.get("issues", []):
            print(f"    [!{iss['severity']}] {iss['fix']}: {iss.get('error', '')}")

        if r.get("applied"):
            print(f"    → APPLIED")
        elif r.get("changed"):
            print(f"    → (dry-run — no changes written)")

    print()


def main():
    parser = argparse.ArgumentParser(description="KB self-modify: detect and fix outdated scripts")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--dry-run", dest="mode", action="store_const", const="dry-run")
    group.add_argument("--apply", dest="mode", action="store_const", const="apply")
    group.add_argument("--report", dest="mode", action="store_const", const="report")
    group.add_argument("--list", dest="mode", action="store_const", const="list")
    parser.set_defaults(mode="dry-run")
    args = parser.parse_args()

    if args.mode == "list":
        # Just list issues without running fixes
        summary = run_all(SCRIPTS_DIR, dry_run=True, report_only=True)
        print_report(summary)
        return

    if args.mode == "report":
        summary = run_all(SCRIPTS_DIR, dry_run=True, report_only=True)
        print_report(summary)
        return

    if args.mode == "dry-run":
        summary = run_all(SCRIPTS_DIR, dry_run=True, report_only=False)
        print_report(summary)
        print("No changes written. Use --apply to apply fixes.")
        return

    if args.mode == "apply":
        summary = run_all(SCRIPTS_DIR, dry_run=False, report_only=False)
        print_report(summary)
        print("Changes applied.")
        return


if __name__ == "__main__":
    main()
