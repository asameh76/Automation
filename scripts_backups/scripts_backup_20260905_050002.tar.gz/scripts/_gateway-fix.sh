#!/bin/bash
# Daemon self-heal script — runs in separate PID, bypasses gateway signal blocking
kill $(pgrep -f "hermes_cli.main gateway") 2>/dev/null
sleep 2
systemctl --user start hermes-gateway
sleep 3
systemctl --user status hermes-gateway --no-pager | head -4
