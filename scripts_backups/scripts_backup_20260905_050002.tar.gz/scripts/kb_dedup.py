#!/usr/bin/env python3
"""
kb_dedup.py — Auto-merge duplicate errors/symptoms in the error-knowledge-base.json.

Deduplication strategy
-----------------------
Two errors are considered duplicates when they share the same (component +
correlation_type) pair AND at least one of the following is true:
  1. Identical or near-identical fix text (normalised Levenshtein ratio ≥ 0.85)
  2. Both are unverified / zero-occurrence curiosity/self-query entries
  3. Their signatures follow the same synthetic pattern (e.g. multiple
     synthetic__curiosity__<component>__NNNN_X shards)

Merging keeps the "best" entry (highest success_rate / occurrence_count) as the
canonical record and folds in:
  • fix_chains  (deduplicated by if_error → then_fix key)
  • component_dependencies (summed cooccur counts)
  • correlated_sources (union of all source hashes)
  • occurrence_count, success_count, fail_count (summed)
  • first_seen (earliest date)
  • last_seen  (latest date)
  • correlation_group_size (number of merged entries)

Usage
-----
  python3 kb_dedup.py [--dry-run] [--report]
  --dry-run   show what would change without writing
  --report    print a detailed merge report even in normal mode
"""

import json
import argparse
import fcntl
import datetime
import hashlib
from pathlib import Path
from Levenshtein import ratio as lev_ratio

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_dedup.log")
# Keep existing scripts company
REPORT_FILE = Path("/root/.hermes/state/kb_dedup_report.json")


# ---------------------------------------------------------------------------
# Normalisation helpers
# ---------------------------------------------------------------------------

def _norm(s):
    """Lowercase, collapse whitespace."""
    if not s:
        return ""
    return " ".join(s.lower().split())


def sig_is_synthetic_shard(sig, prefix):
    """Return True when sig is a numbered synthetic shard of the given prefix."""
    return sig.startswith(prefix + "_") and sig.split("_")[-1].isdigit()


def cluster_key(entry):
    """Return a grouping key for duplicate detection: (component, correlation_type)."""
    return (entry.get("component", "") or "", entry.get("correlation_type", "") or "")


# ---------------------------------------------------------------------------
# Core merge logic
# ---------------------------------------------------------------------------

def merge_entries(best, others):
    """
    Fold `others` into `best` and return the merged record.
    best/others are list[dict] error entries.
    """
    merged = dict(best)          # shallow copy of the canonical entry

    # --- occurrence counts (summed) ---
    merged["occurrence_count"] = sum(
        int(e.get("occurrence_count", 0) or 0) for e in [best] + others
    )
    merged["success_count"] = sum(
        int(e.get("success_count", 0) or 0) for e in [best] + others
    )
    merged["fail_count"] = sum(
        int(e.get("fail_count", 0) or 0) for e in [best] + others
    )
    merged["total_uses"] = sum(
        int(e.get("total_uses", 0) or 0) for e in [best] + others
    )

    # --- dates: earliest first_seen, latest last_seen ---
    dates = [e.get("first_seen", "") for e in [best] + others if e.get("first_seen")]
    merged["first_seen"] = min(dates) if dates else merged.get("first_seen", "")
    dates_last = [e.get("last_seen", "") for e in [best] + others if e.get("last_seen")]
    merged["last_seen"] = max(dates_last) if dates_last else merged.get("last_seen", "")

    # --- correlation group size ---
    merged["correlation_group_size"] = len([best] + others)

    # --- fix_chains: dedup by (if_error, then_fix) key ---
    seen_chains = {}
    for e in [best] + others:
        for fc in e.get("fix_chains", []):
            key = (fc.get("if_error", ""), fc.get("then_fix", ""))
            if key not in seen_chains:
                seen_chains[key] = fc
            else:
                # keep highest confidence
                existing = seen_chains[key]
                if fc.get("confidence", 0) > existing.get("confidence", 0):
                    seen_chains[key] = fc
    merged["fix_chains"] = list(seen_chains.values())

    # --- component_dependencies: sum cooccur for same component ---
    dep_map = {}
    for e in [best] + others:
        for dep in e.get("component_dependencies", []):
            c = dep.get("component", "")
            if c in dep_map:
                dep_map[c]["cooccur"] += dep.get("cooccur", 0)
            else:
                dep_map[c] = dict(dep)
    merged["component_dependencies"] = list(dep_map.values())

    # --- correlated_sources: union of lists ---
    src_sets = set()
    for e in [best] + others:
        for s in e.get("correlated_sources", []):
            src_sets.add(s)
    merged["correlated_sources"] = list(src_sets)

    # --- value_score: re-derive from merged counts ---
    sc = merged["success_count"]
    fc = merged["fail_count"]
    merged["success_rate"] = (sc / (sc + fc)) if (sc + fc) > 0 else 0.0
    merged["value_score"] = merged["success_rate"] * merged.get("total_uses", 0)

    # --- status rollup: verified > unknown > false > gap ---
    verified_order = {"true": 0, "unknown": 1, "false": 2, "gap": 3}
    statuses = [best.get("verified", "unknown")] + [o.get("verified", "unknown") for o in others]
    merged["verified"] = min(statuses, key=lambda s: verified_order.get(s, 99))

    # --- signature: keep best sig ---
    merged["signature"] = best.get("signature", "")

    return merged


def find_duplicates(errors):
    """
    Scan all errors and return a list of clusters to merge.
    Each cluster is a dict: {'best': canonical_entry, 'others': [entry, ...], 'reason': str}
    """
    by_key = {}
    for e in errors:
        k = cluster_key(e)
        by_key.setdefault(k, []).append(e)

    clusters = []

    for (component, corr_type), entries in by_key.items():
        if len(entries) < 2:
            continue

        # ---- Strategy 1: truly identical fixes (ratio ≥ 0.95) ----
        # A ratio of 0.85 is too aggressive for entries with distinct error
        # descriptions. Use 0.95 to catch only verbatim/typo-variant dupes.
        for i, a in enumerate(entries):
            for b in entries[i + 1:]:
                fix_a = _norm(a.get("fix", ""))
                fix_b = _norm(b.get("fix", ""))
                if lev_ratio(fix_a, fix_b) >= 0.95:
                    dupes = {id(a), id(b)}
                    for c in entries:
                        if lev_ratio(_norm(c.get("fix", "")), fix_a) >= 0.95:
                            dupes.add(id(c))
                    dupes_list = [e for e in entries if id(e) in dupes]
                    canonical = max(dupes_list, key=lambda e: (
                        float(e.get("success_rate") or 0),
                        int(e.get("occurrence_count") or 0),
                    ))
                    clusters.append({
                        "best": canonical,
                        "others": [e for e in dupes_list if e is not canonical],
                        "reason": "near-identical fix text",
                        "_all": dupes_list,
                    })
                    break  # stop scanning this pair once cluster is formed

        # ---- Strategy 2: synthetic shard clusters (same component + corr_type) ----
        # These are synthetic self-queries generated with different random seeds.
        # Only merge when they have ZERO real-world occurrence and their fixes
        # are literally the same string (same curiosity/gap template).
        prefixes = {}
        for e in entries:
            sig = e.get("signature", "")
            for prefix in ["synthetic__curiosity", "synthetic__self_query",
                           "synthetic__novel", "synthetic__gap"]:
                if sig_is_synthetic_shard(sig, prefix):
                    prefixes.setdefault(prefix, []).append(e)
                    break

        for prefix, shard_entries in prefixes.items():
            if len(shard_entries) < 2:
                continue
            # Group by exact normalised fix string within this prefix
            by_fix = {}
            for e in shard_entries:
                key = _norm(e.get("fix", ""))
                by_fix.setdefault(key, []).append(e)
            for fix_str, same_fix_entries in by_fix.items():
                if len(same_fix_entries) < 2:
                    continue
                canonical = max(same_fix_entries, key=lambda e: (
                    float(e.get("success_rate") or 0),
                    int(e.get("occurrence_count") or 0),
                ))
                clusters.append({
                    "best": canonical,
                    "others": [e for e in same_fix_entries if e is not canonical],
                    "reason": f"synthetic shard cluster ({prefix})",
                    "_all": same_fix_entries,
                })

    # ---- Remove overlapping entries (keep first-formed cluster) ----
    consumed = set()
    filtered = []
    for cluster in clusters:
        all_ids = {id(e) for e in cluster["_all"]}
        if all_ids & consumed:
            continue   # skip — already merged elsewhere
        consumed |= all_ids
        filtered.append(cluster)

    return filtered


def run_dedup(kb, dry_run=False):
    errors = kb.get("errors", [])
    clusters = find_duplicates(errors)

    if not clusters:
        return {"merged": 0, "clusters": [], "dry_run": dry_run}

    # Build signature → entry map for fast lookup
    sig_map = {e["signature"]: e for e in errors}

    # For each cluster: build merged entry, remove others, insert merged
    merged_count = 0
    total_removed = 0
    reports = []

    for cluster in clusters:
        best = cluster["best"]
        others = cluster["others"]
        merged = merge_entries(best, others)
        merged_count += 1
        total_removed += len(others)

        if not dry_run:
            # Remove others from errors list
            other_sigs = {o["signature"] for o in others}
            kb["errors"] = [e for e in kb["errors"] if e["signature"] not in other_sigs]
            # Append merged entry (replace the best entry in-place)
            for i, e in enumerate(kb["errors"]):
                if e["signature"] == best["signature"]:
                    kb["errors"][i] = merged
                    break

        reports.append({
            "canonical_sig": best["signature"],
            "removed_sigs": [o["signature"] for o in others],
            "reason": cluster["reason"],
            "merged_occurrence_count": merged.get("occurrence_count"),
            "merged_fix_chains": len(merged.get("fix_chains", [])),
        })

    action = "Would merge (dry-run)" if dry_run else "Merged"
    log(f"{action}: {merged_count} cluster(s), {total_removed} duplicate entry/entries removed")

    return {
        "merged": merged_count,
        "removed": total_removed,
        "clusters": reports,
        "dry_run": dry_run,
    }


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


# ---------------------------------------------------------------------------
# KB read / write (file-locked)
# ---------------------------------------------------------------------------

def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Deduplicate error-knowledge-base.json")
    parser.add_argument("--dry-run", action="store_true", help="Show changes without writing")
    parser.add_argument("--report", action="store_true", help="Write JSON report to state/kb_dedup_report.json")
    args = parser.parse_args()

    log("=== kb_dedup started ===")
    if args.dry_run:
        log("DRY-RUN mode enabled — no changes will be written")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    original_count = len(kb.get("errors", []))

    result = run_dedup(kb, dry_run=args.dry_run)

    if not args.dry_run:
        write_kb(kb)
        log(f"KB written — errors before: {original_count}, after: {len(kb.get('errors', []))}")

    # Always print summary
    if result["merged"] == 0:
        log("No duplicate clusters found — nothing to do.")
    else:
        log(f"Summary: {result['merged']} cluster(s) merged, {result.get('removed', 0)} duplicate(s) removed.")

    if args.report or not args.dry_run:
        REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        result["original_error_count"] = original_count
        result["final_error_count"] = len(kb.get("errors", [])) if not args.dry_run else original_count
        with open(REPORT_FILE, "w") as f:
            json.dump(result, f, indent=2)
        log(f"Report written to {REPORT_FILE}")

    log("=== kb_dedup finished ===")


if __name__ == "__main__":
    main()
