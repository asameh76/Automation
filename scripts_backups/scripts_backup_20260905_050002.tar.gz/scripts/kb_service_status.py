#!/usr/bin/env python3
"""
KB Service Status - Service status checker.
"""

import json
import subprocess
import datetime
from pathlib import Path


STATUS_FILE = Path("/root/.hermes/state/kb_service_status.json")
LOG_FILE = Path("/root/.hermes/logs/kb_service_status.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


SERVICES = ["docker", "nginx", "postiz", "temporal", "redis"]


def check_service(name):
    """Check if a service is running."""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout.strip() == "active"
    except Exception:
        pass
    return None


def check_docker_container(name):
    """Check if a docker container is running."""
    try:
        result = subprocess.run(
            ["docker", "ps", "--filter", f"name={name}", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return name in result.stdout
    except Exception:
        return None


def main():
    log("=== KB Service Status started ===")

    status = {
        "timestamp": datetime.datetime.now().isoformat(),
        "services": {},
    }

    for svc in SERVICES:
        svc_status = check_service(svc)
        status["services"][svc] = {
            "systemd": svc_status,
            "docker": check_docker_container(svc),
        }

    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATUS_FILE, "w") as fh:
        json.dump(status, fh, indent=2)

    active = sum(1 for s in status["services"].values() if s.get("systemd") or s.get("docker"))
    log(f"=== KB Service Status: {active}/{len(SERVICES)} active ===")


if __name__ == "__main__":
    main()
