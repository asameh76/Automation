#!/usr/bin/env python3
"""
Auto-restore from R2 backup on failure.
Uses rclone to sync local backup to R2.
"""
import subprocess, sys

def check_r2():
    # Check if R2 is accessible
    r = subprocess.run(
        "rclone ls r2:backups/ --files-only 2>&1",
        shell=True,
        capture_output=True,
        text=True,
        timeout=30
    )
    return "error" not in r.stderr.lower() and r.returncode == 0

def restore_last_backup():
    # Use rclone copy (not tar) to sync latest backup
    r = subprocess.run(
        "rclone copy r2:backups/latest/ /root/ --drive-snapshot 2>&1",
        shell=True,
        capture_output=True,
        text=True,
        timeout=60
    )
    return r.returncode == 0

def main():
    if not check_r2():
        print("[r2-recovery] R2 access failed")
        sys.exit(1)
    
    if restore_last_backup():
        print("[r2-recovery] Restored latest backup")
    else:
        print("[r2-recovery] Restore failed")
        sys.exit(1)

if __name__ == "__main__":
    main()