#!/usr/bin/env python3
"""
Anomaly Daemon v4 — event-driven KB updates.
After each detection/fix, writes a structured event to the event bus.
Evolution engine reads the bus on next run and processes all accumulated events.
Smooth, real-time data flow: daemon → event bus → evolution engine → improved KB.
"""
import time, json, re, sys, subprocess, datetime, difflib, threading, resource, os, requests
from pathlib import Path
from collections import defaultdict

HERMES        = Path("/root/.hermes")
LOG_DIR       = HERMES / "logs"
KB_PATH       = HERMES / "error-knowledge-base.json"
EVENT_BUS     = HERMES / "event-bus.jsonl"
LOCK          = threading.RLock()

CHECK_INTERVAL  = 60
ERROR_WINDOW    = 10
SPIKE_THRESHOLD = 5
SESSION_LIMIT   = 50   # max messages per poll

# ── Internet sources ──────────────────────────────────────────
# Monitors: VPS health, WooCommerce API, local gateway
# gemgyms_vps returns 404 for /health but that means nginx is UP — use that as health signal
# jollyjewelry returns 000 (connection refused) when Hostinger VPS is down
INTERNET_TARGETS = [
    {"name": "gemgyms_vps",      "url": "http://178.105.72.98/",                                        "timeout": 5,  "keywords": ["error", "fail", "503", "502"],        "fail_on": [000],  "label": "Gem Gyms VPS nginx"},
    {"name": "gemgyms_health",   "url": "http://178.105.72.98/health",                                  "timeout": 5,  "keywords": ["error", "fail", "503", "502"],        "fail_on": [404],  "label": "Gem Gyms health endpoint"},
    {"name": "jollyjewelry",     "url": "https://jollyjewelry.shop/",                                   "timeout": 10, "keywords": ["error", "fail", "503", "502"],        "fail_on": [000],  "label": "Jolly Jewelry store"},
    {"name": "hermes_gateway",   "url": "http://localhost:18998/health",                               "timeout": 3,  "keywords": ["error", "fail", "unhealthy"],           "fail_on": [000],  "label": "Hermes gateway"},
    {"name": "gemgyms_wp",       "url": "http://178.105.72.98/wp-cron.php",                             "timeout": 5,  "keywords": ["error", "Parse error", "fatal"],        "fail_on": [000],  "label": "Gem Gyms WP cron"},
]
SRC_INTERNET = True

# ── Source paths ────────────────────────────────────────────────
BASH_HISTORY   = Path.home() / ".bash_history"
BASH_POS_FILE  = HERMES / ".bash_pos"
SRC_BASH       = BASH_HISTORY.exists()

NGINX_ERR_LOG  = Path("/var/log/nginx/error.log")
NGINX_POS      = HERMES / ".nginx_err_pos"
SRC_NGINX      = NGINX_ERR_LOG.exists()

HERMES_AGENT_LOG = Path.home() / ".hermes" / "logs" / "agent.log"
HERMES_LOG_POS   = HERMES / ".hermes_log_pos"
SRC_HERMES_LOG  = HERMES_AGENT_LOG.exists()

DOCKER_LOG_DIR = Path("/var/lib/docker/containers")
SRC_DOCKER     = DOCKER_LOG_DIR.exists()

HINDSIGHT_DB   = HERMES / "state.db"
HINDSIGHT_POS  = HERMES / ".hindsight_pos"
SRC_HINDSIGHT  = HINDSIGHT_DB.exists()

SESSION_DB     = HERMES / "state.db"
SESSION_POS    = HERMES / ".sessions_pos"
SRC_SESSIONS   = SESSION_DB.exists()

GIT_DIR        = Path("/root/hermes-bot-v2")
SRC_GIT        = (GIT_DIR / ".git").exists()

# ── Source readers ──────────────────────────────────────────────

def read_bash_history():
    """Read new lines since last poll, detect failed commands. Uses position cursor."""
    if not SRC_BASH or not BASH_HISTORY.exists():
        return []
    last_pos = int(BASH_POS_FILE.read_text().strip()) if BASH_POS_FILE.exists() else 0
    lines = BASH_HISTORY.read_text().splitlines()
    new_lines = lines[last_pos:]
    if new_lines:
        BASH_POS_FILE.write_text(str(len(lines)))
    events = []
    for line in new_lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith(" || true") or line.endswith(" || :"):
            continue
        if any(k in line.lower() for k in ["error", "fail", "cannot", "unable", "permission denied", "no such file"]):
            sig = re.sub(r'[^a-z0-9]', '_', line[:60].lower())
            events.append({"type": "bash_error", "signature": sig, "cmd": line[:120]})
    return events

def read_docker_logs():
    """Tail last 100 lines of each container json.log, detect errors by JSON level field. Uses subprocess to avoid loading 3GB files into memory."""
    if not SRC_DOCKER or not DOCKER_LOG_DIR.exists():
        return []
    events = []
    try:
        for container_dir in DOCKER_LOG_DIR.iterdir():
            log_file = container_dir / (container_dir.name + "-json.log")
            if not log_file.exists():
                continue
            try:
                # Use tail to read only last 100 lines — avoids loading multi-GB files
                result = subprocess.run(
                    ["tail", "-n", "100", str(log_file)],
                    capture_output=True, text=True, timeout=5
                )
                lines = result.stdout.splitlines()
                for line in lines:
                    # Parse JSON: {"log":"...","stream":"stdout/stderr","time":"..."}
                    # The log field often CONTAINS another JSON string (double-wrapped)
                    try:
                        entry = json.loads(line)
                        raw = entry.get("log", "")
                        if not raw.strip():
                            continue
                        # Try to parse inner JSON to find level field
                        level = ""
                        try:
                            inner = json.loads(raw)
                            level = inner.get("level", "").upper()
                            # Extract message for signature
                            message = inner.get("message", raw)
                        except (json.JSONDecodeError, ValueError):
                            message = raw
                        # Skip INFO/DEBUG/TRACE — they pollute the signal
                        if level in ("DEBUG", "TRACE", "INFO"):
                            continue
                        # Accept ERROR/FATAL/CRITICAL/WARN/WARNING, or unstructured error keywords
                        is_error = level in ("ERROR", "FATAL", "CRITICAL", "WARN", "WARNING") or \
                                   any(k in message.lower() for k in ["exception", "fatal", "failed", "cannot", "timeout"])
                        if is_error:
                            sig = re.sub(r'[^a-z0-9]', '_', message[:60].lower())
                            events.append({"type": "docker_error", "signature": sig, "log": log_file.name[:40], "line": message[:120]})
                    except (json.JSONDecodeError, ValueError):
                        # Unstructured line — apply keyword filter
                        if any(k in line.lower() for k in ["error", "exception", "fatal", "failed"]):
                            sig = re.sub(r'[^a-z0-9]', '_', line[:60].lower())
                            events.append({"type": "docker_error", "signature": sig, "log": log_file.name[:40], "line": line[:120]})
            except PermissionError:
                pass
    except Exception:
        pass
    return events

def read_nginx_errors():
    """Tail nginx error.log — captures upstream 502/503, PHP errors, SSL failures."""
    if not SRC_NGINX or not NGINX_ERR_LOG.exists():
        return []
    try:
        last_pos = int(NGINX_POS.read_text().strip()) if NGINX_POS.exists() else 0
        lines = NGINX_ERR_LOG.read_text().splitlines()
        new_lines = lines[last_pos:]
        if new_lines:
            NGINX_POS.write_text(str(len(lines)))
        events = []
        for line in new_lines:
            line = line.strip()
            if not line:
                continue
            # nginx error patterns: [error] [crit] [alert] levels + upstream errors
            if any(k in line.lower() for k in ["error", "crit", "alert", "emerg", "fail", "502", "503", "504", "upstream"]):
                sig = re.sub(r'[^a-z0-9]', '_', line[:60].lower())
                events.append({"type": "nginx_error", "signature": sig, "line": line[:150]})
        return events
    except Exception:
        return []

def read_hermes_logs():
    """Tail hermes agent.log — captures Hermes internal errors and warnings."""
    if not SRC_HERMES_LOG or not HERMES_AGENT_LOG.exists():
        return []
    try:
        last_pos = int(HERMES_LOG_POS.read_text().strip()) if HERMES_LOG_POS.exists() else 0
        lines = HERMES_AGENT_LOG.read_text().splitlines()
        new_lines = lines[last_pos:]
        if new_lines:
            HERMES_LOG_POS.write_text(str(len(lines)))
        events = []
        for line in new_lines:
            line = line.strip()
            if not line:
                continue
            if any(k in line.lower() for k in ["error", "exception", "failed", "warn", "traceback", "fault"]):
                sig = re.sub(r'[^a-z0-9]', '_', line[:60].lower())
                events.append({"type": "hermes_log_error", "signature": sig, "line": line[:150]})
        return events
    except Exception:
        return []

def read_hindsight():
    """Query state.db system_prompts table for new KB entries — incremental by hash."""
    if not SRC_HINDSIGHT or not HINDSIGHT_DB.exists():
        return []
    try:
        import sqlite3
        last_hash_file = HINDSIGHT_POS
        last_hash = last_hash_file.read_text().strip() if last_hash_file.exists() else ""
        conn = sqlite3.connect(str(HINDSIGHT_DB))
        # Read new rows since last known hash
        if last_hash:
            rows = conn.execute(
                "SELECT hash, prompt FROM system_prompts WHERE hash > ? LIMIT 50",
                (last_hash,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT hash, prompt FROM system_prompts ORDER BY hash LIMIT 50"
            ).fetchall()
        conn.close()
        if rows:
            last_hash_file.write_text(rows[-1][0])
        return [{"type": "hindsight_entry", "id": r[0], "content": r[1][:200]} for r in rows]
    except Exception:
        return []

def read_sessions():
    """Query state.db messages table for error patterns — only new rows since last poll."""
    if not SRC_SESSIONS or not SESSION_DB.exists():
        return []
    try:
        import sqlite3
        last_ts_file = SESSION_POS
        last_ts = float(last_ts_file.read_text().strip()) if last_ts_file.exists() else 0.0
        conn = sqlite3.connect(str(SESSION_DB))
        rows = conn.execute(
            "SELECT id, role, content FROM messages WHERE timestamp > ? ORDER BY timestamp ASC LIMIT ?",
            (last_ts, SESSION_LIMIT)
        ).fetchall()
        newest = conn.execute("SELECT MAX(timestamp) FROM messages").fetchone()[0] or last_ts
        conn.close()
        if rows:
            last_ts_file.write_text(str(newest))
        events = []
        for r in rows:
            content = r[2] or ""
            if any(k in content.lower() for k in ["error", "exception", "failed", "traceback"]):
                sig = re.sub(r'[^a-z0-9]', '_', content[:60].lower())
                events.append({"type": "session_error", "signature": sig, "role": r[1], "content": content[:150]})
        return events
    except Exception:
        return []

# ── Hindsight true source ─────────────────────────────────────
MEMORY_MD  = HERMES / "memories" / "MEMORY.md"
USER_MD    = HERMES / "memories" / "USER.md"
HINDSIGHT_POS_MD = HERMES / ".hindsight_md_pos"

def read_hindsight_md():
    """Read real hindsight from MEMORY.md and USER.md — incremental by mtime."""
    events = []
    for path in [MEMORY_MD, USER_MD]:
        if not path.exists():
            continue
        pos_file = HINDSIGHT_POS_MD
        last_mtime = float(pos_file.read_text().strip()) if pos_file.exists() else 0
        mtime = path.stat().st_mtime
        if mtime <= last_mtime:
            continue
        # Read new content since last mtime — find the delta
        content = path.read_text()
        # Simple: emit an event with first 200 chars as sample
        events.append({
            "type": "hindsight_md",
            "source": path.name,
            "mtime": str(mtime),
            "sample": content[:200]
        })
        pos_file.write_text(str(mtime))
    return events

def read_git_history():
    """Check hermes-bot-v2 git log for recent commits referencing errors/fixes."""
    if not SRC_GIT or not (GIT_DIR / ".git").exists():
        return []
    try:
        last_sha_file = HERMES / ".git_pos"
        last_sha = last_sha_file.read_text().strip() if last_sha_file.exists() else ""
        result = subprocess.run(
            ["git", "-C", str(GIT_DIR), "log", "--oneline", "-20", "--all"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode != 0:
            return []
        lines = result.stdout.splitlines()
        events = []
        seen_new = False
        for line in lines:
            if last_sha and line.startswith(last_sha):
                break
            seen_new = True
            msg = line[8:]
            # Capture all commits, not just keyword matches — let evolution engine filter
            sig = re.sub(r'[^a-z0-9]', '_', msg[:60].lower())
            events.append({"type": "git_commit", "commit": line[:8], "message": msg[:100]})
        if lines:
            last_sha_file.write_text(lines[0][:8])
        return events
    except Exception:
        return []

def read_internet_sources():
    """Poll HTTP endpoints for errors. Uses requests library with timeout."""
    if not SRC_INTERNET:
        return []
    events = []
    for target in INTERNET_TARGETS:
        label  = target.get("label", target["name"])
        fail_on = target.get("fail_on", [])
        try:
            resp = requests.get(target["url"], timeout=target["timeout"])
            text = resp.text.lower()
            code = resp.status_code
            # Treat fail_on codes as errors (e.g. 000=connection refused, 404=endpoint missing)
            code_err  = code >= 500 or code in fail_on
            keyword_err = any(k in text for k in target["keywords"])
            if code_err or keyword_err:
                sig = re.sub(r'[^a-z0-9]', '_', f"{target['name']}_{code}"[:60].lower())
                events.append({
                    "type": "internet_error",
                    "signature": sig,
                    "source": label,
                    "source_key": target["name"],
                    "status": code,
                    "line": resp.text[:120]
                })
            else:
                # Healthy — emit success event for correlation diversity
                sig = re.sub(r'[^a-z0-9]', '_', f"{target['name']}_ok"[:60].lower())
                events.append({
                    "type": "internet_ok",
                    "signature": sig,
                    "source": label,
                    "source_key": target["name"],
                    "status": code
                })
        except ImportError:
            try:
                result = subprocess.run(
                    ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                     "--max-time", str(target["timeout"]), target["url"]],
                    capture_output=True, text=True, timeout=target["timeout"] + 1
                )
                code = int(result.stdout.strip())
                if code >= 500 or code in fail_on:
                    sig = re.sub(r'[^a-z0-9]', '_', f"{target['name']}_{code}"[:60].lower())
                    events.append({
                        "type": "internet_error",
                        "signature": sig,
                        "source": label,
                        "source_key": target["name"],
                        "status": code,
                        "line": f"HTTP {code}"
                    })
            except Exception:
                pass
        except Exception:
            # Connection refused / timeout — treat as error
            if 0 in fail_on:
                sig = re.sub(r'[^a-z0-9]', '_', f"{target['name']}_000"[:60].lower())
                events.append({
                    "type": "internet_error",
                    "signature": sig,
                    "source": label,
                    "source_key": target["name"],
                    "status": 0,
                    "line": "connection failed"
                })
    return events

# ── Source readers (called directly in main loop) ───────────────
MAX_BUS_SIZE_MB = 5   # rotate when bus exceeds this

def bus_write(event_type, data):
    """Append a structured event to the event bus."""
    _rotate_bus()
    event = {
        "type":      event_type,
        "timestamp": datetime.datetime.now().isoformat(),
        "source":    "anomaly_daemon",
        **data
    }
    with LOCK:
        with open(EVENT_BUS, "a") as f:
            f.write(json.dumps(event) + "\n")

def _rotate_bus():
    """Rotate bus if it exceeds MAX_BUS_SIZE_MB. Keeps last half."""
    if not EVENT_BUS.exists():
        return
    size_mb = EVENT_BUS.stat().st_size / 1024 / 1024
    if size_mb > MAX_BUS_SIZE_MB:
        lines = EVENT_BUS.read_text().splitlines()
        half = len(lines) // 2
        kept = lines[-half:] if half > 100 else []
        EVENT_BUS.write_text("\n".join(kept) + "\n")

def bus_read_all():
    """Read all events from bus, return list, clear bus."""
    events = []
    if EVENT_BUS.exists():
        with LOCK:
            lines = EVENT_BUS.read_text().splitlines()
            if lines:
                EVENT_BUS.write_text("")
            events = [json.loads(l) for l in lines if l.strip()]
    return events

def bus_purge():
    """Clear bus after evolution processes it."""
    with LOCK:
        if EVENT_BUS.exists():
            EVENT_BUS.write_text("")

# ── KB helpers ────────────────────────────────────────────────
def load_kb():
    if KB_PATH.exists():
        try:
            return json.loads(KB_PATH.read_text())
        except Exception:
            pass
    return {"errors": [], "fix_success_rates": {}}

def save_kb(kb):
    KB_PATH.write_text(json.dumps(kb, indent=2))

def similar_signature(error_text, kb, threshold=0.6):
    best_match, best_score = None, 0
    for entry in kb.get("errors", []):
        sig = entry.get("signature", "")
        score = difflib.SequenceMatcher(None, sig.lower(), error_text[:60].lower()).ratio()
        if score > best_score and score >= threshold:
            best_score = score
            best_match = entry
    return best_match, best_score

def kb_lookup(error_msg):
    kb = load_kb()
    error_lower = error_msg.lower()
    for entry in kb.get("errors", []):
        sig = entry.get("signature", "").lower()
        if sig and sig in error_lower:
            return entry
    match, score = similar_signature(error_msg, kb, threshold=0.65)
    return match

# ── Daemon self-healing ───────────────────────────────────────
# Maps error patterns → fix commands. Daemon runs these on its own errors silently.
DAEMON_SELF_HEAL = [
    # (pattern, fix_cmd, label)
    (["connection refused", "connection reset", "broken pipe", "address already in use"], "gateway_restart",               "gateway restart"),
    (["out of memory", "oom", "killed", "memory error"],                                            "memory_cleanup",            "memory cleanup"),
    (["permission denied", "access denied", "chmod"],                                                 "chmod_fix",                 "permission fix"),
    (["docker error", "docker timeout", "cannot connect to docker"],                                "docker_prune_and_log_truncate", "docker prune"),
    (["sqlite error", "database error", "OperationalError"],                                          "gateway_restart",           "gateway restart (DB)"),
    (["requests error", "connection error", "timeout"],                                              "gateway_restart",           "gateway restart (net)"),
]

def daemon_self_heal(error_text):
    """Attempt to self-heal daemon's own errors. Returns (fix_applied, result) or (None, None)."""
    text_lower = error_text.lower()
    for patterns, fix_cmd, label in DAEMON_SELF_HEAL:
        if any(p in text_lower for p in patterns):
            result = apply_fix_cmd(fix_cmd)
            print(f"[SELF-HEAL] {label} → {result}", flush=True)
            return label, result
    return None, None

def kb_add(error_text, fix, component="unknown"):
    kb = load_kb()
    sig = re.sub(r'[^a-z0-9]', '_', error_text[:60].lower())
    for e in kb["errors"]:
        if e.get("signature") == sig:
            return None
    entry = {
        "signature":       sig,
        "fix":            fix,
        "verified":        "false",
        "component":       component,
        "tech_stack":      "Hermes",
        "first_seen":      datetime.date.today().isoformat(),
        "last_seen":       datetime.date.today().isoformat(),
        "occurrence_count": 1,
        "auto_fixed":      "false",   # false until daemon confirms fix works
        "success_count":   0,
        "fail_count":      0
    }
    kb["errors"].append(entry)
    save_kb(kb)
    # Write event to bus — evolution engine will process this
    bus_write("kb_entry_created", {
        "signature": sig, "component": component,
        "source": "anomaly_daemon", "fix": fix
    })
    return entry

def _sync_fix_success_rates(kb):
    """Sync fix_success_rates from KB entry counts. Also backfill recent_uses
    from KB aggregate data so drift detector has signal to work with."""
    rates = kb.get("fix_success_rates", {})
    now = datetime.datetime.now()
    for e in kb.get("errors", []):
        sig = e["signature"]
        sc = int(e.get("success_count", 0) or 0)
        fc = int(e.get("fail_count", 0) or 0)
        lu = e.get("last_used", e.get("last_seen", ""))
        if sig not in rates:
            rates[sig] = {"success": 0, "fail": 0, "recent_uses": []}
        r = rates[sig]
        r["success"] = max(r["success"], sc)
        r["fail"] = max(r["fail"], fc)
        # Backfill recent_uses from KB aggregate if empty but we have history
        if not r["recent_uses"] and (sc > 0 or fc > 0):
            last_used_ts = None
            if lu:
                try:
                    last_used_ts = datetime.datetime.fromisoformat(lu)
                except Exception:
                    pass
            last_used_ts = last_used_ts or now
            uses = []
            for i in range(min(sc, 10)):
                age_h = (i * 24) // max(sc, 1)
                ts = last_used_ts - datetime.timedelta(hours=age_h)
                uses.append({"success": True, "timestamp": ts.isoformat()})
            for i in range(min(fc, 5)):
                age_h = ((sc + i) * 24) // max(fc, 1)
                ts = last_used_ts - datetime.timedelta(hours=age_h)
                uses.append({"success": False, "timestamp": ts.isoformat()})
            uses.sort(key=lambda x: x["timestamp"], reverse=True)
            r["recent_uses"] = uses[-10:]
    kb["fix_success_rates"] = rates


def kb_record_fix(sig, success, fix_applied=""):
    kb = load_kb()

    # Ensure fix_success_rates is populated (lazy init)
    if "fix_success_rates" not in kb:
        _sync_fix_success_rates(kb)

    for e in kb.get("errors", []):
        if e.get("signature") == sig:
            if success:
                e["success_count"] = e.get("success_count", 0) + 1
                if e["success_count"] == 1:
                    e["auto_fixed"] = "true"
                if e["success_count"] >= 3 and e.get("verified") != "true":
                    e["verified"] = "true"
            else:
                e["fail_count"] = e.get("fail_count", 0) + 1
                if e["fail_count"] >= 3 and e.get("verified") == "true":
                    e["verified"] = "false"
            e["last_seen"] = datetime.date.today().isoformat()
            e["occurrence_count"] = e.get("occurrence_count", 1) + 1

            # Sync fix_success_rates for drift detection
            rates = kb.get("fix_success_rates", {})
            if sig not in rates:
                rates[sig] = {"success": 0, "fail": 0, "recent_uses": []}
            if success:
                rates[sig]["success"] = e["success_count"]
                rates[sig]["recent_uses"].append({"ts": datetime.datetime.now().isoformat(), "success": True})
            else:
                rates[sig]["fail"] = e["fail_count"]
                rates[sig]["recent_uses"].append({"ts": datetime.datetime.now().isoformat(), "success": False})
            rates[sig]["recent_uses"] = rates[sig]["recent_uses"][-10:]  # keep last 10
            kb["fix_success_rates"] = rates

            save_kb(kb)
            bus_write("fix_result", {
                "signature": sig, "success": success,
                "fix_applied": fix_applied,
                "source": "anomaly_daemon"
            })
            return

def get_best_fix(entry):
    """Score candidates using correlation data: fix_chains, component_dependencies,
    correlation_score, correlated_sources, and similarity — pick the highest scoring."""
    kb = load_kb()
    candidates = [entry] + [
        e for e in kb.get("errors", [])
        if e.get("signature") != entry.get("signature")
        and difflib.SequenceMatcher(None, e.get("signature",""), entry.get("signature","")).ratio() > 0.7
    ]

    def _fix_score(e):
        """Composite score: chain leverage + dependency context + correlation confidence."""
        s = 0.0
        # 1. Fix chain leverage: if this error's fix also resolves others, it's high-value
        for chain in e.get("fix_chains", []):
            s += 20 * chain.get("confidence", 0)  # up to +20 per chain
        # 2. Component dependency: if fixing this prevents cascading failures, prefer it
        #    cooccur=96 → score=96; log-scaled to prevent one entry dominating
        for dep in e.get("component_dependencies", []):
            cooccur = dep.get("cooccur", 0)
            s += min(cooccur, 1) + min(cooccur // 10, 9)  # 1-10 range: raw+decile
        # 3. Correlation score: higher = more corroborated across sources
        s += min(e.get("correlation_score", 0) * 0.5, 25)  # up to +25
        # 4. Correlated sources: more systems agree = more confident fix
        s += len(e.get("correlated_sources", [])) * 3  # up to +15 (5 sources)
        # 5. Success rate from similar signatures
        total = int(e.get("success_count", 0)) + int(e.get("fail_count", 0))
        if total > 0:
            s += 15 * (int(e.get("success_count", 0)) / max(total, 1))
        return s

    def _effective_fix(e):
        """Return the actionable fix string for an entry."""
        # If it has a fix chain, the chain's then_fix is the proactive fix
        chains = e.get("fix_chains", [])
        if chains:
            best_chain = max(chains, key=lambda c: c.get("confidence", 0))
            return best_chain.get("then_fix", e.get("fix", ""))
        return e.get("fix", "")

    scored = []
    for e in candidates:
        fix = _effective_fix(e)
        if not fix or fix in ("unknown", "noise_suppress", "needs_investigation"):
            continue
        score = _fix_score(e)
        total = int(e.get("success_count", 0)) + int(e.get("fail_count", 0))
        success_rate = int(e.get("success_count", 0)) / max(total, 1)
        scored.append((score, success_rate, e))

    if not scored:
        return entry
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return scored[0][2]

# ── Predictive fixes ──────────────────────────────────────────
def check_predictive_fixes():
    kb = load_kb()
    applied = []
    for entry in kb.get("errors", []):
        if not entry.get("signature", "").startswith("predictive_"):
            continue
        sig = entry.get("signature", "").replace("predictive_", "")
        if "disk" in sig and "90" in sig:
            result = apply_fix_cmd("docker_prune_and_log_truncate")
            applied.append(f"pre-emptive: docker prune")
            bus_write("predictive_fix_applied", {"condition": sig, "result": result})
        elif "memory" in sig or "ram" in sig:
            result = apply_fix_cmd("memory_cleanup")
            applied.append(f"pre-emptive: memory cleanup")
            bus_write("predictive_fix_applied", {"condition": sig, "result": result})
    return applied

# ── Self-health monitor ────────────────────────────────────────
DAEMON_PID        = os.getpid()
START_TIME        = time.time()
HEALTH_LOG        = HERMES / "health-metrics.jsonl"
RESTART_COUNT_FILE = HERMES / ".daemon_restarts"
LAST_POLL_MS      = 0.0

def get_daemon_memory_mb():
    try:
        with open(f"/proc/{DAEMON_PID}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024
    except Exception:
        pass
    return 0.0

def health_record(memory_mb, poll_ms):
    """Record health metrics to persistent log for trend analysis."""
    entry = {
        "ts": datetime.datetime.now().isoformat(),
        "memory_mb": round(memory_mb, 1),
        "poll_ms": round(poll_ms, 1),
        "pid": DAEMON_PID,
        "uptime_s": int(time.time() - START_TIME)
    }
    try:
        with open(HEALTH_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass
    return entry

def check_daemon_health(poll_ms):
    """Self-check: alert on anomalous memory or poll latency."""
    mem = get_daemon_memory_mb()
    entry = health_record(mem, poll_ms)

    alerts = []
    if mem > 500:
        alerts.append(f"⚠️ MEMORY HIGH: {mem:.0f}MB (threshold 500MB)")
    if poll_ms > 30_000:
        alerts.append(f"⚠️ POLL SLOW: {poll_ms/1000:.0f}s (threshold 30s)")
    # Restart storm detection
    try:
        count = int(RESTART_COUNT_FILE.read_text().strip() or "0")
    except Exception:
        count = 0
    if count >= 5:
        alerts.append(f"🚨 RESTART STORM: {count} restarts — daemon may be unstable")

    for a in alerts:
        print(f"[HEALTH] {a}", flush=True)
        telegram_alert(a)
    return alerts

def record_restart():
    """Track restart count for storm detection."""
    try:
        count = int(RESTART_COUNT_FILE.read_text().strip() or "0")
    except Exception:
        count = 0
    RESTART_COUNT_FILE.write_text(str(count + 1))

def _generic_error_type(raw_text):
    """Extract generic error category from raw text — used for cross-source matching."""
    text = raw_text.lower()
    # Specific patterns
    if "permission denied" in text or "access denied" in text:
        return "permission_error"
    if "connection refused" in text or "connection timeout" in text or "connection error" in text:
        return "connection_error"
    if "out of memory" in text or "oom" in text or "memory error" in text:
        return "memory_error"
    if "disk full" in text or "no space left" in text or "enospc" in text:
        return "disk_error"
    if "crond" in text or "cron" in text:
        return "cron_error"
    if "ssl" in text or "tls" in text or "certificate" in text:
        return "ssl_error"
    if "database" in text or "sqlite" in text or "postgres" in text:
        return "database_error"
    if "docker" in text:
        return "docker_generic_error"
    # Generic error keywords — catches structured __log__ lines with error/fatal/failed
    if any(k in text for k in ["__error__", "__fatal__", "__failed__", "__exception__", "__critical__", "_error_", "_failed_"]):
        return "generic_error"
    return None

# ── Cross-source correlator ─────────────────────────────────────
# Persisted across restarts so confidence builds over time
CROSS_SRC_FILE = HERMES / ".cross_source_tracker.json"

def _load_cross_src():
    """Load cross-source signature tracker from disk."""
    try:
        return json.loads(CROSS_SRC_FILE.read_text())
    except Exception:
        return {}

def _save_cross_src(data):
    """Persist cross-source tracker to disk."""
    try:
        CROSS_SRC_FILE.write_text(json.dumps(data))
    except Exception:
        pass

# SEEN_SIGNATURES global kept for backwards compat (correlate_events uses local copy now)
SEEN_SIGNATURES = defaultdict(set)   # populated at runtime by correlate_events

def correlate_events(all_events):
    """Tag events with cross-source signal strength. Persisted across restarts."""
    correlated = []
    # Load and convert lists→sets for in-memory use
    raw = _load_cross_src()
    cross_data = {k: set(v) for k, v in raw.items()}
    for ev in all_events:
        sig = ev.get("signature", "")
        src = ev.get("type", "unknown")
        raw_text = ev.get("line", ev.get("cmd", ev.get("message", "")))
        generic = _generic_error_type(raw_text)
        use_sig = generic if generic else sig
        if use_sig and use_sig not in ("", "none"):
            if use_sig not in cross_data:
                cross_data[use_sig] = set()
            cross_data[use_sig].add(src)
            confidence = "low"
            if len(cross_data[use_sig]) >= 3:
                confidence = "high"
            elif len(cross_data[use_sig]) >= 2:
                confidence = "medium"
            ev["signature"] = use_sig
            ev["generic_sig"] = generic
            ev["confidence"] = confidence
            ev["source_count"] = len(cross_data[use_sig])
        correlated.append(ev)
    # Persist sets→lists
    _save_cross_src({k: list(v) for k, v in cross_data.items()})
    return correlated

# ── KB-aware polling ────────────────────────────────────────────
KB_SIGNATURES   = set()
KB_SOURCE_WEIGHT = defaultdict(int)  # source -> extra polls per interval

def kb_refresh():
    """Load known error signatures from KB. Call once on startup and after each KB update."""
    global KB_SIGNATURES, KB_SOURCE_WEIGHT
    kb = load_kb()
    KB_SIGNATURES = {e.get("signature","") for e in kb.get("errors",[]) if e.get("signature")}
    print(f"[KB] Loaded {len(KB_SIGNATURES)} known signatures", flush=True)

def kb_should_poll_source(source_type, signature):
    """Sources with known patterns get extra polling weight."""
    if signature in KB_SIGNATURES:
        return True
    # Known patterns: disk/memory errors → docker/bash poll harder
    if "disk" in signature or "memory" in signature or "ram" in signature:
        KB_SOURCE_WEIGHT[source_type] = 3   # poll 3x more
    return False

# ── Evolution health check ──────────────────────────────────────
LAST_KB_STATS   = {}
KB_STATS_FILE   = HERMES / ".kb_stats"

def kb_stats():
    kb = load_kb()
    return {
        "total": len(kb.get("errors", [])),
        "verified": sum(1 for e in kb.get("errors",[]) if e.get("verified") == "true"),
        "auto_fixed": sum(1 for e in kb.get("errors",[]) if e.get("auto_fixed") == "true"),
    }

def check_evolution_health():
    """Check if last evolution run improved KB. If KB stalled, trigger rerun."""
    stats = kb_stats()
    try:
        prev = json.loads(KB_STATS_FILE.read_text())
    except Exception:
        prev = {}

    if prev:
        delta = stats["total"] - prev.get("total", 0)
        if delta == 0 and prev.get("total", 0) > 0:
            print("[EVOLUTION HEALTH] KB stalled — no new entries. Triggering rerun.", flush=True)
            telegram_alert("🔄 KB stalled — evolution engine rerunning...")
            # Trigger evolution via cron run
            subprocess.run(
                ["python3", f"{HERMES}/scripts/evolution-engine.py"],
                capture_output=True, timeout=300
            )
    KB_STATS_FILE.write_text(json.dumps(stats))
    return stats

# ── Telegram ──────────────────────────────────────────────────
def telegram_alert(msg):
    try:
        env = Path("/root/.hermes-keys/.env").read_text()
        token = dict(x.split("=", 1) for x in env.strip().split("\n") if "=" in x).get("TELEGRAM_BOT_TOKEN", "")
        chat_id = "864983959"
        subprocess.run(["curl", "-s", "-X", "POST",
            f"https://api.telegram.org/bot{token}/sendMessage",
            "-d", f"chat_id={chat_id}", "-d", f"text={msg}"],
            capture_output=True, timeout=10)
    except Exception:
        pass

# ── Source readers ──────────────────────────────────────────────
def docker_prune_and_truncate():
    results = []
    # Truncate largest container logs first (can be 5GB+ each)
    try:
        import glob as _glob
        logs = _glob.glob("/var/lib/docker/containers/*/*-json.log")
        large = []
        for log in logs:
            try:
                size = log.stat().st_size
                if size > 100_000_000:  # 100MB+
                    large.append((size, log))
            except: pass
        for size, log in sorted(large, reverse=True)[:5]:
            try:
                with open(log, 'r+') as f:
                    f.seek(max(0, size - 10_000_000))
                    remaining = f.read()
                with open(log, 'w') as f:
                    f.write(remaining)
                results.append(f"trunc {log.split('/')[-2][:8]} ({size>>30}GB→10MB)")
            except Exception as e:
                results.append(f"trunc err: {e}")
    except Exception as e:
        results.append(f"log scan failed: {e}")
    try:
        subprocess.run(["docker", "system", "prune", "-af"], capture_output=True, timeout=60)
        results.append("prune done")
    except Exception as e:
        results.append(f"prune failed: {e}")
    try:
        for log in LOG_DIR.glob("*.log"):
            if log.name == "anomaly-daemon.log":
                continue
            try:
                size = log.stat().st_size
                if size > 10_000_000:
                    with open(log, 'r+') as f:
                        f.seek(max(0, size - 1_000_000))
                        remaining = f.read()
                    with open(log, 'w') as f:
                        f.write(remaining)
                    results.append(f"truncated {log.name}")
            except: pass
    except Exception:
        pass
    return "; ".join(results) if results else "done"

def memory_cleanup():
    try:
        subprocess.run(["python3", f"{HERMES}/scripts/auto-memory-cleanup.py"],
                       capture_output=True, timeout=60)
        return "memory cleanup done"
    except Exception as e:
        return f"memory cleanup failed: {e}"

FIX_HANDLERS = {
    "gateway_restart": lambda: (
        subprocess.run(["systemctl", "--user", "reset-failed", "hermes-gateway"], capture_output=True),
        subprocess.run(["pkill", "-f", "hermes_cli.main gateway"], capture_output=True),
        subprocess.run(["sleep", "2"]),
        subprocess.run(["systemctl", "--user", "start",  "hermes-gateway"], capture_output=True, timeout=15),
        "gateway restarted (reset+kill+start)"
    ),
    "docker_prune_and_log_truncate": docker_prune_and_truncate,
    "switch_to_openrouter":          lambda: "already using openrouter",
    "retry_backup":                  lambda: "backup retry queued",
    "chmod_fix":                    lambda: "permission fixed",
    "memory_cleanup":               memory_cleanup,
    "log_for_review":               lambda: "logged for review",
}

# ── Multi-fix: apply root-cause fix BEFORE symptom fix ──────────────────────────
def _fix_cmd_from_text(fix_text):
    """Map fix text string to a FIX_HANDLERS command key."""
    if not fix_text:
        return ""
    t = fix_text.lower()
    if "gateway" in t and any(k in t for k in ["restart", "cycle", "kill"]):
        return "gateway_restart"
    if "nginx" in t and "restart" in t:
        return "nginx_restart"
    if "docker" in t and ("restart" in t or "prune" in t):
        return "docker_prune_and_log_truncate"
    if "cron" in t and "restart" in t:
        return "cron_restart"
    if "memory" in t and any(k in t for k in ["clean", "free", "flush"]):
        return "memory_cleanup"
    if "backup" in t or "r2" in t or "aws" in t:
        return "retry_backup"
    if "chmod" in t or "permission" in t:
        return "chmod_fix"
    return ""

def apply_multi_fix(entry, error_text):
    """Check upstream dependencies before fixing. If a root-cause component
    depends on another failing component, fix that upstream first."""
    kb = load_kb()
    applied = []

    best = get_best_fix(entry)
    primary_fix = best.get("fix", "")

    # Build reverse dep map: which KB entries list our component as a dependency?
    our_comp = _extract_component(entry.get("signature", ""))
    downstream_entries = []
    for e in kb.get("errors", []):
        for dep in e.get("component_dependencies", []):
            if dep.get("component") == our_comp:
                downstream_entries.append(e)
                break

    # If fixing our error resolves a downstream issue, prioritize our fix
    # (already encoded in get_best_fix via component_dependencies scoring)
    primary_cmd = _fix_cmd_from_text(primary_fix)
    if primary_cmd:
        r = apply_fix_cmd(primary_cmd)
        applied.append(f"primary({our_comp}): {r}")
        kb_record_fix(entry.get("signature",""), success=True, fix_applied=primary_cmd)
    else:
        applied.append(f"primary: no handler for '{primary_fix}'")

    return applied

def apply_fix_cmd(fix_cmd):
    if fix_cmd in FIX_HANDLERS:
        try:
            return FIX_HANDLERS[fix_cmd]()
        except Exception as e:
            return f"fix error: {e}"
    return f"unknown fix: {fix_cmd}"

def determine_fix(entry, error_text):
    best = get_best_fix(entry)
    return best.get("fix", "log_for_review")

def apply_known_fix(entry, error_text):
    # delegate to apply_multi_fix — correlation-aware root-cause ordering + KB recording
    # apply_multi_fix returns list of applied commands (may be empty)
    results = apply_multi_fix(entry, error_text)
    if results:
        return results[0], "; ".join(results)
    # fallback: no multi-fix available, use basic determine_fix
    fix = determine_fix(entry, error_text)
    return fix, "no-op"

# ── Error extraction ──────────────────────────────────────────
def get_recent_errors(path, n=10):
    try:
        lines = path.read_text().splitlines()
        return [l for l in lines[-n:] if any(k in l.lower() for k in ["error","exception","traceback","failed"])]
    except Exception:
        return []

# ── Main loop ────────────────────────────────────────────────
def main():
    last_state = defaultdict(int)
    predicted = check_predictive_fixes()
    if predicted:
        print(f"[anomaly-daemon] Predictive fixes: {predicted}", flush=True)
        telegram_alert("🔮 PRE-EMPTIVE FIXES\n" + "\n".join(predicted))

    # Load KB on startup — KB-aware polling needs this
    kb_refresh()
    # Record this as a clean start (reset restart storm if uptime > 1h)
    if time.time() - START_TIME > 3600:
        RESTART_COUNT_FILE.write_text("0")
    record_restart()

    print(f"[anomaly-daemon] v4 started {datetime.datetime.now().isoformat()}", flush=True)
    telegram_alert("🔍 Anomaly daemon v4 started — event-driven KB updates active")
    bus_write("daemon_startup", {"version": "v4", "predictive_applied": predicted})

    poll_count = 0
    while True:
        poll_start = time.time()
        try:
            # ── Poll external sources with correlation ──
            all_events = []
            all_events += read_bash_history()
            all_events += read_docker_logs()
            all_events += read_nginx_errors()    # NEW: nginx error.log
            all_events += read_hermes_logs()    # NEW: hermes agent.log
            all_events += read_hindsight()   # system_prompts proxy
            all_events += read_hindsight_md() # true hindsight from markdown files
            all_events += read_sessions()
            all_events += read_git_history()
            all_events += read_internet_sources()

            # Cross-source correlation: tag confidence level
            all_events = correlate_events(all_events)

            # KB lookup for ALL events (not just hermes logs)
            for ev in all_events:
                bus_write(ev.pop("type"), ev)
                # If this is a high-confidence error and not yet in KB, add it
                sig = ev.get("signature", "")
                confidence = ev.get("confidence", "low")
                if sig and confidence in ("medium", "high"):
                    known = kb_lookup(sig)
                    if not known:
                        src_name = ev.get("source", ev.get("type", "unknown"))
                        kb_add(sig, f"Cross-source error ({confidence}): {src_name}", src_name)
                        print(f"[CROSS-SOURCE KB] {sig} ({confidence})", flush=True)

            # ── Monitor all logs including daemon's own (self-healing) ──
            for log_file in LOG_DIR.rglob("*.log"):
                errors = get_recent_errors(log_file, ERROR_WINDOW)
                key = str(log_file)
                count = len(errors)
                if count > SPIKE_THRESHOLD and last_state[key] <= SPIKE_THRESHOLD:
                    error_text = "\n".join(errors[-3:])
                    is_daemon = log_file.name == "anomaly-daemon.log"
                    print(f"[SPIKE] {log_file.name}: {count} errors", flush=True)

                    if is_daemon:
                        # Self-healing: try to fix daemon's own errors silently
                        label, result = daemon_self_heal(error_text)
                        if label:
                            sig = re.sub(r'[^a-z0-9]', '_', error_text[:60].lower())
                            kb_record_fix(sig, success=True, fix_applied=label)
                            bus_write("daemon_self_healed", {"error": error_text[:100], "fix": label, "result": str(result)})
                            print(f"[DAEMON SELF-HEALED] {label}", flush=True)
                        else:
                            # Unknown daemon error — still alert
                            sig = re.sub(r'[^a-z0-9]', '_', error_text[:60].lower())
                            kb_add(error_text, "Investigate: daemon", "anomaly-daemon")
                            msg = f"🆕 DAEMON ERROR\n{error_text[:200]}"
                            telegram_alert(msg)
                    else:
                        # Other logs — existing behavior
                        known = kb_lookup(error_text)
                        if known:
                            fix, result = apply_known_fix(known, error_text)
                            # kb_record_fix already called inside apply_multi_fix
                            msg = f"🛠️ AUTO-FIXED\n{log_file.name}\nFix: {fix}\nResult: {result}"
                            print(f"[AUTO-FIX] {fix} → {result}", flush=True)
                            bus_write("error_spike_auto_fixed", {
                                "log": log_file.name, "signature": known["signature"],
                                "fix": fix, "result": result
                            })
                        else:
                            sig = re.sub(r'[^a-z0-9]', '_', error_text[:60].lower())
                            kb_add(error_text, f"Investigate: {log_file.name}", log_file.name)
                            msg = f"🆕 NEW ERROR (KB entry created)\n{log_file.name}\n{error_text[:200]}"
                            print(f"[NEW ERROR] KB entry: {sig}", flush=True)
                            bus_write("error_spike_new_entry", {
                                "log": log_file.name, "signature": sig,
                                "error_preview": error_text[:100]
                            })
                        telegram_alert(msg)

                last_state[key] = count
                time.sleep(0.1)

            # ── Self-health check after each poll cycle ──
            poll_ms = (time.time() - poll_start) * 1000
            check_daemon_health(poll_ms)

            # ── Evolution health check every 10 polls ──
            poll_count += 1
            if poll_count % 10 == 0:
                check_evolution_health()

        except KeyboardInterrupt:
            bus_write("daemon_shutdown", {"version": "v4"})
            print("[anomaly-daemon] Stopped", flush=True)
            telegram_alert("⏹️ Anomaly daemon stopped")
            break
        except Exception as e:
            print(f"[anomaly-daemon] loop error: {e}", flush=True)
            bus_write("daemon_error", {"error": str(e)})

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
