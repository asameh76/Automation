#!/bin/bash
LOG=/tmp/gw-restart.log
H=/root/hermes-bot-v2/venv/bin/hermes
echo "=== $(date) restarting gateway ===" >> $LOG
$H gateway restart >> $LOG 2>&1
echo "=== done rc=$? ===" >> $LOG
