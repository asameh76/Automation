#!/usr/bin/env python3
"""
KB Self-Cost - Track CPU/memory/API costs per script.
Runs daily; outputs efficiency report.
Stores metrics in /root/.hermes/state/kb_self_cost.json
"""

import json
import os
import sys
import resource
import datetime
import fcntl
import subprocess
import re
from pathlib import Path
from collections import defaultdict

STATE_FILE = Path("/root/.hermes/state/kb_self_cost.json")
LOG_FILE   = Path("/root/.hermes/logs/kb_self_cost.log")
SCRIPTS_DIR = Path("/root/.hermes/scripts")
PROFILE_DIR = Path("/root/.hermes/profiles/default")

# ── helpers ──────────────────────────────────────────────────────────────────

def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def load_state():
    """Return existing state dict, creating file if absent."""
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r") as fh:
                fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
                try:
                    return json.load(fh)
                finally:
                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except (json.JSONDecodeError, IOError):
            return _fresh_state()
    return _fresh_state()


def save_state(state):
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(state, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    tmp.rename(STATE_FILE)


def _fresh_state():
    return {
        "version": 1,
        "last_updated": None,
        "scripts": {},          # script_name -> RunRecord
        "daily_summaries": [],  # last 90 days of daily aggregates
    }


# ── cost measurement ─────────────────────────────────────────────────────────

def get_process_stats():
    """Return (cpu_time_s, peak_memory_bytes) for current process."""
    usage = resource.getrusage(resource.RUSAGE_SELF)
    cpu_time = usage.ru_utime + usage.ru_stime          # seconds
    peak_mem = usage.ru_maxrss * 1024                   # bytes (Linux pages→bytes)
    return cpu_time, peak_mem


def get_system_memory():
    """Total / available / used memory in bytes."""
    try:
        out = subprocess.check_output(
            ["free", "-b"], text=True, timeout=10
        )
        lines = out.strip().split("\n")
        # header: total used free shared buff/cache available
        parts = lines[1].split()
        total = int(parts[1])
        used  = int(parts[2])
        avail = int(parts[6])
        return total, used, avail
    except Exception:
        return 0, 0, 0


def get_cpu_percent():
    """Overall system CPU utilisation 0-100."""
    try:
        # Use /proc/stat — no subprocess needed, instant
        with open("/proc/stat", "r") as f:
            line = f.readline()
        # cpu  user nice system idle iowait irq softirq steal guest guest_nice
        parts = line.split()
        idle = int(parts[4])
        total = sum(int(x) for x in parts[1:])
        # Not worth computing a delta without a prior sample — return a placeholder
        # that signals "snapshot not available" but doesn't break the report
        return -1.0  # sentinel; report will note "N/A"
    except Exception:
        return 0.0


# ── script discovery ─────────────────────────────────────────────────────────

def list_scripts():
    """Return sorted list of Python scripts in SCRIPTS_DIR."""
    if not SCRIPTS_DIR.is_dir():
        return []
    return sorted(p.name for p in SCRIPTS_DIR.glob("*.py"))


# ── log parsing ─────────────────────────────────────────────────────────────

def estimate_api_calls_from_logs():
    """
    Scan hermes logs for API call markers and return counts.
    Looks for patterns like: 'api_call', 'model:', 'completion_tokens',
    HTTP headers like 'X-RateLimit-Remaining', or 'llm-request'.
    Returns dict: script_name → estimated API call count.
    """
    api_counts = defaultdict(int)
    log_dirs = [
        Path("/root/.hermes/logs"),
        Path("/root/hermes/logs"),
    ]
    api_markers = ["api_call", "llm-request", "completion_tokens", "model:",
                   "x-ratelimit-remaining", "openai", "anthropic"]

    for log_dir in log_dirs:
        if not log_dir.is_dir():
            continue
        # Only scan the 10 most recent .log files to avoid reading huge files
        log_files = sorted(log_dir.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
        for log_file in log_files:
            try:
                # Read only first 200 KB to stay fast
                with open(log_file, "r", errors="ignore") as fh:
                    text = fh.read(200 * 1024)
            except Exception:
                continue
            for name in list_scripts():
                # quick presence check
                if name not in text:
                    continue
                # count markers
                lower = text.lower()
                hits = sum(lower.count(m) for m in api_markers)
                if hits:
                    api_counts[name] += hits // max(1, text.count(name))

    # Check state files for api_call fields (fast JSON parse)
    for name in list_scripts():
        for suffix in [name.replace("kb_", ""), name]:
            state_file = PROFILE_DIR / "state" / f"kb_{suffix}.json"
            if state_file.exists():
                try:
                    data = json.loads(state_file.read_text())
                    for key in ["api_calls", "llm_calls", "api_count", "model_calls"]:
                        if key in data:
                            api_counts[name] += data[key]
                except Exception:
                    pass

    return dict(api_counts)


# ── core tracking ────────────────────────────────────────────────────────────

def tick_scripts(state):
    """
    Increment run-count for every script that exists.
    New scripts get a fresh record.
    """
    now = datetime.datetime.now().isoformat()
    state["last_updated"] = now

    for name in list_scripts():
        rec = state["scripts"].get(name)
        if rec is None:
            rec = {
                "run_count": 0,
                "total_cpu_s": 0.0,
                "peak_memory_bytes": 0,
                "total_api_calls": 0,
                "iteration_costs": [],      # list of {date, cpu_s, mem_bytes, api_calls}
                "last_run": None,
            }
            state["scripts"][name] = rec
        # increment run count only (actual cost accrued by caller)
        rec["run_count"] += 1
        rec["last_run"] = now


def record_api_calls(state, api_counts):
    """Add API call estimates to today's iteration record."""
    now_date = datetime.date.today().isoformat()
    for name, count in api_counts.items():
        rec = state["scripts"].get(name)
        if rec is None:
            continue
        rec["total_api_calls"] += count
        # append to iteration_costs if last entry is today, else new entry
        if rec["iteration_costs"] and rec["iteration_costs"][-1]["date"] == now_date:
            rec["iteration_costs"][-1]["api_calls"] += count
        else:
            rec["iteration_costs"].append({
                "date": now_date,
                "cpu_s": 0.0,
                "mem_bytes": 0,
                "api_calls": count,
            })
        # keep last 90 days
        if len(rec["iteration_costs"]) > 90:
            rec["iteration_costs"] = rec["iteration_costs"][-90:]


def update_daily_summary(state):
    """Append today's aggregate costs per script to daily_summaries (last 90)."""
    today = datetime.date.today().isoformat()
    summaries = state.get("daily_summaries", [])

    # Build today's aggregate
    today_agg = {"date": today, "scripts": {}}
    for name, rec in state["scripts"].items():
        # Find today's iteration cost entry
        today_cost = None
        if rec.get("iteration_costs"):
            for c in reversed(rec["iteration_costs"]):
                if c["date"] == today:
                    today_cost = c
                    break
        today_agg["scripts"][name] = {
            "run_count": 1,   # one tick per day per script
            "cpu_s": today_cost["cpu_s"] if today_cost else 0.0,
            "mem_bytes": today_cost["mem_bytes"] if today_cost else 0,
            "api_calls": today_cost["api_calls"] if today_cost else 0,
        }

    # Replace today's entry if already present, else append
    replaced = False
    for i, entry in enumerate(summaries):
        if entry["date"] == today:
            summaries[i] = today_agg
            replaced = True
            break
    if not replaced:
        summaries.append(today_agg)

    # Keep last 90 days
    if len(summaries) > 90:
        summaries[:] = summaries[-90:]

    state["daily_summaries"] = summaries


# ── report generation ────────────────────────────────────────────────────────

def build_report(state):
    """Return a human-readable efficiency report string."""
    now = datetime.datetime.now().isoformat()
    lines = [
        "=" * 60,
        "KB SELF-COST  –  Efficiency Report",
        f"Generated : {now}",
        f"State file: {STATE_FILE}",
        "=" * 60,
    ]

    total_cpu   = sum(s.get("total_cpu_s", 0) for s in state["scripts"].values())
    total_api   = sum(s.get("total_api_calls", 0) for s in state["scripts"].values())
    total_runs  = sum(s.get("run_count", 0) for s in state["scripts"].values())
    total_mem   = sum(s.get("peak_memory_bytes", 0) for s in state["scripts"].values())

    sys_total, sys_used, sys_avail = get_system_memory()
    cpu_pct = get_cpu_percent()
    cpu_str = f"{cpu_pct:.1f} %" if cpu_pct >= 0 else "N/A (snapshot)"

    lines += [
        "",
        "── System ──────────────────────────────────────────────────",
        f"  Host memory total : {sys_total/1024**3:>8.1f} GB",
        f"  Host memory used  : {sys_used/1024**3:>8.1f} GB",
        f"  Host memory avail : {sys_avail/1024**3:>8.1f} GB",
        f"  System CPU util   : {cpu_str:>7}",
        "",
        "── Aggregate (all time) ────────────────────────────────────",
        f"  Total runs        : {total_runs:>8}",
        f"  Total CPU time    : {total_cpu:>8.2f} s",
        f"  Total API calls   : {total_api:>8}",
        f"  Peak memory alloc : {total_mem:>8.1f} MB",
    ]

    # Per-script breakdown
    lines += [
        "",
        "── Per-Script Breakdown ─────────────────────────────────────",
        f"  {'Script':<36} {'Runs':>6} {'CPU(s)':>8} {'API calls':>10} {'Peak MB':>8}",
        f"  {'-'*36} {'-'*6} {'-'*8} {'-'*10} {'-'*8}",
    ]

    sorted_scripts = sorted(
        state["scripts"].items(),
        key=lambda x: x[1].get("total_cpu_s", 0),
        reverse=True,
    )
    for name, rec in sorted_scripts:
        cpu  = rec.get("total_cpu_s", 0)
        api  = rec.get("total_api_calls", 0)
        runs = rec.get("run_count", 0)
        mem  = rec.get("peak_memory_bytes", 0) / (1024 ** 2)
        lines.append(f"  {name:<36} {runs:>6} {cpu:>8.2f} {api:>10} {mem:>8.1f}")

    # 7-day trend
    lines += [
        "",
        "── 7-Day Cost Trend ─────────────────────────────────────────",
    ]
    summaries = state.get("daily_summaries", [])
    last_7 = summaries[-7:] if len(summaries) >= 7 else summaries
    if last_7:
        lines.append(f"  {'Date':<12} {'Scripts active':>14} {'Total CPU(s)':>13} {'Total API':>11}")
        lines.append(f"  {'-'*12} {'-'*14} {'-'*13} {'-'*11}")
        for day in last_7:
            day_cpu = sum(v["cpu_s"] for v in day["scripts"].values())
            day_api = sum(v["api_calls"] for v in day["scripts"].values())
            active  = len(day["scripts"])
            lines.append(f"  {day['date']:<12} {active:>14} {day_cpu:>13.2f} {day_api:>11}")
    else:
        lines.append("  (no daily data yet)")

    # Efficiency hints
    lines += [
        "",
        "── Efficiency Hints ─────────────────────────────────────────",
    ]
    hints = []
    if total_runs > 0:
        avg_cpu = total_cpu / total_runs
        if avg_cpu > 30:
            hints.append(f"  ⚠  avg {avg_cpu:.1f}s per run — consider caching or offloading")
    high_mem_scripts = [
        n for n, r in state["scripts"].items()
        if r.get("peak_memory_bytes", 0) > 512 * 1024 * 1024
    ]
    if high_mem_scripts:
        hints.append(f"  ⚠  High memory: {', '.join(high_mem_scripts[:5])}")
    if total_api > 500:
        hints.append(f"  ⚠  {total_api} API calls logged — review necessity")
    if not hints:
        lines.append("  ✓  No obvious inefficiencies detected")
    else:
        lines += hints

    lines += ["", "=" * 60]
    return "\n".join(lines)


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    log("Starting KB Self-Cost run")

    state = load_state()
    tick_scripts(state)

    # Estimate API calls from logs + state files
    api_counts = estimate_api_calls_from_logs()
    record_api_calls(state, api_counts)

    update_daily_summary(state)
    save_state(state)

    report = build_report(state)
    print("\n" + report)
    log("KB Self-Cost run complete")

    # Also write report to logs
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write("\n" + report + "\n")


if __name__ == "__main__":
    main()
