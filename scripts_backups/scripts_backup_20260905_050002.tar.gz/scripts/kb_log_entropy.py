#!/usr/bin/env python3
"""
KB Log Entropy - Detect 'too quiet' periods.
"""

import json
import datetime
import fcntl
from pathlib import Path


ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
ENTROPY_FILE = Path("/root/.hermes/state/kb_log_entropy.json")
LOG_FILE = Path("/root/.hermes/logs/kb_log_entropy.log")

QUIET_THRESHOLD_HOURS = 6


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_errors():
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            return fh.readlines()
    except Exception:
        return []


def parse_timestamp(line):
    try:
        if line.startswith("["):
            ts_str = line[1 : line.find("]")]
            return datetime.datetime.fromisoformat(ts_str)
    except Exception:
        pass
    return None


def main():
    log("=== KB Log Entropy started ===")

    lines = read_errors()
    if not lines:
        log("No errors log found")
        return

    timestamps = []
    for line in lines:
        ts = parse_timestamp(line)
        if ts:
            timestamps.append(ts)

    if not timestamps:
        log("No parseable timestamps in errors log")
        return

    timestamps.sort()
    latest = timestamps[-1]
    now = datetime.datetime.now()
    hours_since_last = (now - latest).total_seconds() / 3600

    quiet_detected = hours_since_last >= QUIET_THRESHOLD_HOURS

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "last_error": latest.isoformat() if latest else None,
        "hours_since_last_error": round(hours_since_last, 2),
        "quiet_threshold_hours": QUIET_THRESHOLD_HOURS,
        "quiet_detected": quiet_detected,
        "total_errors_logged": len(timestamps),
    }

    ENTROPY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(ENTROPY_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    if quiet_detected:
        log(f"ALERT: System has been quiet for {hours_since_last:.1f} hours")

    log(f"=== KB Log Entropy: {hours_since_last:.1f}h since last error ===")


if __name__ == "__main__":
    main()
