#!/usr/bin/env python3
"""
KB Dependency - Dependency graph.
"""

import json
import subprocess
import datetime
import fcntl
from collections import defaultdict
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
DEP_FILE = Path("/root/.hermes/state/kb_dependency.json")
LOG_FILE = Path("/root/.hermes/logs/kb_dependency.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def get_docker_deps():
    """Get docker container dependencies."""
    deps = defaultdict(list)
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        containers = result.stdout.strip().split("\n")
        for c in containers:
            if c:
                deps[c] = []
    except Exception:
        pass
    return deps


def main():
    log("=== KB Dependency started ===")

    docker_deps = get_docker_deps()

    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": []}

    # Build dependency graph from KB entries
    graph = defaultdict(list)
    for entry in kb.get("knowledge_base", []):
        error = entry.get("error", "")
        tags = entry.get("tags", [])
        if "docker" in tags:
            graph["docker"].append(error[:60])
        if "nginx" in tags:
            graph["nginx"].append(error[:60])

    # Merge docker deps
    for container, deps in docker_deps.items():
        graph[container] = deps

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "graph": dict(graph),
        "nodes": list(graph.keys()),
    }

    DEP_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DEP_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Dependency: {len(graph)} nodes ===")


if __name__ == "__main__":
    main()
