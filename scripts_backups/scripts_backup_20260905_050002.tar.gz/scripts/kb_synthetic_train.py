#!/usr/bin/env python3
"""
KB Synthetic Train - Synthetic training data.
"""

import json
import random
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
SYNTH_FILE = Path("/root/.hermes/state/kb_synthetic_train.json")
LOG_FILE = Path("/root/.hermes/logs/kb_synthetic_train.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


ERROR_TEMPLATES = [
    "Connection refused: {host}:{port}",
    "Timeout waiting for {service}",
    "Out of memory in {container}",
    "Disk full on {mount}",
    "Failed to restart {service} after update",
    "SSL certificate expired for {domain}",
    "Database connection pool exhausted",
    "Rate limit exceeded for API {api}",
]

FIX_TEMPLATES = [
    "Restart {service}",
    "Increase {resource} limit",
    "Clear cache and retry",
    "Scale up {component}",
    "Update configuration",
]


def generate_synthetic_entry():
    error_template = random.choice(ERROR_TEMPLATES)
    error = error_template.format(
        host=random.choice(["api", "db", "cache", "worker"]),
        port=random.choice([80, 443, 3000, 5432, 6379]),
        service=random.choice(["nginx", "docker", "postiz", "temporal"]),
        container=random.choice(["app", "worker", "scheduler"]),
        mount=random.choice(["/data", "/var/log", "/tmp"]),
        domain=random.choice(["api.example.com", "app.example.com"]),
        api=random.choice(["/v1/users", "/v1/orders", "/v1/payments"]),
        resource=random.choice(["memory", "CPU", "disk"]),
        component=random.choice(["workers", "instances", "replicas"]),
    )
    return {
        "error": error,
        "status": random.choice(["new", "investigate", "verified"]),
        "fixes": [
            {
                "description": random.choice(FIX_TEMPLATES).format(
                    service=random.choice(["nginx", "docker", "postiz"]),
                    resource=random.choice(["memory", "CPU"]),
                    component=random.choice(["workers", "instances"]),
                ),
                "applied": random.choice([True, False]),
            }
        ],
        "tags": random.sample(["docker", "nginx", "api", "database", "cache", "docker"], k=2),
        "created_at": datetime.datetime.now().isoformat(),
    }


def main():
    log("=== KB Synthetic Train started ===")

    count = 50
    synthetic = [generate_synthetic_entry() for _ in range(count)]

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "count": count,
        "synthetic_entries": synthetic,
    }

    SYNTH_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SYNTH_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Synthetic Train: generated {count} entries ===")


if __name__ == "__main__":
    main()
