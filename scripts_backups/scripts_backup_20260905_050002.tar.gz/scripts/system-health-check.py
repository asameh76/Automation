#!/usr/bin/env python3
"""Unified system health check + auto-fix — runs 4x/day, silent when healthy."""
import subprocess, sys, os, shutil

def run(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def fix(name, action_fn):
    """Run a fix function; return (fixed, message)."""
    try:
        result = action_fn()
        return True, result
    except Exception as e:
        return False, str(e)

issues = []
fixed = []

# ── 1. DISK ────────────────────────────────────────────────
r = run("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'")
disk_pct = int(r.stdout.strip())

if disk_pct > 90:
    # Truncate largest docker container logs first (can be 5GB+ each)
    try:
        result = run("du -h /var/lib/docker/containers/*/*-json.log 2>/dev/null | sort -rh | head -5")
        for line in result.stdout.strip().splitlines():
            size, path = line.split(maxsplit=1)
            path = path.strip()
            if size.endswith("G") and float(size[:-1]) >= 0.5:
                run(f"truncate -s 10M {path} 2>/dev/null")
    except Exception:
        pass

    # Then clean docker orphans
    run("docker system prune -f 2>/dev/null")

    # Truncate large rotated logs if disk still high
    for log in ["/root/.hermes/logs/agent.log.1",
                "/root/.hermes/logs/agent.log.2",
                "/root/.hermes/logs/agent.log.3",
                "/root/.hermes/logs/gateway.log",
                "/root/.hermes/logs/gateway-exit-diag.log"]:
        if os.path.exists(log) and os.path.getsize(log) > 1024*1024:
            open(log, 'w').close()

    # Re-check
    r = run("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'")
    disk_pct = int(r.stdout.strip())
    if disk_pct > 90:
        issues.append(f"DISK {disk_pct}%")
    else:
        fixed.append(f"DISK freed to {disk_pct}%")

# ── 2. MEMORY ─────────────────────────────────────────────
r = run("free | awk 'NR==2 {print int($3/$2*100)}'")
mem_pct = int(r.stdout.strip())
if mem_pct > 90:
    issues.append(f"MEM {mem_pct}%")

# ── 3. BACKUP FILE ────────────────────────────────────────
backup_path = "/root/backups/"
if os.path.exists(backup_path):
    files = sorted([f for f in os.listdir(backup_path) if f.startswith("root_backup_")])
    if not files:
        # Trigger a local backup
        os.makedirs(backup_path, exist_ok=True)
        ts = subprocess.run("date +%Y%m%d_%H%M%S", shell=True, capture_output=True, text=True).stdout.strip()
        dst = os.path.join(backup_path, f"root_backup_{ts}.tar.gz")
        r = run(f"tar czf {dst} /root/.hermes /root/.hermes-keys /root/scripts /root/skills 2>/dev/null")
        if os.path.exists(dst) and os.path.getsize(dst) > 1000:
            fixed.append("BACKUP created")
        else:
            issues.append("BACKUP failed")
    else:
        latest = files[-1]
        size = os.path.getsize(os.path.join(backup_path, latest))
        if size < 1000:
            issues.append(f"BACKUP_TINY ({size}B)")
else:
    issues.append("NO_BACKUP")

# ── 4. GATEWAY ────────────────────────────────────────────
gw = run("systemctl --user is-active hermes-gateway")
if gw.returncode != 0:
    # Try restart
    r = run("systemctl --user start hermes-gateway 2>/dev/null")
    gw = run("systemctl --user is-active hermes-gateway")
    if gw.returncode != 0:
        issues.append("GATEWAY_DOWN")
    else:
        fixed.append("GATEWAY restarted")

# ── 4b. DELETED SERVICE BINARIES ──────────────────────────
# Check hermes-related systemd services for missing binaries
# Only targets user-facing/hermes services, not kernel internals
HERMES_SVCS = [
    "hermes-gateway.service",
    "hermes-agent.service",
    "hermes.service",
]
for svc in HERMES_SVCS:
    exec_path = run(f"systemctl show {svc} -p ExecStart --value 2>/dev/null").stdout.strip()
    if not exec_path:
        continue
    # Extract the binary path (handle path= syntax and plain paths)
    import re
    m = re.search(r'path=([^\s]+)', exec_path)
    candidate = m.group(1) if m else exec_path.lstrip("*/").split()[0]
    if candidate.startswith('~'):
        candidate = os.path.expanduser(candidate)
    if candidate and not os.path.exists(candidate):
        status = run(f"systemctl is-active {svc} 2>/dev/null").stdout.strip()
        if status == 'active':
            issues.append(f"DELETED_BIN:{svc}")
        else:
            run("systemctl daemon-reload 2>/dev/null")
            fixed.append(f"DELETED_BIN:{svc} (reloaded)")

# ── 4c. FAILED SYSTEMD UNITS ───────────────────────────────
# Detect failed units; auto-disable if permanently dead hermes leftovers
r_failed = run("systemctl --failed --no-pager 2>/dev/null")
for line in r_failed.stdout.strip().splitlines():
    if not line.startswith('● '):
        continue
    failed_unit = line[1:].strip().split()[0]  # strip ● and get unit name
    # Ignore kernel/cloud/vendor internals
    if any(x in failed_unit for x in ['cloud-init', 'snapd', 'systemd-', 'dbus', 'getty', 'rsyslog', 'ufw', 'polkit']):
        continue
    # Auto-disable known dead/obsolete services
    DEAD_SVCS = ('hermes.service', 'caddy.service', 'kb-auto-research.service', 'kb-auto-research.path')
    if failed_unit in DEAD_SVCS:
        run(f"systemctl disable {failed_unit} 2>/dev/null")
        run(f"systemctl stop {failed_unit} 2>/dev/null")
        fixed.append(f"DISABLED:{failed_unit}")
    else:
        issues.append(f"UNIT_FAILED:{failed_unit}")

# ── 5. R2 ────────────────────────────────────────────────
r2 = run("timeout 10 rclone ls cloudflare_hermes:gem-gyms76/backups/latest/scripts/ 2>&1")
if "ERROR" in r2.stdout or r2.returncode != 0:
    # Try running the backup script to re-verify R2 connectivity
    br = run("bash /root/.hermes/scripts/full-r2-backup.sh 2>&1")
    if br.returncode != 0:
        issues.append("R2_UNREACHABLE")
    else:
        fixed.append("R2 reconnected")

# ── REPORT ────────────────────────────────────────────────
if fixed and not issues:
    print("FIXED: " + " | ".join(fixed))
    sys.exit(0)
elif issues:
    print("ISSUES: " + " | ".join(issues) + (" | FIXED: " + " | ".join(fixed) if fixed else ""))
    sys.exit(1)
else:
    print(f"OK: disk={disk_pct}% mem={mem_pct}%")
    sys.exit(0)
