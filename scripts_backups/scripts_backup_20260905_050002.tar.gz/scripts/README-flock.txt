#!/bin/bash
# flock wrapper - prevents overlapping cron runs
# Usage: flock -n /tmp/lock-X /path/script.sh
exec 9>/tmp/lock-daily-article
flock -n 9 || { echo "$(date) [$0] already running, skipping" >> /root/cron-alerts.log; exit 1; }
