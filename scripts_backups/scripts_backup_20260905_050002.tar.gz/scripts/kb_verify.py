#!/usr/bin/env python3
"""
KB Verify - Verification loop.
Promotes investigate->verified entries based on evidence.
Reads errors.log and KB.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
VERIFY_FILE = Path("/root/.hermes/state/kb_verify.json")
LOG_FILE = Path("/root/.hermes/logs/kb_verify.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_errors():
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            return fh.readlines()
    except Exception:
        return []


def promote_entry(entry, errors):
    """Check if entry should be promoted from investigate to verified."""
    error_pattern = entry.get("error", "").lower()
    if not error_pattern:
        return False

    # Count occurrences in errors
    count = 0
    for line in errors:
        if error_pattern in line.lower():
            count += 1

    fixes = entry.get("fixes", [])
    has_fixes = len(fixes) > 0
    has_evidence = any(f.get("evidence") for f in fixes)
    applied_count = sum(1 for f in fixes if f.get("applied"))

    # Promote if: has fixes + evidence + applied or seen multiple times
    if has_fixes and has_evidence and (applied_count > 0 or count >= 2):
        return True
    return False


def main():
    log("=== KB Verify started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    errors = read_errors()
    entries = kb.get("knowledge_base", [])

    promoted = 0
    for entry in entries:
        if entry.get("status") == "investigate":
            if promote_entry(entry, errors):
                entry["status"] = "verified"
                entry["verified_at"] = datetime.datetime.now().isoformat()
                promoted += 1
                log(f"Promoted: {entry.get('error', '')[:60]}")

    write_kb(kb)

    verify_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "entries_checked": len(entries),
        "promoted": promoted,
    }

    VERIFY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(VERIFY_FILE, "w") as fh:
        json.dump(verify_state, fh, indent=2)

    log(f"=== KB Verify: promoted {promoted} entries ===")


if __name__ == "__main__":
    main()
