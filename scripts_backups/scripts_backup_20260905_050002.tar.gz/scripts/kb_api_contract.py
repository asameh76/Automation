#!/usr/bin/env python3
"""Monitor API contract / config drift from known-good baseline."""
import json, os, hashlib, subprocess
from datetime import datetime

KB_PATH = "/root/.hermes/error-knowledge-base.json"
STATE_DIR = "/root/.hermes/state"
BASELINE_FILE = f"{STATE_DIR}/config_baseline.json"

WATCH_PATHS = [
    "/root/.hermes/config.yaml",
    "/root/.hermes/.env",
    "/root/.hermes/crontab",
    "/root/.hermes/.hermes-keys/.env",
]

def file_hash(path):
    try:
        with open(path) as f:
            return hashlib.md5(f.read().encode()).hexdigest()
    except Exception:
        return None

def load_baseline():
    try:
        with open(BASELINE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}

def main():
    try:
        with open(KB_PATH) as f:
            kb = json.load(f)
    except Exception:
        kb = {"errors": []}
    errors = kb.get("errors", [])
    existing_sigs = {e.get("signature", "") for e in errors}

    baseline = load_baseline()
    drift = []
    for path in WATCH_PATHS:
        if not os.path.exists(path):
            continue
        h = file_hash(path)
        if not h:
            continue
        name = os.path.basename(path)
        if name not in baseline:
            baseline[name] = h
            drift.append(f"NEW: {path} ({h})")
        elif baseline[name] != h:
            drift.append(f"CHANGED: {path} ({baseline[name]} -> {h})")

    os.makedirs(STATE_DIR, exist_ok=True)
    with open(BASELINE_FILE, 'w') as f:
        json.dump(baseline, f, indent=2)

    if drift:
        print("DRIFT: " + " | ".join(drift))
    else:
        print("OK: config baseline stable")

if __name__ == "__main__":
    main()
