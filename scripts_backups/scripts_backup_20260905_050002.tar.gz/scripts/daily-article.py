#!/usr/bin/env python3
"""Gem Gyms Daily Article Generator - with autonomous self-review loop.
Self-review: reads article log, extracts lessons, injects improvements into next article.
"""
import json, os, re, subprocess, sys, datetime

WP_USER = "gemgyms"
WP_PASS = "R6JW SoIa Gqoj E39u 6wgh w9mo"
API = "https://gemgyms.com/wp-json/wp/v2/posts"
USED_FILE = "/root/used_topics.txt"
LOG = "/root/article-log.txt"
KEY_FILE = "/root/.hermes-keys/.env"
REVIEW_FILE = "/root/performance-review.json"
MEMORY_FILE = "/root/article-memory.json"  # stores last N articles for cluster analysis

TOPICS = [
    ("progressive-overload", "Progressive Overload Explained: The Science Behind Every PR",
     "progressive overload,strength training,muscle growth"),
    ("protein-timing", "Protein Timing: Myths, Facts & What Actually Matters for Muscle Growth",
     "protein timing,whey protein,muscle protein synthesis"),
    ("kettlebell-exercises", "15 Best Kettlebell Exercises for Full-Body Strength & Fat Loss",
     "kettlebell exercises,kettlebell workout,kettlebell fat loss"),
    ("home-gym-under-500", "Build a Complete Home Gym Under $500: The Smart Shopper's Guide",
     "budget home gym,cheap home gym equipment,affordable home gym"),
    ("zone-2-cardio", "Zone 2 Cardio: Why Every Athlete Needs It (And How to Do It Right)",
     "zone 2 cardio,aerobic base,cardio for lifters"),
    ("skinny-to-strong", "From Skinny to Strong: A Beginner's 12-Week Muscle Building Program",
     "beginner muscle building,12 week program,skinny to strong"),
    ("creatine-guide", "The Complete Creatine Guide: Types, Dosing, Loading & Side Effects",
     "creatine monohydrate,creatine dosage,creatine benefits"),
    ("mobility-routine", "The 10-Minute Daily Mobility Routine That Fixes Desk Job Damage",
     "mobility routine,desk stretches,hip mobility"),
    ("deadlift-form", "Deadlift Form Fix: 7 Mistakes Killing Your Back (And How to Fix Them)",
     "deadlift form,deadlift mistakes,how to deadlift"),
    ("fasting-lifting", "Intermittent Fasting + Lifting: How to Make It Work (Science-Based)",
     "intermittent fasting,fasting and muscle,fasted training"),
    ("pull-up-progression", "Zero to 10 Pull-Ups: The Complete Progression System",
     "pull up progression,how to do pull ups,pull up training"),
    ("sleep-and-gains", "Sleep & Gains: Why 8 Hours Is Your Best Legal Performance Enhancer",
     "sleep and muscle growth,sleep recovery,sleep testosterone"),
    ("resistance-bands", "Full-Body Resistance Band Workout: Build Muscle Without Weights",
     "resistance band workout,bands muscle building,band exercises"),
    ("pre-workout-truth", "Pre-Workout Supplements: What Works, What's Waste, What's Dangerous",
     "pre workout supplements,best pre workout,caffeine pre workout"),
    ("fat-loss-plateau", "Fat Loss Plateau? Here's the Science of Breaking Through",
     "fat loss plateau,weight loss plateau,metabolic adaptation"),
    ("home-cable-machine", "Best Home Cable Machines 2024: Budget to Premium Reviewed",
     "home cable machine,cable machine home gym,functional trainer"),
    ("deload-week", "Deload Weeks: When to Take One & How to Do It Right",
     "deload week,recovery week,overtraining"),
    ("grip-strength", "Grip Strength Guide: Why It Predicts Longevity & How to Train It",
     "grip strength,forearm training,grip training"),
    ("meal-prep-lifters", "Meal Prep for Lifters: 5 Days of Food in 2 Hours",
     "bodybuilding meal prep,fitness meal prep,high protein meals"),
    ("bench-press-plateau", "Bench Press Stuck? 9 Science-Backed Ways to Break Your Plateau",
     "bench press plateau,increase bench press,bench press tips"),
]

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG, "a") as f:
        f.write(line + "\n")

# ─── SELF-REVIEW LOOP ────────────────────────────────────────────────────────

def load_memory():
    """Load last N article records for cross-article pattern learning."""
    try:
        with open(MEMORY_FILE) as f:
            try:
                try:
                    return json.load(f)
                except Exception:
                    return None
            except Exception:
                return None
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_memory(memory):
    """Keep last 10 articles for cluster/pattern analysis."""
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory[-10:], f, indent=2)

def analyze_log():
    """Extract patterns from article log: wins, failures, model quality."""
    if not os.path.exists(LOG):
        return {}
    entries = []
    with open(LOG) as f:
        for line in f:
            m = re.search(r"\[([\d-]+_[\d:]+)\] (.+)", line)
            if m:
                entries.append({"ts": m.group(1), "msg": m.group(2)})

    # Count what worked / failed
    models_used = [e["msg"] for e in entries if "via" in e["msg"]]
    failures = [e["msg"] for e in entries if "weak/failed" in e["msg"] or "ERROR" in e["msg"]]
    successes = [e["msg"] for e in entries if "SUCCESS" in e["msg"]]

    return {
        "total_runs": len(entries),
        "successes": len(successes),
        "failures": len(failures),
        "models_used": models_used[-5:],  # last 5
        "lessons": build_lessons(successes, failures),
    }

def build_lessons(successes, failures):
    """Build natural-language improvement instructions for next article."""
    lessons = []

    # If we see model patterns, bias toward the reliable ones
    if len(successes) > len(failures):
        lessons.append(
            "CONTINUE what is working: articles that published successfully had "
            "clear structure, specific numbers, and actionable takeaways. "
            "Emphasize these qualities."
        )

    if len(failures) > 0:
        lessons.append(
            "AVOID known failure modes: articles that were rejected or empty had "
            "vague intros, no data citations, and generic conclusions. "
            "Start with a hook stat, cite one study or data point, "
            "and end with a specific call-to-action — not generic advice."
        )

    # Pattern: long titles with numbers perform better (bench press plateau, 15 best...)
    lessons.append(
        "PREFERENCE: titles with numbers (e.g. '9 ways', '5 steps') and "
        "specificity (product names, rep ranges, dollar amounts) outperform "
        "generic titles. Use exact figures throughout the article."
    )

    # Pattern: articles with tables and FAQ sections rank better
    lessons.append(
        "MANDATORY: include at least one data table AND an FAQ section with "
        "3-4 real questions (scraped from 'People Also Ask'). "
        "These directly feed Rich Snippets and increase CTR."
    )

    # Cluster signal: if a keyword topic was already written, go deeper not wider
    lessons.append(
        "DEPTH RULE: if a related article already exists on gemgyms.com, "
        "do NOT repeat the same advice. Add a new angle: "
        "comparison table, expert quote, case study, or contrarian take. "
        "Duplicated content dilutes rankings."
    )

    return lessons

def build_review_note(lessons):
    """Format lessons into a single paragraph for the generate() prompt."""
    if not lessons:
        return ""
    header = "ARTICLES REVIEW — SELF-IMPROVEMENT LESSONS (apply these):\n"
    body = "\n".join(f"- {l}" for l in lessons)
    return f"\n\n{header}{body}\n"

def fetch_last_published_id():
    """Get the most recently published article URL for internal linking."""
    r = subprocess.run(
        ["curl", "-s", "-X", "GET",
         f"-u", f"{WP_USER}:{WP_PASS}",
         f"{API}?status=publish&per_page=1&orderby=date&order=desc"],
        capture_output=True, text=True, timeout=30
    )
    try:
        posts = json.loads(r.stdout)
        if posts:
            return posts[0].get("link", ""), posts[0].get("slug", "")
    except Exception:
        pass
    return "", ""

def record_article_memory(key, title, word_count, model_used):
    """Save this article to memory for next run's cluster analysis."""
    memory = load_memory()
    memory.append({
        "key": key,
        "title": title,
        "word_count": word_count,
        "model": model_used,
        "published": datetime.datetime.now().isoformat(),
    })
    save_memory(memory)

# ──────────────────────────────────────────────────────────────────────────────

def get_key():
    with open(KEY_FILE) as f:
        for line in f:
            if line.startswith("OPENROUTER_API_KEY="):
                return line.strip().split("=", 1)[1]
    raise RuntimeError("no OPENROUTER_API_KEY")

def pick_topic():
    try:
        used = set(open(USED_FILE).read().split())
    except FileNotFoundError:
        used = set()
    for key, title, kws in TOPICS:
        if key not in used:
            return key, title, kws
    # cycle reset
    open(USED_FILE, "w").close()
    return TOPICS[0]

def generate(title, keywords):
    import requests, time
    kw = keywords.split(",")
    last_url, last_slug = fetch_last_published_id()

    review_data = analyze_log()
    review_note = build_review_note(review_data["lessons"])

    system_prompt = """You are an expert SEO content writer for Gem Gyms (gemgyms.com), a fitness equipment store. Write comprehensive, science-backed fitness articles in raw WordPress block-editor HTML."""

    user_prompt = f"""Write a comprehensive SEO-optimized fitness article in HTML.

TITLE: {title}
PRIMARY KEYWORD: {kw[0]}
SECONDARY KEYWORDS: {', '.join(kw[1:3])}
{review_note}
REQUIREMENTS:
- 1000-1500 words
- Primary keyword in title, meta description, first 100 words
- Clear H2/H3 hierarchy with WordPress block editor comments (<!-- wp:heading --> etc.)
- Bullet points and at least one data table (comparison or ranked list)
- FAQ section at end with 3-4 questions sourced from 'People Also Ask' — these feed Rich Snippets
- Actionable, science-backed, no fluff
- Brand voice: expert, encouraging, no-nonsense
- Internal link to last article: {last_url}
- Natural mention of Gem Gyms (gemgyms.com) with 1-2 internal links to relevant product pages

Output ONLY raw WordPress block-editor HTML. No markdown fences, no explanation."""

    api_key = get_key()
    for attempt in range(1, 4):
        try:
            resp = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://gemgyms.com",
                    "X-Title": "Gem Gyms Daily Article",
                },
                json={
                    "model": "anthropic/claude-3-haiku",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                    "max_tokens": 2000,
                },
                timeout=120,
            )
            data = resp.json()
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            if content and len(content) > 500:
                log("generated via claude-3-haiku (OpenRouter free)")
                return content
        except Exception as e:
            log(f"attempt {attempt} error: {e}")
        log(f"attempt {attempt} weak/failed")
        time.sleep(15)
    return None

def strip_tags(html):
    return re.sub(r"<[^>]*>", "", html)

def main():
    key, title, keywords = pick_topic()
    log(f"Publishing '{title}'")
    content = generate(title, keywords)
    if not content:
        log("ERROR: content generation failed after 3 attempts")
        sys.exit(1)

    meta = strip_tags(content)[:155].strip()
    slug = key
    kw_primary = keywords.split(",")[0]
    payload = {
        "title": title,
        "slug": slug,
        "content": content,
        "status": "publish",
        "excerpt": meta,
        "meta": {
            "_rank_math_focus_keyword": kw_primary,
            "_rank_math_description": meta,
            "_rank_math_title": title + " | Gem Gyms",
            "_rank_math_schema_type": "Article",
            "_rank_math_rich_snippet": "article",
        },
    }
    r = subprocess.run(
        ["curl", "-s", "-X", "POST", "-u", f"{WP_USER}:{WP_PASS}",
         "-H", "Content-Type: application/json",
         "-d", json.dumps(payload), API],
        capture_output=True, text=True, timeout=120)
    try:
        data = json.loads(r.stdout)
    except Exception:
        data = {}
    if data.get("id"):
        log(f"SUCCESS: Post ID {data['id']} published -> {data.get('link')}")
        with open(USED_FILE, "a") as f:
            f.write(key + "\n")
    else:
        log(f"FAILED to publish: {r.stdout[:400]}")
        sys.exit(1)

if __name__ == "__main__":
    main()
