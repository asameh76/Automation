#!/usr/bin/env python3
"""
KB Safety - Emergency Stop + Audit.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
SAFETY_FILE = Path("/root/.hermes/state/kb_safety.json")
EMERGENCY_FILE = Path("/root/.hermes/.kb_emergency_stop")
LOG_FILE = Path("/root/.hermes/logs/kb_safety.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def is_emergency_stop():
    """Check if emergency stop is active."""
    return EMERGENCY_FILE.exists()


def activate_emergency_stop():
    """Activate emergency stop."""
    EMERGENCY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(EMERGENCY_FILE, "w") as fh:
        fh.write(datetime.datetime.now().isoformat())
    log("EMERGENCY STOP ACTIVATED")


def main():
    log("=== KB Safety check started ===")

    safety_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "emergency_stop": is_emergency_stop(),
    }

    SAFETY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SAFETY_FILE, "w") as fh:
        json.dump(safety_state, fh, indent=2)

    if is_emergency_stop():
        log("Emergency stop is ACTIVE")
    else:
        log("System is running normally")


if __name__ == "__main__":
    main()
