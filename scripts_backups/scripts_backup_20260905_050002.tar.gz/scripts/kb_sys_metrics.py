#!/usr/bin/env python3
"""
KB Sys Metrics - System metrics ingestion.
"""

import json
import subprocess
import datetime
import fcntl
from pathlib import Path


METRICS_FILE = Path("/root/.hermes/state/kb_sys_metrics.json")
LOG_FILE = Path("/root/.hermes/logs/kb_sys_metrics.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def get_disk_usage():
    try:
        result = subprocess.run(
            ["df", "-h", "/"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        parts = result.stdout.strip().split("\n")[-1].split()
        if len(parts) >= 6:
            return {
                "total": parts[1],
                "used": parts[2],
                "available": parts[3],
                "percent": int(parts[4].replace("%", "")),
            }
    except Exception:
        pass
    return {}


def get_memory():
    try:
        with open("/proc/meminfo") as fh:
            lines = fh.readlines()
        data = {}
        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                key = parts[0].rstrip(":")
                try:
                    data[key] = int(parts[1])
                except ValueError:
                    pass
        if "MemTotal" in data and "MemAvailable" in data:
            used = data["MemTotal"] - data["MemAvailable"]
            percent = int((used / data["MemTotal"]) * 100)
            return {
                "total_kb": data["MemTotal"],
                "available_kb": data["MemAvailable"],
                "used_kb": used,
                "percent": percent,
            }
    except Exception:
        pass
    return {}


def get_load():
    try:
        with open("/proc/loadavg") as fh:
            parts = fh.read().split()
        return {"1min": float(parts[0]), "5min": float(parts[1]), "15min": float(parts[2])}
    except Exception:
        return {}


def get_docker_stats():
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}|{{.Status}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        containers = []
        for line in result.stdout.strip().split("\n"):
            if line:
                parts = line.split("|")
                containers.append({"name": parts[0], "status": parts[1] if len(parts) > 1 else "unknown"})
        return containers
    except Exception:
        return []


def main():
    log("=== KB Sys Metrics started ===")

    metrics = {
        "timestamp": datetime.datetime.now().isoformat(),
        "disk": get_disk_usage(),
        "memory": get_memory(),
        "load": get_load(),
        "docker": {
            "count": len(get_docker_stats()),
            "containers": get_docker_stats(),
        },
    }

    METRICS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(METRICS_FILE, "w") as fh:
        json.dump(metrics, fh, indent=2)

    log("=== KB Sys Metrics finished ===")


if __name__ == "__main__":
    main()
