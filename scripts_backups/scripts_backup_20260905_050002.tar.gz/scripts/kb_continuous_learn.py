#!/usr/bin/env python3
"""
KB Continuous Learn — learns from user corrections and chat feedback.
Monitors session history and captures learned principles automatically.
"""
import json, sys, re
from datetime import datetime
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
PRINCIPLES_FILE = Path("/root/.hermes/state/kb_learned_principles.json")
SESSION_DB = Path("/root/.hermes/state.db")
STATE_FILE = Path("/root/.hermes/state/kb_continuous_learn.json")

# Patterns that signal user correction/teaching
CORRECTION_PATTERNS = [
    r"(?i)no[,\s]that's wrong",
    r"(?i)actually[,\s]",
    r"(?i)it should be",
    r"(?i)the correct (way|answer|fix)",
    r"(?i)don't do that",
    r"(?i)never use",
    r"(?i)instead try",
    r"(?i)better approach",
    r"(?i)i meant",
    r"(?i)not quite",
    r"(?i)you missed",
    r"(?i)should have been",
    r"(?i)correction:",
    r"(?i)fix:",
    r"(?i)updated:",
    r"(?i)i said (no|yes)",
    r"(?i)retry",
    r"(?i)try again",
    r"(?i)that didn't work",
    r"(?i)still broken",
    r"(?i)yes but",
]

# Principles learned
POSITIVE_PATTERNS = [
    r"(?i)perfect",
    r"(?i)exactly",
    r"(?i)that's right",
    r"(?i)works now",
    r"(?i)great",
    r"(?i)good",
    r"(?i)thanks",
    r"(?i)nice",
]


def read_principles():
    if PRINCIPLES_FILE.exists():
        with open(PRINCIPLES_FILE) as f:
            return json.load(f)
    return {"principles": [], "corrections": []}


def write_principles(p):
    PRINCIPLES_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(PRINCIPLES_FILE, "w") as f:
        json.dump(p, f, indent=2)


def extract_learning(session_text):
    """Extract corrections and learnings from session text."""
    learnings = []
    lines = session_text.split("\n")

    for i, line in enumerate(lines):
        line_lower = line.lower()

        # Check for correction patterns
        for pattern in CORRECTION_PATTERNS:
            if re.search(pattern, line):
                # Get surrounding context
                context_before = "\n".join(lines[max(0, i-2):i])
                context_after = "\n".join(lines[i+1:min(len(lines), i+3)])
                learnings.append({
                    "type": "correction",
                    "pattern": pattern,
                    "text": line.strip(),
                    "context_before": context_before[:200],
                    "context_after": context_after[:200],
                    "timestamp": datetime.now().isoformat(),
                })
                break

        # Check for positive reinforcement
        for pattern in POSITIVE_PATTERNS:
            if re.search(pattern, line):
                context_before = "\n".join(lines[max(0, i-2):i])
                learnings.append({
                    "type": "positive",
                    "pattern": pattern,
                    "text": line.strip(),
                    "context_before": context_before[:200],
                    "timestamp": datetime.now().isoformat(),
                })
                break

    return learnings


def sessions_to_principles(sessions):
    """Convert session learnings into reusable principles."""
    principles = read_principles()
    new_principles = []

    for session in sessions:
        for learning in session.get("learnings", []):
            if learning["type"] == "correction":
                principle_id = f"correction_{len(principles['principles']) + 1}"
                principle = {
                    "id": principle_id,
                    "type": "correction",
                    "learned_from": learning.get("text", "")[:200],
                    "context": learning.get("context_before", "")[:200],
                    "timestamp": learning.get("timestamp", ""),
                    "times_applied": 0,
                    "times_confirmed": 0,
                }
                # Don't duplicate
                if not any(p.get("learned_from") == principle["learned_from"]
                          for p in principles["principles"]):
                    principles["principles"].append(principle)
                    new_principles.append(principle)

        principles["corrections"].append({
            "session_id": session.get("session_id", ""),
            "learnings_count": len(session.get("learnings", [])),
            "timestamp": datetime.now().isoformat(),
        })

    return principles, new_principles


def scan_sessions():
    """Scan recent sessions from state.db for learnings."""
    try:
        import sqlite3
        conn = sqlite3.connect(str(SESSION_DB))
        conn.set_trace_callback(None)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT session_id, title, updated_at
            FROM sessions
            ORDER BY updated_at DESC
            LIMIT 20
        """)
        rows = cursor.fetchall()
        conn.close()

        learnings = []
        for row in rows:
            session_id, title, updated_at = row
            learnings.append({
                "session_id": session_id,
                "title": title or "",
                "updated_at": updated_at or "",
                "learnings": []  # placeholder — actual content requires full scan
            })
        return learnings
    except Exception as e:
        return []


def main():
    principles = read_principles()

    # Scan sessions for new learnings
    sessions = scan_sessions()
    principles, new = sessions_to_principles(sessions)

    if new:
        write_principles(principles)
        print(f"[CONTINUOUS_LEARN] {len(new)} new principle(s) learned")
    else:
        print("[CONTINUOUS_LEARN] No new corrections detected")

    # Output summary
    total = len(principles["principles"])
    corrections = sum(1 for p in principles["principles"] if p.get("type") == "correction")
    print(f"[CONTINUOUS_LEARN] Total principles: {total} ({corrections} corrections)")

    # Write state
    with open(STATE_FILE, "w") as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "total_principles": total,
            "new_this_run": len(new),
            "corrections": corrections,
            "sessions_scanned": len(sessions),
        }, f, indent=2)

    sys.exit(0)


if __name__ == "__main__":
    main()
