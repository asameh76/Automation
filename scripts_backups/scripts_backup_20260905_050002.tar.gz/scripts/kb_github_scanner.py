#!/usr/bin/env python3
"""
KB GitHub Scanner - Scan GitHub repos for commits+issues.
Has REPOS list: nousresearch/hermes-agent, postiz-app/postiz, boto/boto3,
openai/openai-python, anthropic/anthropic-sdk-python, redis/redis-py.
Uses urllib for GitHub API.
"""

import json
import urllib.request
import urllib.parse
import datetime
from pathlib import Path


REPOS = [
    "nousresearch/hermes-agent",
    "postiz-app/postiz",
    "boto/boto3",
    "openai/openai-python",
    "anthropic/anthropic-sdk-python",
    "redis/redis-py",
]

SCAN_FILE = Path("/root/.hermes/state/kb_github_scan.json")
LOG_FILE = Path("/root/.hermes/logs/kb_github_scanner.log")
GITHUB_API = "https://api.github.com"


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def github_api(url):
    """Make a GitHub API request."""
    try:
        req = urllib.request.Request(url)
        req.add_header("Accept", "application/vnd.github.v3+json")
        req.add_header("User-Agent", "KB-GitHub-Scanner/1.0")
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        log(f"GitHub API error for {url}: {e}")
        return None


def get_commits(repo, days=7):
    """Get recent commits."""
    since = datetime.datetime.now() - datetime.timedelta(days=days)
    since_str = since.strftime("%Y-%m-%dT%H:%M:%SZ")
    url = f"{GITHUB_API}/repos/{repo}/commits?since={since_str}&per_page=10"
    data = github_api(url)
    if not data:
        return []
    commits = []
    for c in data:
        commits.append({
            "sha": c.get("sha", "")[:8],
            "message": c.get("commit", {}).get("message", "").split("\n")[0],
            "author": c.get("commit", {}).get("author", {}).get("name", ""),
            "date": c.get("commit", {}).get("author", {}).get("date", ""),
        })
    return commits


def get_issues(repo, days=7, state="open"):
    """Get recent issues."""
    since = datetime.datetime.now() - datetime.timedelta(days=days)
    since_str = since.strftime("%Y-%m-%dT%H:%M:%SZ")
    url = f"{GITHUB_API}/repos/{repo}/issues?since={since_str}&state={state}&per_page=10"
    data = github_api(url)
    if not data:
        return []
    issues = []
    for i in data:
        if "pull_request" in i:
            continue
        issues.append({
            "number": i.get("number"),
            "title": i.get("title", ""),
            "state": i.get("state", ""),
            "labels": [l.get("name") for l in i.get("labels", [])],
            "created": i.get("created_at", ""),
        })
    return issues


def scan_repo(repo):
    """Scan a single repo."""
    log(f"Scanning {repo}...")
    commits = get_commits(repo, days=7)
    issues = get_issues(repo, days=7, state="open")
    return {
        "repo": repo,
        "commits": commits,
        "issues": issues,
        "scanned_at": datetime.datetime.now().isoformat(),
    }


def main():
    log("=== KB GitHub Scanner started ===")

    results = []
    for repo in REPOS:
        result = scan_repo(repo)
        results.append(result)
        log(f"  {repo}: {len(result['commits'])} commits, {len(result['issues'])} issues")

    scan_data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "repos_scanned": len(REPOS),
        "results": results,
    }

    SCAN_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SCAN_FILE, "w") as fh:
        json.dump(scan_data, fh, indent=2)

    total_commits = sum(len(r["commits"]) for r in results)
    total_issues = sum(len(r["issues"]) for r in results)
    log(f"=== KB GitHub Scanner: {total_commits} commits, {total_issues} issues ===")


if __name__ == "__main__":
    main()
