#!/usr/bin/env python3
"""
KB Self-Evaluate - Self-Evaluation.
Checks KB health: min_fix_len=15, min_coverage thresholds.
Writes to kb_audit.json.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
AUDIT_FILE = Path("/root/.hermes/state/kb_audit.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_evaluate.log")

MIN_FIX_LEN = 15
MIN_COVERAGE = 0.5
MIN_ENTRIES = 5


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def evaluate_fix(fix):
    """Evaluate a single fix."""
    score = 0
    issues = []

    desc = fix.get("description", "")
    if len(desc) >= MIN_FIX_LEN:
        score += 1
    else:
        issues.append(f"Fix description too short ({len(desc)} < {MIN_FIX_LEN})")

    if fix.get("evidence"):
        score += 1
    else:
        issues.append("No evidence provided")

    if fix.get("applied"):
        score += 1

    if fix.get("verified"):
        score += 2

    return score, issues


def evaluate_entry(entry):
    """Evaluate a single KB entry."""
    score = 0
    issues = []

    desc = entry.get("error", "")
    if len(desc) >= 10:
        score += 1

    fixes = entry.get("fixes", [])
    if fixes:
        fix_scores = [evaluate_fix(f) for f in fixes]
        avg_fix_score = sum(s for s, _ in fix_scores) / len(fix_scores) if fix_scores else 0
        score += avg_fix_score
        for _, issues_list in fix_scores:
            issues.extend(issues_list)
    else:
        issues.append("No fixes defined")

    status = entry.get("status", "unknown")
    if status == "verified":
        score += 3
    elif status == "investigate":
        score += 1

    return score, issues


def main():
    log("=== KB Self-Evaluate started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])
    total = len(entries)

    if total < MIN_ENTRIES:
        log(f"WARNING: Only {total} KB entries, minimum recommended: {MIN_ENTRIES}")

    entry_scores = []
    all_issues = []

    for entry in entries:
        score, issues = evaluate_entry(entry)
        entry_scores.append({
            "error": entry.get("error", "")[:80],
            "status": entry.get("status", "unknown"),
            "score": score,
            "issues": issues,
        })
        all_issues.extend(issues)

    verified_count = sum(1 for e in entries if e.get("status") == "verified")
    investigate_count = sum(1 for e in entries if e.get("status") == "investigate")
    coverage = verified_count / total if total > 0 else 0

    audit = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_entries": total,
        "verified": verified_count,
        "investigate": investigate_count,
        "coverage": coverage,
        "coverage_adequate": coverage >= MIN_COVERAGE,
        "min_entries_met": total >= MIN_ENTRIES,
        "entry_scores": entry_scores,
        "issues": all_issues,
    }

    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_FILE, "w") as fh:
        json.dump(audit, fh, indent=2)

    log(f"=== KB Self-Evaluate: {total} entries, {verified_count} verified, coverage={coverage:.2f} ===")


if __name__ == "__main__":
    main()
