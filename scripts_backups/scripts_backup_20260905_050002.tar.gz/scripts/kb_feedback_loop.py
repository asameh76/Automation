#!/usr/bin/env python3
"""
KB Feedback Loop - KB Feedback Loop.
Tracks which fixes were applied and validates by error cessation.
4h window. Reads errors.log.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
FBL_STATE_FILE = Path("/root/.hermes/state/kb_feedback_loop.json")
LOG_FILE = Path("/root/.hermes/logs/kb_feedback_loop.log")

WINDOW_HOURS = 4


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def get_recent_errors():
    """Get errors from the last WINDOW_HOURS hours."""
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            lines = fh.readlines()
    except Exception:
        return []

    cutoff = datetime.datetime.now() - datetime.timedelta(hours=WINDOW_HOURS)
    recent = []
    for line in lines:
        # Try to parse timestamp from log line
        try:
            # Expect format: [ISO timestamp] error message
            if line.startswith("["):
                ts_str = line[1:line.find("]")]
                ts = datetime.datetime.fromisoformat(ts_str)
                if ts >= cutoff:
                    recent.append(line.strip())
        except Exception:
            # If can't parse, include last 50 lines as fallback
            pass
    return recent[-50:]


def main():
    log("=== KB Feedback Loop started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    recent_errors = get_recent_errors()
    fbl_state = load_fbl_state()

    applied_fixes = []
    for entry in kb.get("knowledge_base", []):
        for fix in entry.get("fixes", []):
            if fix.get("applied"):
                applied_fixes.append({
                    "error": entry.get("error", ""),
                    "fix": fix,
                    "applied_at": fix.get("applied_at", ""),
                })

    # Check error cessation
    validated = 0
    not_validated = 0
    for applied in applied_fixes:
        error_pattern = applied["error"].lower()
        error_ceased = True
        for err_line in recent_errors:
            if error_pattern in err_line.lower():
                error_ceased = False
                break
        applied["error_ceased"] = error_ceased
        if error_ceased:
            validated += 1
        else:
            not_validated += 1

    fbl_state["last_run"] = datetime.datetime.now().isoformat()
    fbl_state["window_hours"] = WINDOW_HOURS
    fbl_state["recent_error_count"] = len(recent_errors)
    fbl_state["applied_fixes_count"] = len(applied_fixes)
    fbl_state["validated_count"] = validated
    fbl_state["not_validated_count"] = not_validated
    fbl_state["applied_fixes"] = applied_fixes[-20:]

    FBL_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(FBL_STATE_FILE, "w") as fh:
        json.dump(fbl_state, fh, indent=2)

    log(f"=== KB Feedback Loop: {validated}/{len(applied_fixes)} fixes validated ===")


def load_fbl_state():
    if FBL_STATE_FILE.exists():
        try:
            with open(FBL_STATE_FILE) as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


if __name__ == "__main__":
    main()
