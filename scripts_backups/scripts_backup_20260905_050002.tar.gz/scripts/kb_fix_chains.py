#!/usr/bin/env python3
"""
KB Fix Chains - Apply fix chains in sequence, falling through to the next
fix if the previous one fails.

For each KB entry with status != 'fixed' (and with un-applied fixes), this
script tries the fixes in order.  If fix[i] fails, fix[i+1] is attempted.
The chain outcome (which fix succeeded, or that all failed) is recorded in
the entry and written back to the KB.

Chain logic
-----------
Each entry's fixes list is treated as an ordered chain:

    fixes = [fix1, fix2, fix3, ...]

The script iterates through the chain in order:
  - If fix[i] succeeds  → mark it applied, break, record entry status 'fixed'.
  - If fix[i] fails     → record the failure detail, continue to fix[i+1].
  - If ALL fixes fail    → mark entry status 'unfixed', record chain_failure.

Every fix's result (applied_at, error, detail) is stamped on the fix object
so the chain history is auditable inside the KB entry.
"""

import json
import subprocess
import datetime
import fcntl
import os
import re
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE = Path("/root/.hermes/state/kb_fix_chains.json")
LOG_FILE = Path("/root/.hermes/logs/kb_fix_chains.log")

# Commands that are NEVER safe to run
BLOCKED_COMMANDS = {
    "rm", "dd", "mkfs", "fdisk", "parted",
    "shutdown", "reboot", "init", "poweroff",
    ">:", ">|", "tee",
}

# Shell commands considered safe to execute (restart-like ops)
SAFE_ACTIONS = {
    "docker": ["restart", "stop", "start", "kill"],
    "systemctl": ["restart", "stop", "start"],
    "nginx": ["reload"],
}


# ── Logging ──────────────────────────────────────────────────────────────────

def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


# ── KB read/write ─────────────────────────────────────────────────────────────

def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


# ── Safety checks ─────────────────────────────────────────────────────────────

def _base_cmd(cmd):
    """Leading binary name from a command list."""
    if not cmd:
        return ""
    return os.path.basename(str(cmd[0]))


def is_dangerous(cmd):
    """Return True if cmd contains a known destructive operation."""
    if not cmd:
        return True
    flat = " ".join(str(c) for c in cmd)
    for blocked in BLOCKED_COMMANDS:
        if re.search(r'\b' + blocked + r'\b', flat):
            return True
    return False


def is_safe_action(cmd):
    """Return True if cmd is in the allowed safe-action set."""
    if not cmd:
        return False
    base = _base_cmd(cmd)
    sub = cmd[1] if len(cmd) > 1 else ""
    return base in SAFE_ACTIONS and sub in SAFE_ACTIONS.get(base, [])


# ── Per-fix execution ─────────────────────────────────────────────────────────

def run_fix(fix):
    """
    Execute a single fix.  Returns (success: bool, detail: str).

    Supports fix action types:
      - shell  : runs a list[str] command via subprocess
      - python : runs a python code string via python3 -c
      - script : runs an executable script path with optional args

    Danger-check is applied before any execution; dangerous commands are
    rejected without running.
    """
    action = fix.get("action", {})
    fix_type = action.get("type", "shell")
    now = datetime.datetime.now().isoformat()

    if fix_type == "shell":
        cmd = action.get("command", [])
        if not cmd:
            return False, "no command in shell action"
        if is_dangerous(cmd):
            return False, "blocked: command is on the danger list"
        if not is_safe_action(cmd):
            return False, f"command not in safe-action allowlist: {' '.join(cmd)}"
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                out = result.stdout.strip()[:200] if result.stdout else "(no output)"
                return True, f"ok: {out}"
            else:
                err = result.stderr.strip()[:200] if result.stderr else "(no stderr)"
                return False, f"exit {result.returncode}: {err}"
        except subprocess.TimeoutExpired:
            return False, "timeout after 60s"
        except Exception as e:
            return False, f"exception: {e}"

    elif fix_type == "python":
        code = action.get("code", "")
        if not code:
            return False, "no code in python action"
        try:
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                out = result.stdout.strip()[:200] if result.stdout else "(no output)"
                return True, f"ok: {out}"
            else:
                err = result.stderr.strip()[:200] if result.stderr else "(no stderr)"
                return False, f"exit {result.returncode}: {err}"
        except subprocess.TimeoutExpired:
            return False, "timeout after 60s"
        except Exception as e:
            return False, f"exception: {e}"

    elif fix_type == "script":
        path = action.get("path", "")
        args = action.get("args", [])
        if not path:
            return False, "no path in script action"
        cmd = [path] + list(args)
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                out = result.stdout.strip()[:200] if result.stdout else "(no output)"
                return True, f"ok: {out}"
            else:
                err = result.stderr.strip()[:200] if result.stderr else "(no stderr)"
                return False, f"exit {result.returncode}: {err}"
        except subprocess.TimeoutExpired:
            return False, "timeout after 120s"
        except Exception as e:
            return False, f"exception: {e}"

    else:
        return False, f"unknown fix type: {fix_type}"


# ── Chain processing ──────────────────────────────────────────────────────────

def process_entry(entry):
    """
    Run the fix chain for a single KB entry.
    Returns a stats dict for this entry.
    """
    error_key = entry.get("error", "")[:60]
    fixes = entry.get("fixes", [])

    # Skip entries with no fixes
    if not fixes:
        return {"error_key": error_key, "fixes_attempted": 0, "chain_succeeded": False, "final_fix": None}

    stats = {
        "error_key": error_key,
        "fixes_attempted": 0,
        "chain_succeeded": False,
        "final_fix": None,   # index of fix that succeeded (0-based), or None
        "fix_results": [],
    }

    for idx, fix in enumerate(fixes):
        # Skip fixes already recorded as applied
        if fix.get("applied"):
            continue

        stats["fixes_attempted"] += 1
        success, detail = run_fix(fix)

        fix["applied"] = success
        fix["applied_at"] = datetime.datetime.now().isoformat()
        fix["apply_detail"] = detail

        stats["fix_results"].append({
            "fix_index": idx,
            "fix_id": fix.get("id", f"fix-{idx}"),
            "success": success,
            "detail": detail,
        })

        if success:
            stats["chain_succeeded"] = True
            stats["final_fix"] = idx
            log(f"  CHAIN OK   [{error_key}] fix[{idx}] succeeded → {detail[:80]}")
            # Chain succeeded — stop here, entry is 'fixed'
            break
        else:
            log(f"  CHAIN FAIL [{error_key}] fix[{idx}] failed  → {detail[:80]}")
            # fall through to next fix in chain

    # If we exhausted the chain with no success, mark entry as unfixed
    if not stats["chain_succeeded"] and stats["fixes_attempted"] > 0:
        entry["status"] = "unfixed"
        entry["chain_failure_at"] = datetime.datetime.now().isoformat()
        log(f"  CHAIN DEAD [{error_key}] all {stats['fixes_attempted']} fixes failed")

    elif stats["chain_succeeded"]:
        entry["status"] = "fixed"
        entry["fixed_at"] = datetime.datetime.now().isoformat()
        log(f"  CHAIN DONE [{error_key}] resolved at fix[{stats['final_fix']}]")

    return stats


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    log("=== KB Fix Chains started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])
    total_stats = {
        "entries_processed": 0,
        "entries_fixed": 0,
        "entries_unfixed": 0,
        "entries_skipped": 0,
        "total_fixes_attempted": 0,
        "chains": [],
    }

    for entry in entries:
        status = entry.get("status", "")
        # Skip entries already confirmed as fixed or verified (no chain needed)
        if status in ("fixed", "verified"):
            total_stats["entries_skipped"] += 1
            continue
        # Skip entries with no known fixes
        if not entry.get("fixes"):
            total_stats["entries_skipped"] += 1
            continue

        total_stats["entries_processed"] += 1
        es = process_entry(entry)
        total_stats["chains"].append(es)
        total_stats["total_fixes_attempted"] += es["fixes_attempted"]

        if es["chain_succeeded"]:
            total_stats["entries_fixed"] += 1
        else:
            total_stats["entries_unfixed"] += 1

    # Write updated KB if any entry was modified
    if total_stats["entries_processed"] > 0:
        write_kb(kb)

    # Write state summary
    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        **total_stats,
    }
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Fix Chains: "
        f"processed={total_stats['entries_processed']} "
        f"fixed={total_stats['entries_fixed']} "
        f"unfixed={total_stats['entries_unfixed']} "
        f"skipped={total_stats['entries_skipped']} "
        f"fixes_run={total_stats['total_fixes_attempted']} ===")


if __name__ == "__main__":
    main()
