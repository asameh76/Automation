#!/usr/bin/env python3
"""
KB False Positive Filter — Learn which errors fix themselves.

Finds errors in the KB that resolved without intervention:
  - verified='false' AND auto_fixed='true'  → self-resolved
  - verified='false' AND success_count > 0  → fix applied but not marked verified

Marks them as false_positive and updates the KB.
"""

import json
import datetime
import fcntl
import sys
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_false_positive_filter.log")
STATE_FILE = Path("/root/.hermes/state/kb_false_positive_filter.json")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def is_self_resolved(entry):
    """Entry resolved without external intervention."""
    verified = str(entry.get("verified", "")).lower()
    auto_fixed = str(entry.get("auto_fixed", "")).lower()
    return verified == "false" and auto_fixed == "true"


def is_fix_applied_unverified(entry):
    """Fix was applied (success_count > 0) but verified flag is still false."""
    verified = str(entry.get("verified", "")).lower()
    success_count = entry.get("success_count", 0)
    return verified == "false" and success_count > 0


def main():
    log("=== KB False Positive Filter started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        sys.exit(1)

    errors = kb.get("errors", [])
    log(f"Total KB entries: {len(errors)}")

    self_resolved = []
    fix_applied_unverified = []
    already_marked = []
    updated = []

    for entry in errors:
        sig = entry.get("signature", "<unknown>")

        # Skip if already marked as false_positive
        if entry.get("false_positive"):
            already_marked.append(sig)
            continue

        if is_self_resolved(entry):
            entry["false_positive"] = True
            entry["false_positive_reason"] = "self_resolved"
            entry["false_positive_detected_at"] = datetime.datetime.now().isoformat()
            self_resolved.append(sig)
            updated.append(sig)
            log(f"  [self-resolved]   {sig}")

        elif is_fix_applied_unverified(entry):
            entry["false_positive"] = True
            entry["false_positive_reason"] = "fix_applied_unverified"
            entry["false_positive_detected_at"] = datetime.datetime.now().isoformat()
            fix_applied_unverified.append(sig)
            updated.append(sig)
            log(f"  [fix+unverified]  {sig}")

    # Update KB metadata
    kb["updated"] = datetime.datetime.now().isoformat()
    kb["metadata"] = kb.get("metadata", {})
    kb["metadata"]["false_positive_filter_run"] = datetime.datetime.now().isoformat()

    if updated:
        write_kb(kb)
        log(f"KB updated: {len(updated)} entries marked false_positive")
    else:
        log("No false positives detected — KB unchanged.")

    # Persist run state
    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_entries": len(errors),
        "self_resolved": self_resolved,
        "fix_applied_unverified": fix_applied_unverified,
        "already_marked_count": len(already_marked),
        "total_marked": len(updated),
    }

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB False Positive Filter done: "
        f"marked={len(updated)}, "
        f"self_resolved={len(self_resolved)}, "
        f"fix_unverified={len(fix_applied_unverified)}, "
        f"already_marked={len(already_marked)} ===")

    print(json.dumps(state, indent=2))


if __name__ == "__main__":
    main()
