#!/usr/bin/env python3
"""
KB Collaborate - KB Collaborative Learning.
Shares via GitHub gist.
"""

import json
import subprocess
import datetime
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
GIST_FILE = Path("/root/.hermes/state/kb_collaborate.json")
LOG_FILE = Path("/root/.hermes/logs/kb_collaborate.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE) as fh:
        return json.load(fh)


def create_gist(content, description):
    """Create a GitHub gist using gh CLI."""
    try:
        result = subprocess.run(
            ["gh", "gist", "create", "--desc", description, "--public"],
            input=content,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception as e:
        log(f"Failed to create gist: {e}")
    return None


def main():
    log("=== KB Collaborate started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    # Export verified entries for sharing
    verified = [e for e in kb.get("knowledge_base", []) if e.get("status") == "verified"]
    share_data = {
        "version": kb.get("version", "1.0"),
        "exported_at": datetime.datetime.now().isoformat(),
        "entries": verified,
    }

    content = json.dumps(share_data, indent=2)
    gist_url = create_gist(content, "Hermes KB Export")

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "entries_shared": len(verified),
        "gist_url": gist_url,
    }

    GIST_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(GIST_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    if gist_url:
        log(f"=== KB Collaborate: shared {len(verified)} entries to {gist_url} ===")
    else:
        log("=== KB Collaborate: gist creation failed ===")


if __name__ == "__main__":
    main()
