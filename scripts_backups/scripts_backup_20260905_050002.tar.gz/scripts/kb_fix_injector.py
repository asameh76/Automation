#!/usr/bin/env python3
"""KB Fix Injector — marks a fix as applied in logs so feedback loop can validate it."""
import sys, json
from datetime import datetime

LOG_FILE = "/root/.hermes/logs/errors.log"

def inject_fix(sig, fix_text=None, result=None):
    """Write KB fix applied marker to log."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    marker = f"[KB_FIX_APPLIED] {now} | sig={sig}"
    if fix_text:
        marker += f" | fix={fix_text[:100]}"
    if result:
        marker += f" | result={result}"
    marker += " | source=kb_fix_injector"

    try:
        with open(LOG_FILE, "a") as f:
            f.write(marker + "\n")
        return True
    except Exception as e:
        print(f"[ERROR] Could not write to log: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: kb_fix_injector.py <signature> [fix_text] [result]")
        print("Example: kb_fix_injector.py 'gateway_timeout' 'Increase gateway timeout to 60s' 'success'")
        sys.exit(1)

    sig = sys.argv[1]
    fix_text = sys.argv[2] if len(sys.argv) > 2 else None
    result = sys.argv[3] if len(sys.argv) > 3 else None

    if inject_fix(sig, fix_text, result):
        print(f"[OK] Fix applied marker logged: {sig}")
    else:
        print(f"[FAIL] Could not inject fix marker")
        sys.exit(1)
