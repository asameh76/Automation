#!/usr/bin/env python3
"""Auto-flush memory when >75% full. Reads MEMORY.md directly."""
import re, os, sys, subprocess

MEM_FILE = "/root/.hermes/memories/MEMORY.md"
MAX_CHARS = 2200
THRESHOLD = 0.75

def get_size():
    if not os.path.exists(MEM_FILE):
        return 0
    with open(MEM_FILE) as f:
        return len(f.read())

def run(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def condense():
    with open(MEM_FILE) as f:
        content = f.read()
    # Split on § separator
    entries = [e.strip() for e in content.split("§") if e.strip()]
    # Keep essential keywords, condense others
    essential_keywords = ["PERMANENT", "Creds", "Fallback", "Pending", "Dawn pipeline", "Email", "Migration"]
    kept = []
    for e in entries:
        if any(k.lower() in e.lower() for k in essential_keywords):
            kept.append(e)
        else:
            if len(e) > 200:
                kept.append(e[:150] + "… [condensed]")
            else:
                kept.append(e)
    new_content = "\n§\n".join(kept) + "\n"
    with open(MEM_FILE, "w") as f:
        f.write(new_content)
    print(f"Memory condensed: {len(entries)} -> {len(kept)} entries")

def main():
    size = get_size()
    usage_pct = size / MAX_CHARS * 100
    print(f"Memory: {size}/{MAX_CHARS} ({usage_pct:.0f}%)")
    if usage_pct > THRESHOLD * 100:
        condense()
        new_size = get_size()
        print(f"After cleanup: {new_size}/{MAX_CHARS} ({new_size/MAX_CHARS*100:.0f}%)")
    else:
        print("OK")

if __name__ == "__main__":
    main()
