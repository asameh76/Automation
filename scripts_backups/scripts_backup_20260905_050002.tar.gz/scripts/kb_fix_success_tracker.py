#!/usr/bin/env python3
"""
Fix Success Tracker — records when KB fixes are applied and whether they worked.
Feeds op_fix_drift_detector with real success rate data.
Runs on each kb_combined cycle.
"""
import json, fcntl, subprocess
from pathlib import Path
from datetime import datetime, timedelta

KB_FILE      = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE   = Path("/root/.hermes/state/kb_fix_success_tracker.json")
LOG_FILE     = Path("/root/.hermes/logs/kb_fix_success_tracker.log")
V_TYPES      = {'verified','manual_verified','canary_verified','cross_verified','self_healed'}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[FIX-TRACKER {ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def read_kb():
    with open(KB_FILE) as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(f)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def write_kb(kb):
    with open(KB_FILE, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, f, indent=2, default=str)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def read_state():
    try:
        return json.load(open(STATE_FILE))
    except:
        return {"fix_history": [], "success_rates": {}, "applied_log": []}

def write_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)

def run(cmd, timeout=10):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    return r.stdout.strip()

def check_fix_worked(entry_sig):
    """
    Check if applying the fix for this entry actually resolved the error.
    Returns: (worked: bool or None, detail: str)
    None = can't determine
    """
    sig_lower = entry_sig.lower()

    # Check errors.log for the error pattern in the last 24h
    if not Path("/root/.hermes/logs/errors.log").exists():
        return None, "no_errors_log"

    try:
        lines = open("/root/.hermes/logs/errors.log").readlines()
    except:
        return None, "cant_read_log"

    # Look for the error in the last 48h
    cutoff = datetime.now() - timedelta(hours=48)
    recent = []
    for line in lines[-1000:]:
        try:
            if line.startswith("2026"):
                ts_str = line[:19]
                ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
                if ts >= cutoff:
                    recent.append(line)
        except:
            pass

    # Count error occurrences in recent vs older
    error_lines = [l for l in recent if sig_lower in l.lower()]

    if not error_lines:
        # Error gone — fix likely worked
        return True, f"error_not_seen_in_48h"

    # Check if there's a "fixed" or "resolved" marker near the error
    for l in error_lines:
        if any(x in l.lower() for x in ["fixed", "resolved", "restarted", "recovered", "applied"]):
            return True, f"recovery_signal: {l[:60]}"

    # Error still present — fix may have failed or error recurred
    return False, f"error_still_present ({len(error_lines)} occurrences in 48h)"

def main():
    log("=== Fix Success Tracker START ===")
    kb    = read_kb()
    state = read_state()

    errors        = kb.get("errors", [])
    success_rates = state.get("success_rates", {})
    applied_log   = state.get("applied_log", [])

    # Track entries we haven't checked yet
    checked_this_run = []
    new_success_data = []

    for entry in errors:
        sig  = entry.get("signature", "")
        v    = entry.get("verified", "")

        if v not in V_TYPES:
            continue  # only track verified fixes

        fix_desc = entry.get("fix", "") or (entry.get("fixes", [{}])[0].get("description", "") if entry.get("fixes") else "")

        # Get or init success rate record
        if sig not in success_rates:
            success_rates[sig] = {"success": 0, "fail": 0, "recent_uses": [], "fix_desc": fix_desc[:80]}

        sr = success_rates[sig]
        last_check = sr.get("last_checked", "")

        # Only re-check entries not checked in last 6h
        if last_check:
            try:
                last_dt = datetime.fromisoformat(last_check)
                if (datetime.now() - last_dt).total_seconds() < 6 * 3600:
                    continue
            except:
                pass

        worked, detail = check_fix_worked(sig)
        checked_this_run.append({"sig": sig, "worked": worked, "detail": detail})

        if worked is None:
            sr["last_checked"] = datetime.now().isoformat()
            continue

        # Record outcome
        if worked:
            sr["success"] += 1
            sr["recent_uses"].append({"success": True, "ts": datetime.now().isoformat(), "detail": detail})
        else:
            sr["fail"] += 1
            sr["recent_uses"].append({"success": False, "ts": datetime.now().isoformat(), "detail": detail})

        # Keep only last 10 uses
        sr["recent_uses"] = sr["recent_uses"][-10:]
        sr["last_checked"] = datetime.now().isoformat()

        total = sr["success"] + sr["fail"]
        sr["rate"] = round(sr["success"] / total, 3) if total > 0 else 0
        new_success_data.append(sig)

    # Write success_rates back to KB for op_fix_drift_detector
    kb["fix_success_rates"] = success_rates

    state["success_rates"] = success_rates
    state["applied_log"]  = applied_log[-100:]
    state["last_run"]     = datetime.now().isoformat()
    write_state(state)
    write_kb(kb)

    total_tracked = len(success_rates)
    good_rate     = sum(1 for s in success_rates.values() if s.get("rate", 0) >= 0.7)
    bad_rate      = [s for s in success_rates.values() if s.get("rate", 0) < 0.7 and (s["success"] + s["fail"]) >= 3]

    log(f"=== Fix Success Tracker END: {len(checked_this_run)} checked, {total_tracked} total tracked, {good_rate} good fix rate, {len(bad_rate)} showing drift ===")
    if checked_this_run:
        for c in checked_this_run[:5]:
            log(f"  {'✅' if c['worked'] else '❌'} {c['sig'][:50]}: {c['detail']}")

if __name__ == "__main__":
    main()
