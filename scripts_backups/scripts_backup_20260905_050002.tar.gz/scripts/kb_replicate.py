#!/usr/bin/env python3
"""
KB Replicate - KB Self-Replication.
"""

import json
import shutil
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
REPLICATE_DIR = Path("/root/.hermes/replication")
LOG_FILE = Path("/root/.hermes/logs/kb_replicate.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB Replicate started ===")

    REPLICATE_DIR.mkdir(parents=True, exist_ok=True)

    kb = read_kb()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    replica = REPLICATE_DIR / f"kb_replica_{timestamp}.json"

    with open(replica, "w") as fh:
        json.dump(kb, fh, indent=2)

    log(f"Replicated KB to {replica}")

    # Prune old replicas (keep last 10)
    replicas = sorted(REPLICATE_DIR.glob("kb_replica_*.json"), key=lambda p: p.stat().st_mtime)
    for old in replicas[:-10]:
        old.unlink()
        log(f"Pruned old replica: {old.name}")

    log("=== KB Replicate finished ===")


if __name__ == "__main__":
    main()
