#!/usr/bin/env python3
"""
Hostinger VPS health check — monitors WordPress/WooCommerce at 153.92.220.105
Runs every 15 min via cron. Silent when healthy; Telegram alert when down.
"""
import subprocess, sys, os

HOST = "153.92.220.105"
PORT = 65002
USER = "u927523272"
SSH_KEY = "/root/.hermes-keys/hostinger_private_key"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = "864983959"

def run(cmd, timeout=30):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)

def ssh_cmd(cmd):
    return run(f"ssh -o StrictHostKeyChecking=no -o ConnectTimeout=25 -p {PORT} -i {SSH_KEY} {USER}@{HOST} \"{cmd}\"")

def send_telegram(msg):
    if not TELEGRAM_BOT_TOKEN:
        print(f"[ALERT] {msg}")
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    subprocess.run(["curl", "-s", "-X", "POST", url,
                    "-d", f"chat_id={TELEGRAM_CHAT_ID}",
                    "-d", f"text={msg}"],
                   capture_output=True)

def check():
    issues = []

    # 1. SSH connectivity
    r = ssh_cmd("echo ok")
    if r.returncode != 0 or "ok" not in r.stdout:
        issues.append(f"SSH unreachable")
        return issues

    # 2. Disk
    r = ssh_cmd("df -h / | tail -1 | awk '{print $5}' | sed 's/%//'")
    try:
        disk_pct = int(r.stdout.strip())
        if disk_pct > 85:
            issues.append(f"Disk {disk_pct}% (>85%)")
    except:
        pass

    # 3. Memory
    r = ssh_cmd("free -m | awk 'NR==2 {print $3, $2}'")
    try:
        used, total = r.stdout.strip().split()
        mem_pct = int(used) / int(total) * 100
        if mem_pct > 90:
            issues.append(f"Memory {mem_pct:.0f}% (>90%)")
    except:
        pass

    # 4. Load
    r = ssh_cmd("uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//'")
    try:
        load = float(r.stdout.strip())
        cores = os.cpu_count() or 4
        if load > cores * 2:
            issues.append(f"High load: {load}")
    except:
        pass

    # 5. gemgyms.com HTTP check through Cloudflare
    r = run(f"curl -s -o /dev/null -w '%{{http_code}}' --max-time 10 -L http://gemgyms.com/ 2>/dev/null || echo '000'")
    try:
        code = r.stdout.strip()[:3]
        # Only alert on genuinely unreachable (000), not 403/429 (WAF/CDN blocks)
        if code == "000":
            issues.append(f"gemgyms.com unreachable (HTTP {code})")
    except:
        pass

    # 6. MySQL via direct TCP check
    r = ssh_cmd("mysqladmin ping 2>/dev/null || echo 'down'")
    if "down" in r.stdout or r.returncode != 0:
        issues.append("MySQL not responding")

    return issues

def main():
    issues = check()
    if issues:
        msg = f"⚠️ Hostinger VPS ({HOST}) Issues:\n" + "\n".join(f"  • {i}" for i in issues)
        send_telegram(msg)
        print(msg)
        sys.exit(1)
    else:
        print("[OK] Hostinger VPS healthy")
        sys.exit(0)

if __name__ == "__main__":
    main()
