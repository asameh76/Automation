#!/usr/bin/env python3
"""
KB Self-Deprecate — retires obsolete mechanisms gracefully.
Detects unused/obsolete scripts and KB entries, archives them instead of deleting.
"""
import json, sys, os
from datetime import datetime
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
SCRIPTS_DIR = Path("/root/.hermes/scripts")
STATE_FILE = Path("/root/.hermes/state/kb_self_deprecate.json")
DEPRECATED_DIR = Path("/root/.hermes/deprecated")
LOG_FILE = Path("/root/.hermes/logs/kb_self_deprecate.log")
REGISTRY_FILE = Path("/root/.hermes/state/mechanism_registry.json")


def read_kb():
    with open(KB_FILE) as f:
        return json.load(f)


def write_kb(kb):
    with open(KB_FILE, "w") as f:
        json.dump(kb, f, indent=2)


def read_registry():
    if REGISTRY_FILE.exists():
        with open(REGISTRY_FILE) as f:
            return json.load(f)
    return {}


def write_registry(reg):
    REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(REGISTRY_FILE, "w") as f:
        json.dump(reg, f, indent=2)


def get_cron_scripts():
    """Get list of scripts currently in crontab."""
    try:
        import subprocess
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=5)
        scripts = set()
        for line in result.stdout.split("\n"):
            # Match /root/.hermes/scripts/kb_*.py patterns
            import re
            matches = re.findall(r'/root/\.hermes/scripts/(kb_\w+\.py)', line)
            scripts.update(matches)
        return scripts
    except:
        return set()


def get_recently_run_scripts(days=7):
    """Scripts that ran in last N days via cron state."""
    try:
        jobs_file = Path("/root/.hermes/cron/jobs.json")
        if not jobs_file.exists():
            return set()
        with open(jobs_file) as f:
            jobs = json.load(f)
        cutoff = datetime.now().timestamp() - (days * 86400)
        run_scripts = set()
        for job in jobs.get("jobs", []):
            last_run = job.get("last_run", 0)
            if isinstance(last_run, str):
                import time
                try:
                    last_run = time.mktime(time.strptime(last_run, "%Y-%m-%dT%H:%M:%S"))
                except:
                    last_run = 0
            if last_run > cutoff:
                script = job.get("script", "")
                if script:
                    run_scripts.add(script.split("/")[-1])
        return run_scripts
    except:
        return set()


def detect_obsolete_scripts():
    """Find scripts that haven't run in 30+ days and aren't in crontab."""
    cron_scripts = get_cron_scripts()
    recently_run = get_recently_run_scripts(days=30)
    registry = read_registry()

    all_scripts = list(SCRIPTS_DIR.glob("kb_*.py"))
    obsolete = []

    for script in all_scripts:
        name = script.name
        # Skip if in crontab
        if name in cron_scripts:
            continue
        # Skip if ran recently
        if name in recently_run:
            continue
        # Skip if actively registered
        gap_id = name.replace(".py", "")
        if gap_id in registry:
            continue
        # Skip core scripts
        core = {"kb_manager", "kb_combined", "kb_self_generation", "kb_self_governance",
                "kb_self_deprecate", "kb_self_awareness", "kb_self_model"}
        if gap_id in core:
            continue

        mtime_days = (datetime.now() - datetime.fromtimestamp(script.stat().st_mtime)).days
        # Only flag as potentially obsolete if not modified in last 7 days
        if mtime_days < 7:
            continue
        age_days = mtime_days
        obsolete.append({"script": name, "age_days": age_days, "path": str(script)})

    return obsolete


def deprecate_script(script_info):
    """Archive an obsolete script."""
    name = script_info["script"]
    src = Path(script_info["path"])
    DEPRECATED_DIR.mkdir(parents=True, exist_ok=True)

    dest = DEPRECATED_DIR / name
    shutil = __import__("shutil")
    shutil.copy2(src, dest)

    # Add deprecation metadata
    meta_file = DEPRECATED_DIR / f"{name}.meta.json"
    with open(meta_file, "w") as f:
        json.dump({
            "original_path": str(src),
            "deprecated_at": datetime.now().isoformat(),
            "reason": "obsolete",
            "age_days": script_info["age_days"],
        }, f, indent=2)

    return str(dest)


def main():
    obsolete = detect_obsolete_scripts()
    deprecated_this_run = []

    if not obsolete:
        print("[DEPRECATE] No obsolete scripts found")
        sys.exit(0)

    print(f"[DEPRECATE] Found {len(obsolete)} obsolete script(s):")
    for s in obsolete:
        print(f"  {s['script']} ({s['age_days']} days old)")

    # Dry-run by default
    if "--apply" not in sys.argv:
        print("\nDry-run: pass --apply to actually deprecate")
        sys.exit(0)

    for s in obsolete:
        deprecate_script(s)
        deprecated_this_run.append(s["script"])

    # Update registry
    reg = read_registry()
    for name in deprecated_this_run:
        gap_id = name.replace(".py", "")
        if gap_id in reg:
            reg[gap_id]["status"] = "deprecated"
            reg[gap_id]["deprecated_at"] = datetime.now().isoformat()

    if deprecated_this_run:
        write_registry(reg)

    # Log
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps({
            "timestamp": datetime.now().isoformat(),
            "deprecated": deprecated_this_run,
        }) + "\n")

    print(f"\nDeprecated {len(deprecated_this_run)} script(s)")
    sys.exit(0)


if __name__ == "__main__":
    main()
