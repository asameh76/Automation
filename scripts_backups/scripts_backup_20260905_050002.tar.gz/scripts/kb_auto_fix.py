#!/usr/bin/env python3
"""
KB Auto Fix - Apply fixes from KB.
"""

import json
import subprocess
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
AUTO_FIX_FILE = Path("/root/.hermes/state/kb_auto_fix.json")
LOG_FILE = Path("/root/.hermes/logs/kb_auto_fix.log")


SAFE_ACTIONS = {
    "docker": ["restart", "stop", "start"],
    "systemctl": ["restart", "stop", "start"],
    "nginx": ["reload"],
}


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def is_safe(cmd):
    """Check if command is safe."""
    if not cmd:
        return False
    for service, actions in SAFE_ACTIONS.items():
        if service in cmd[0]:
            return True
    return False


def apply_fix(action):
    """Apply a fix action."""
    if not is_safe(action):
        return False, "Not in safe list"

    try:
        result = subprocess.run(action, capture_output=True, text=True, timeout=30)
        return result.returncode == 0, result.stdout
    except Exception as e:
        return False, str(e)


def main():
    log("=== KB Auto Fix started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    applied = 0
    failed = 0

    for entry in kb.get("knowledge_base", []):
        if entry.get("status") != "verified":
            continue
        for fix in entry.get("fixes", []):
            if fix.get("applied"):
                continue
            action = fix.get("action", {}).get("command", [])
            if not isinstance(action, list):
                continue
            if is_safe(action):
                success, output = apply_fix(action)
                if success:
                    fix["applied"] = True
                    fix["applied_at"] = datetime.datetime.now().isoformat()
                    applied += 1
                else:
                    failed += 1

    if applied > 0:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "applied": applied,
        "failed": failed,
    }

    AUTO_FIX_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(AUTO_FIX_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Auto Fix: {applied} applied, {failed} failed ===")


if __name__ == "__main__":
    main()
