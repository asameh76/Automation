#!/usr/bin/env python3
"""
KB Manager - KB Manager.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
MANAGER_FILE = Path("/root/.hermes/state/kb_manager.json")
LOG_FILE = Path("/root/.hermes/logs/kb_manager.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB Manager started ===")

    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": [], "version": "1.0"}

    entries = kb.get("knowledge_base", [])

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total": len(entries),
        "verified": sum(1 for e in entries if e.get("status") == "verified"),
        "investigate": sum(1 for e in entries if e.get("status") == "investigate"),
        "new": sum(1 for e in entries if e.get("status") == "new"),
        "version": kb.get("version", "1.0"),
    }

    MANAGER_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(MANAGER_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Manager: {len(entries)} entries ===")


if __name__ == "__main__":
    main()
