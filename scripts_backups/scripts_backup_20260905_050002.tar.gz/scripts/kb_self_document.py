#!/usr/bin/env python3
"""
KB Self-Document - Self-Documentation.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
DOC_FILE = Path("/root/.hermes/state/kb_self_document.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_document.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def generate_documentation():
    """Generate documentation from KB."""
    try:
        kb = read_kb()
    except Exception:
        return {}

    entries = kb.get("knowledge_base", [])
    docs = {
        "total_entries": len(entries),
        "verified": sum(1 for e in entries if e.get("status") == "verified"),
        "investigate": sum(1 for e in entries if e.get("status") == "investigate"),
        "tags": {},
        "recent_errors": [e.get("error", "")[:80] for e in entries[-5:]],
    }

    for entry in entries:
        for tag in entry.get("tags", []):
            docs["tags"][tag] = docs["tags"].get(tag, 0) + 1

    return docs


def main():
    log("=== KB Self-Document started ===")

    docs = generate_documentation()

    DOC_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DOC_FILE, "w") as fh:
        json.dump(docs, fh, indent=2)

    log(f"=== KB Self-Document: {docs.get('total_entries', 0)} entries documented ===")


if __name__ == "__main__":
    main()
