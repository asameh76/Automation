#!/bin/bash
# Cloudflare R2 Backup Sync Script
# Uploads latest backup to Cloudflare R2 and cleans local after success

BACKUP_DIR="/root/backups"
R2_BUCKET="${R2_BUCKET:-hermes-backups}"
R2_ACCOUNT_ID="${R2_ACCOUNT_ID:-}"
R2_ACCESS_KEY_ID="${R2_ACCESS_KEY_ID:-}"
R2_SECRET_ACCESS_KEY="${R2_SECRET_ACCESS_KEY:-}"

if [ -z "$R2_ACCESS_KEY_ID" ] || [ -z "$R2_SECRET_ACCESS_KEY" ]; then
    echo "ERROR: Missing R2 credentials (R2_ACCESS_KEY_ID / R2_SECRET_ACCESS_KEY)"
    exit 1
fi

# Get latest backup
LATEST=$(ls -t ${BACKUP_DIR}/root_backup_*.tar.gz 2>/dev/null | head -1)

if [ -z "$LATEST" ]; then
    echo "No backup files found in ${BACKUP_DIR}"
    exit 1
fi

FILENAME=$(basename "$LATEST")
echo "Uploading ${FILENAME} to Cloudflare R2 bucket: ${R2_BUCKET}"

# Upload using AWS CLI compatible (rclone also works)
aws --endpoint-url="https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com" \
    s3 cp "$LATEST" "s3://${R2_BUCKET}/backups/${FILENAME}" \
    --access-key="$R2_ACCESS_KEY_ID" \
    --secret-key="$R2_SECRET_ACCESS_KEY"

if [ $? -eq 0 ]; then
    echo "Upload successful. Deleting local copy to save disk space."
    rm -f "$LATEST"
    echo "Local backup ${FILENAME} deleted."
else
    echo "ERROR: Failed to upload to R2"
    exit 1
fi

# Clean up old R2 backups (keep last 5)
echo "Pruning R2 bucket (keeping last 5 backups)"
aws --endpoint-url="https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com" \
    s3 ls "s3://${R2_BUCKET}/backups/" \
    --access-key="$R2_ACCESS_KEY_ID" \
    --secret-key="$R2_SECRET_ACCESS_KEY" | \
    sort -r | tail -n +6 | awk '{print $3}' | while read key; do
        echo "Deleting old remote backup: $key"
        aws --endpoint-url="https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com" \
            s3 rm "s3://${R2_BUCKET}/${key}" \
            --access-key="$R2_ACCESS_KEY_ID" \
            --secret-key="$R2_SECRET_ACCESS_KEY"
    done