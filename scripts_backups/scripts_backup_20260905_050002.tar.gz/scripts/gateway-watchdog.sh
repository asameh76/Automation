#!/bin/bash
# Restart gateway if context overflow detected in logs
if grep -q "maximum context length" /root/.hermes/logs/*.log 2>/dev/null; then
    echo "$(date): Context overflow detected — restarting gateway" >> /root/.hermes/logs/gateway-watchdog.log
    systemctl --user restart hermes-gateway
    # Clear the error log to avoid repeated triggers
    > /root/.hermes/logs/errors.log
fi
