#!/usr/bin/env python3
"""
KB Self-Debug — Auto-diagnose and fix broken scripts.

Monitors /root/.hermes/logs/ for Python tracebacks, identifies error types,
suggests fixes, and optionally applies them. Writes a debug report and
backports fixes to the broken script with a timestamped backup.

Usage:
    python kb_self_debug.py                 # One-shot: scan logs, diagnose, apply
    python kb_self_debug.py --watch         # Watchdog loop ( Ctrl-C to stop )
    python kb_self_debug.py --watch --fix   # Watchdog + auto-apply confident fixes
    python kb_self_debug.py --file <path>   # Diagnose a specific script
    python kb_self_debug.py --traceback "..."  # Diagnose from a raw traceback string
"""

import argparse
import datetime
import difflib
import fcntl
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from textwrap import dedent

# ── paths ────────────────────────────────────────────────────────────────────

HERMES_ROOT = Path("/root/.hermes")
LOGS_DIR     = HERMES_ROOT / "logs"
SCRIPTS_DIR  = HERMES_ROOT / "scripts"
KB_FILE      = HERMES_ROOT / "error-knowledge-base.json"
STATE_DIR    = HERMES_ROOT / "state"
REPORT_FILE  = STATE_DIR / "kb_self_debug_report.json"
LOG_FILE     = LOGS_DIR   / "kb_self_debug.log"

STATE_DIR.mkdir(parents=True, exist_ok=True)

# ── logging ─────────────────────────────────────────────────────────────────

def log(msg: str, fp=None):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    line = f"[{ts}] {msg}"
    print(line, file=fp or sys.stdout)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")

# ── traceback parsing ─────────────────────────────────────────────────────────

TRACEBACK_RE = re.compile(
    r'(?P<trace>(?:  File "(?P<file>.+?)", line (?P<line>\d+).*\n(?:    .*\n)?)+)'
    r'(?P<err_type>[A-Za-z_]\w*Error(?:匠[^\n]*)?): (?P<err_msg>[^\n]+)\n',
    re.MULTILINE,
)

SYNTAX_ERROR_RE = re.compile(
    r'SyntaxError: ([^\n]+)\n'
    r'(?:  File "(.+?)", line (?:\d+)\n(?:    .*\n)?)+',
    re.MULTILINE,
)


def parse_traceback(text: str):
    """Return list of {file, line, func, code, err_type, err_msg, trace} dicts."""
    findings = []
    for m in TRACEBACK_RE.finditer(text):
        d = m.groupdict()
        # extract function names from trace lines
        funcs = re.findall(r'File ".+?", line \d+(?:, in (.+))?', m.group("trace"))
        # grab the offending line
        code_lines = re.findall(r'    (.*)', m.group("trace"))
        code = code_lines[-1].strip() if code_lines else ""
        try:
            lineno = int(d["line"])
        except (TypeError, ValueError):
            lineno = 0
        findings.append({
            "file":    d["file"],
            "line":    lineno,
            "funcs":   funcs,
            "code":    code,
            "err_type": d["err_type"],
            "err_msg":  d["err_msg"],
            "trace":   m.group("trace"),
        })
    # SyntaxError has a different layout
    for m in SYNTAX_ERROR_RE.finditer(text):
        findings.append({
            "file":    m.group(2) or "<?>",
            "line":    0,
            "funcs":   [],
            "code":    "",
            "err_type": "SyntaxError",
            "err_msg":  m.group(1),
            "trace":   m.group(0),
        })
    return findings


def extract_error_type(trace_text: str) -> str:
    """Quick classification of the error category."""
    if "SyntaxError" in trace_text:
        return "SyntaxError"
    if "IndentationError" in trace_text:
        return "IndentationError"
    if "TabError" in trace_text:
        return "TabError"
    if "ImportError" in trace_text:
        return "ImportError"
    if "ModuleNotFoundError" in trace_text:
        return "ModuleNotFoundError"
    if "AttributeError" in trace_text:
        return "AttributeError"
    if "TypeError" in trace_text:
        return "TypeError"
    if "ValueError" in trace_text:
        return "ValueError"
    if "RuntimeError" in trace_text:
        return "RuntimeError"
    if "KeyError" in trace_text:
        return "KeyError"
    if "IndexError" in trace_text:
        return "IndexError"
    if "FileNotFoundError" in trace_text or "FileExistsError" in trace_text:
        return "FileNotFoundError"
    if "PermissionError" in trace_text:
        return "PermissionError"
    if "TimeoutError" in trace_text or "timed out" in trace_text.lower():
        return "TimeoutError"
    if "JSONDecodeError" in trace_text:
        return "JSONDecodeError"
    if "CalledProcessError" in trace_text:
        return "CalledProcessError"
    return "RuntimeError"


# ── fix knowledge base ───────────────────────────────────────────────────────

def get_builtin_fixes() -> dict:
    """Heuristic fix rules keyed by (error_type, pattern fragment)."""
    return {

        ("ModuleNotFoundError", "No module named"):
            lambda d: {
                "confidence": 0.9,
                "fix_type": "import",
                "action": "install_missing_module",
                "detail": d["err_msg"].split(" named ")[-1].strip("'\"") if " named " in d["err_msg"] else d["err_msg"],
                "script_patch": None,
                "description": "Install missing pip package",
                "command": f"pip install {d['err_msg'].split()[-1].strip(chr(34))}",
            },

        ("ImportError", ""):
            lambda d: {
                "confidence": 0.7,
                "fix_type": "import",
                "action": "check_import",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Check import path / circular import",
                "command": None,
            },

        ("SyntaxError", ""):
            lambda d: {
                "confidence": 0.95,
                "fix_type": "syntax",
                "action": "syntax_check",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Fix syntax error — manual review required",
                "command": f"python3 -m py_compile {d.get('file', '')}",
            },

        ("IndentationError", ""):
            lambda d: {
                "confidence": 0.9,
                "fix_type": "indentation",
                "action": "fix_indentation",
                "detail": d["err_msg"],
                "script_patch": {"method": "auto_indent"},
                "description": "Fix indentation (use python3 -m indent on file)",
                "command": None,
            },

        ("AttributeError", ""):
            lambda d: {
                "confidence": 0.7,
                "fix_type": "attribute",
                "action": "check_attribute",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Check attribute/method name or import",
                "command": None,
            },

        ("TypeError", ""):
            lambda d: {
                "confidence": 0.6,
                "fix_type": "type",
                "action": "check_types",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Check argument types / wrong API usage",
                "command": None,
            },

        ("ValueError", ""):
            lambda d: {
                "confidence": 0.6,
                "fix_type": "value",
                "action": "check_value",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Check value passed to function",
                "command": None,
            },

        ("FileNotFoundError", ""):
            lambda d: {
                "confidence": 0.9,
                "fix_type": "file",
                "action": "create_path",
                "detail": d["err_msg"],
                "script_patch": {"method": "ensure_dir"},
                "description": "Create missing directory or file",
                "command": None,
            },

        ("KeyError", ""):
            lambda d: {
                "confidence": 0.7,
                "fix_type": "key",
                "action": "check_dict_key",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Key missing from dict — use .get() or check key exists",
                "command": None,
            },

        ("IndexError", ""):
            lambda d: {
                "confidence": 0.7,
                "fix_type": "index",
                "action": "check_index_bounds",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Index out of range — check list bounds",
                "command": None,
            },

        ("JSONDecodeError", ""):
            lambda d: {
                "confidence": 0.9,
                "fix_type": "json",
                "action": "validate_json",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Invalid JSON — check file content",
                "command": None,
            },

        ("PermissionError", ""):
            lambda d: {
                "confidence": 0.9,
                "fix_type": "permission",
                "action": "chmod_file",
                "detail": d["err_msg"],
                "script_patch": None,
                "description": "Fix file permissions",
                "command": f"chmod 644 {d.get('file', '')}",
            },
    }


def get_kb_fixes(kb: dict, err_type: str, file_path: str, err_msg: str) -> list:
    """Query the error-knowledge-base.json for matching fixes."""
    fixes = []
    for entry in kb.get("knowledge_base", []):
        # match by error type
        if entry.get("error_type") != err_type:
            continue
        for fix in entry.get("fixes", []):
            fixes.append({**fix, "source": "kb", "confidence": fix.get("confidence", 0.8)})
    return fixes


def diagnose_one(findings: dict, kb: dict) -> dict:
    """Return a diagnosis dict for one parsed traceback entry."""
    err_type = findings["err_type"]
    err_msg  = findings["err_msg"]
    file_path = findings["file"]
    line     = findings["line"]
    code     = findings["code"]

    # 1. Try KB
    kb_fixes = get_kb_fixes(kb, err_type, file_path, err_msg)

    # 2. Try builtin heuristics
    builtin_fixes = get_builtin_fixes()
    builtin = None
    for (etype, epat), fn in builtin_fixes.items():
        if etype == err_type and (epat == "" or epat in err_msg):
            try:
                builtin = fn(findings)
            except Exception:
                builtin = None
            break

    # choose best fix
    if kb_fixes and builtin:
        fixes = sorted(kb_fixes + [builtin], key=lambda x: x.get("confidence", 0), reverse=True)
    elif kb_fixes:
        fixes = kb_fixes
    elif builtin:
        fixes = [builtin]
    else:
        fixes = []

    best = fixes[0] if fixes else None

    diagnosis = {
        "file":       file_path,
        "line":       line,
        "err_type":   err_type,
        "err_msg":    err_msg,
        "offending":  code,
        "funcs":       findings.get("funcs", []),
        "trace":       findings.get("trace", ""),
        "best_fix":   best,
        "all_fixes":  fixes,
        "fixable":    best is not None and best.get("confidence", 0) >= 0.7,
        "timestamp":  datetime.datetime.now().isoformat(timespec="seconds"),
    }
    return diagnosis


# ── script patching ──────────────────────────────────────────────────────────

def backup_script(path: Path) -> Path:
    """Create a timestamped backup of the script."""
    bak = Path(str(path) + f".bak.{datetime.datetime.now():%Y%m%d_%H%M%S}")
    shutil.copy2(path, bak)
    return bak


def fix_syntax_error(path: Path) -> str | None:
    """Attempt to auto-fix simple syntax issues."""
    try:
        import ast
        with open(path) as fh:
            src = fh.read()
        ast.parse(src)
        return None  # already valid
    except SyntaxError as e:
        # try to fix common issues
        with open(path) as fh:
            src = fh.read()
        original = src
        # fix: trailing whitespace / invisible chars on problem line
        lines = src.splitlines(keepends=True)
        if e.lineno and e.lineno <= len(lines):
            lines[e.lineno - 1] = lines[e.lineno - 1].rstrip() + "\n"
            src = "".join(lines)
        try:
            ast.parse(src)
            with open(path, "w") as fh:
                fh.write(src)
            return f"Fixed trailing whitespace on line {e.lineno}"
        except SyntaxError:
            return None


def ensure_dir_for_file(path: Path, err_msg: str) -> str | None:
    """If the error is a missing directory, create it."""
    # extract path from FileNotFoundError
    m = re.search(r"'(/[^']+)'", err_msg)
    if not m:
        return None
    target = Path(m.group(1))
    if target.exists():
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        return f"Created directory {target.parent}"
    except Exception as e:
        return f"Could not create dir: {e}"


def apply_script_fix(path: Path, diagnosis: dict) -> dict:
    """Apply the best fix to a broken script. Returns result."""
    result = {"path": str(path), "applied": False, "action": "", "detail": ""}
    best = diagnosis.get("best_fix")
    if not best:
        result["detail"] = "No known fix available"
        return result

    action = best.get("action", "")
    err_type = diagnosis["err_type"]

    # backup first
    try:
        backup_path = backup_script(path)
        result["backup"] = str(backup_path)
    except Exception as e:
        result["detail"] = f"Backup failed: {e}"
        return result

    # try to apply the fix
    if err_type == "FileNotFoundError" and action == "create_path":
        detail = ensure_dir_for_file(path, diagnosis["err_msg"])
        if detail:
            result["applied"] = True
            result["action"] = action
            result["detail"] = detail
            return result

    if err_type in ("SyntaxError", "IndentationError") and action == "syntax_check":
        detail = fix_syntax_error(path)
        if detail:
            result["applied"] = True
            result["action"] = action
            result["detail"] = detail
            return result
        result["detail"] = "Could not auto-fix syntax — manual review required"
        return result

    if best.get("command"):
        cmd = best["command"]
        try:
            cp = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
            if cp.returncode == 0:
                result["applied"] = True
                result["action"] = action
                result["detail"] = f"Ran: {cmd} → OK"
            else:
                result["detail"] = f"Command failed: {cmd} → {cp.stderr[:200]}"
        except Exception as e:
            result["detail"] = f"Command error: {e}"
        return result

    result["detail"] = f"Action '{action}' requires manual intervention"
    return result


# ── log scanning ─────────────────────────────────────────────────────────────

def scan_log_for_errors(log_path: Path) -> str:
    """Read the tail of a log file, return text containing errors."""
    try:
        with open(log_path) as fh:
            lines = fh.readlines()
        # return last 200 lines that contain 'Error' or 'Traceback'
        error_lines = []
        capture = False
        for line in lines[-500:]:
            if "Error" in line or "Traceback" in line or "error" in line.lower():
                capture = True
            if capture:
                error_lines.append(line)
                if len(error_lines) > 200:
                    error_lines.pop(0)
        return "".join(error_lines)
    except Exception:
        return ""


def get_recent_tracebacks() -> list[dict]:
    """Scan all Hermes log files for Python tracebacks."""
    all_findings = []
    seen_hashes = set()

    for log_path in sorted(LOGS_DIR.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]:
        text = scan_log_for_errors(log_path)
        if not text:
            continue
        findings = parse_traceback(text)
        for f in findings:
            # dedupe by (file, line, err_type)
            h = hashlib.md5(f"{f['file']}:{f['line']}:{f['err_type']}".encode()).hexdigest()
            if h not in seen_hashes:
                seen_hashes.add(h)
                f["log_file"] = str(log_path)
                all_findings.append(f)
    return all_findings


# ── main diagnosis + fix flow ────────────────────────────────────────────────

def load_kb() -> dict:
    try:
        with open(KB_FILE) as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
            try:
                return json.load(fh)
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    except Exception:
        return {"knowledge_base": []}


def run_diagnosis(fix: bool = False) -> dict:
    """Full diagnosis + optional fix flow. Returns report dict."""
    kb = load_kb()
    findings = get_recent_tracebacks()

    report = {
        "timestamp":    datetime.datetime.now().isoformat(timespec="seconds"),
        "logs_scanned": str(LOGS_DIR),
        "tracebacks_found": len(findings),
        "diagnoses": [],
        "fixes_applied": [],
        "fixes_failed":  [],
    }

    for finding in findings:
        diag = diagnose_one(finding, kb)
        report["diagnoses"].append(diag)
        log(f"[DIAG]  {diag['file']}:{diag['line']} → {diag['err_type']}: {diag['err_msg'][:80]}")

        if fix and diag.get("fixable"):
            script_path = Path(diag["file"])
            if script_path.exists() and script_path.is_relative_to(SCRIPTS_DIR):
                result = apply_script_fix(script_path, diag)
                report["fixes_applied"].append(result)
                status = "APPLIED" if result["applied"] else "FAILED"
                log(f"[{status}] {result['action']}: {result['detail']}")
            else:
                log(f"[SKIP]  Not a Hermes scripts dir or file not found: {diag['file']}")

    # write report
    with open(REPORT_FILE, "w") as fh:
        json.dump(report, fh, indent=2)

    log(f"=== KB Self-Debug complete: {len(report['diagnoses'])} diagnosed, "
        f"{len(report['fixes_applied'])} fixes applied, "
        f"{len(report['fixes_failed'])} failed ===")
    return report


def diagnose_file(file_path: str) -> dict:
    """Diagnose a specific file by running it and capturing stderr."""
    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    try:
        cp = subprocess.run(
            ["python3", "-m", "py_compile", str(path)],
            capture_output=True, text=True, timeout=30,
        )
    except Exception as e:
        return {"error": str(e)}

    # If py_compile failed, parse the error
    if cp.returncode != 0:
        findings = parse_traceback(cp.stderr)
        kb = load_kb()
        diagnoses = [diagnose_one(f, kb) for f in findings]
        return {"file": str(path), "diagnoses": diagnoses, "compilation_errors": len(diagnoses)}

    return {"file": str(path), "diagnoses": [], "status": "OK — no syntax errors"}


def diagnose_traceback_string(traceback_str: str) -> dict:
    """Diagnose from a raw traceback string (e.g. passed on CLI)."""
    findings = parse_traceback(traceback_str)
    kb = load_kb()
    diagnoses = [diagnose_one(f, kb) for f in findings]
    return {"diagnoses": diagnoses, "count": len(diagnoses)}


# ── watchdog mode ────────────────────────────────────────────────────────────

def get_log_mtimes() -> dict:
    """Return {log_path: mtime} for all Hermes log files."""
    return {str(p): p.stat().st_mtime for p in LOGS_DIR.glob("*.log")}


def watch_loop(interval: int = 10, auto_fix: bool = False):
    """Watch log files for new tracebacks, run diagnosis on changes."""
    log("=== KB Self-Debug watch mode started ===")
    last_mtimes = get_log_mtimes()
    last_size   = {p: Path(p).stat().st_size for p in last_mtimes}
    processed_at = datetime.datetime.now()

    while True:
        time.sleep(interval)
        current_mtimes = get_log_mtimes()
        new_files = [p for p, mt in current_mtimes.items() if p not in last_mtimes or mt > last_mtimes[p]]

        if new_files:
            log(f"New/modified log files detected: {new_files}")
            report = run_diagnosis(fix=auto_fix)
            for diag in report.get("diagnoses", []):
                print(json.dumps(diag, indent=2))

        last_mtimes = current_mtimes
        last_size   = {str(p): Path(p).stat().st_size for p in LOGS_DIR.glob("*.log")}


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="KB Self-Debug: auto-diagnose and fix broken scripts")
    ap.add_argument("--watch",    action="store_true", help="Watchdog loop")
    ap.add_argument("--fix",      action="store_true", help="Auto-apply fixes (use with --watch or solo)")
    ap.add_argument("--file",     metavar="PATH", help="Diagnose a specific script file")
    ap.add_argument("--traceback", metavar="TEXT", help="Diagnose from a raw traceback string")
    ap.add_argument("--interval", type=int, default=10, metavar="N",
                    help="Watchdog poll interval in seconds (default: 10)")
    args = ap.parse_args()

    log("=== KB Self-Debug started ===")

    if args.watch:
        watch_loop(interval=args.interval, auto_fix=args.fix)
    elif args.file:
        result = diagnose_file(args.file)
        print(json.dumps(result, indent=2))
        diags = result.get("diagnoses") or []
        top = diags[0] if diags else {}
        log(f"File diagnosis: {args.file} → {top.get('err_type', result.get('status', '?'))}")
    elif args.traceback:
        result = diagnose_traceback_string(args.traceback)
        print(json.dumps(result, indent=2))
        log(f"Traceback diagnosis: {result['count']} issue(s) found")
    else:
        report = run_diagnosis(fix=args.fix)
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
