#!/usr/bin/env python3
"""
KB Self-Certify - KB Self-Certify.
Confidence scores based on log evidence.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
CERTIFY_FILE = Path("/root/.hermes/state/kb_certify.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_certify.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_errors():
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            return fh.read()
    except Exception:
        return ""


def compute_confidence(entry, errors_text):
    """Compute confidence score for a KB entry."""
    score = 0.0
    error_pattern = entry.get("error", "").lower()

    # Evidence in logs
    if error_pattern and error_pattern in errors_text.lower():
        score += 0.3

    # Has fixes
    fixes = entry.get("fixes", [])
    if fixes:
        score += 0.2

    # Fix has evidence
    for fix in fixes:
        if fix.get("evidence"):
            score += 0.2
        if fix.get("applied"):
            score += 0.15

    # Status
    if entry.get("status") == "verified":
        score += 0.15

    return min(1.0, score)


def main():
    log("=== KB Self-Certify started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    errors_text = read_errors()
    entries = kb.get("knowledge_base", [])

    certified = 0
    for entry in entries:
        conf = compute_confidence(entry, errors_text)
        entry["confidence"] = round(conf, 2)
        if conf >= 0.7:
            entry["certified"] = True
            certified += 1
        else:
            entry["certified"] = False

    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    certify_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total": len(entries),
        "certified": certified,
        "avg_confidence": round(sum(e.get("confidence", 0) for e in entries) / len(entries), 2) if entries else 0,
    }

    CERTIFY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CERTIFY_FILE, "w") as fh:
        json.dump(certify_state, fh, indent=2)

    log(f"=== KB Self-Certify: {certified}/{len(entries)} certified ===")


if __name__ == "__main__":
    main()
