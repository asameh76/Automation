#!/bin/bash
# ONE-COMMAND DISASTER RESTORE
# Download this file, put it and the capsule in the same folder, run:
#   bash restore-capsule.sh
set -e

CAPSULE="survival-capsule.tar.gz"

if [ ! -f "$CAPSULE" ]; then
    echo "ERROR: Put this script next to $CAPSULE and run again."
    exit 1
fi

echo "Restoring from capsule..."
tar -xzf "$CAPSULE"
cp -f .env ~/.hermes-keys/ 2>/dev/null || true
cp -rf hermes/* ~/.hermes/ 2>/dev/null || true
echo "✅ Restored! Run: hermes gateway restart"
