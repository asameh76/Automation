#!/usr/bin/env python3
"""
KB Archive Retrieve - Archive retrieval.
"""

import json
import tarfile
import datetime
from pathlib import Path


CAPSULE_DIR = Path("/root/.hermes/capsule")
RETRIEVE_FILE = Path("/root/.hermes/state/kb_archive_retrieve.json")
LOG_FILE = Path("/root/.hermes/logs/kb_archive_retrieve.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def list_capsules():
    capsules = []
    if CAPSULE_DIR.exists():
        for c in CAPSULE_DIR.glob("capsule-*.tar.gz"):
            capsules.append({
                "name": c.name,
                "size": c.stat().st_size,
                "modified": datetime.datetime.fromtimestamp(c.stat().st_mtime).isoformat(),
            })
    return capsules


def retrieve_capsule(name):
    """Extract a capsule to temp."""
    capsule_path = CAPSULE_DIR / name
    if not capsule_path.exists():
        return False, "Capsule not found"

    extract_dir = Path("/tmp/kb_archive_retrieve")
    extract_dir.mkdir(parents=True, exist_ok=True)

    try:
        with tarfile.open(capsule_path, "r:gz") as tar:
            tar.extractall(extract_dir)
        return True, str(extract_dir)
    except Exception as e:
        return False, str(e)


def main():
    log("=== KB Archive Retrieve started ===")

    capsules = list_capsules()

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "available_capsules": capsules,
    }

    RETRIEVE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(RETRIEVE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Archive Retrieve: {len(capsules)} capsules available ===")


if __name__ == "__main__":
    main()
