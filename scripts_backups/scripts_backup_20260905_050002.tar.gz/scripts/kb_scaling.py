#!/usr/bin/env python3
"""
KB Scaling - Predictive Scaling.
"""

import json
import subprocess
import datetime
from pathlib import Path


METRICS_FILE = Path("/root/.hermes/state/kb_sys_metrics.json")
SCALING_FILE = Path("/root/.hermes/state/kb_scaling.json")
LOG_FILE = Path("/root/.hermes/logs/kb_scaling.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def get_load():
    try:
        with open("/proc/loadavg") as fh:
            return float(fh.read().split()[0])
    except Exception:
        return 0.0


def get_memory_percent():
    try:
        with open("/proc/meminfo") as fh:
            lines = fh.readlines()
        total = 0
        avail = 0
        for line in lines:
            if line.startswith("MemTotal:"):
                total = int(line.split()[1])
            elif line.startswith("MemAvailable:"):
                avail = int(line.split()[1])
        if total:
            return int(((total - avail) / total) * 100)
    except Exception:
        pass
    return 0


def get_docker_count():
    try:
        result = subprocess.run(
            ["docker", "ps", "-q"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return len(result.stdout.strip().split("\n"))
    except Exception:
        return 0


def scale_recommend():
    """Recommend scaling actions based on metrics."""
    load = get_load()
    mem = get_memory_percent()
    containers = get_docker_count()

    actions = []
    if load > 8:
        actions.append({"type": "scale_up", "reason": f"High load: {load}"})
    elif load < 1:
        actions.append({"type": "scale_down", "reason": f"Low load: {load}"})

    if mem > 90:
        actions.append({"type": "memory_pressure", "reason": f"Memory at {mem}%"})

    if containers > 20:
        actions.append({"type": "many_containers", "reason": f"{containers} containers running"})

    return {
        "load": load,
        "memory_percent": mem,
        "docker_containers": containers,
        "recommended_actions": actions,
    }


def main():
    log("=== KB Scaling started ===")

    metrics = scale_recommend()

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "metrics": metrics,
    }

    SCALING_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SCALING_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    actions_count = len(metrics.get("recommended_actions", []))
    log(f"=== KB Scaling: {actions_count} actions recommended ===")


if __name__ == "__main__":
    main()
