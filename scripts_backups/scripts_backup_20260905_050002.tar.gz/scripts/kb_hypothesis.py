#!/usr/bin/env python3
"""
KB Hypothesis - Hypothesis Generator.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
HYP_FILE = Path("/root/.hermes/state/kb_hypothesis.json")
LOG_FILE = Path("/root/.hermes/logs/kb_hypothesis.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def generate_hypotheses():
    """Generate hypotheses from KB patterns."""
    try:
        kb = read_kb()
    except Exception:
        return []

    entries = kb.get("knowledge_base", [])
    hypotheses = []

    # Group by tag
    by_tag = {}
    for entry in entries:
        for tag in entry.get("tags", []):
            if tag not in by_tag:
                by_tag[tag] = []
            by_tag[tag].append(entry)

    for tag, tag_entries in by_tag.items():
        if len(tag_entries) >= 2:
            hypotheses.append({
                "type": "correlation",
                "tag": tag,
                "count": len(tag_entries),
                "hypothesis": f"Multiple {tag} errors may share a common root cause",
            })

    # Multiple failures of same fix
    fix_counts = {}
    for entry in entries:
        for fix in entry.get("fixes", []):
            desc = fix.get("description", "")
            if desc and fix.get("failed"):
                fix_counts[desc] = fix_counts.get(desc, 0) + 1

    for desc, count in fix_counts.items():
        if count >= 2:
            hypotheses.append({
                "type": "fix_ineffective",
                "description": desc[:60],
                "count": count,
                "hypothesis": f"Fix '{desc[:40]}' has failed {count} times, may need revision",
            })

    return hypotheses


def main():
    log("=== KB Hypothesis started ===")

    hypotheses = generate_hypotheses()

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "hypotheses": hypotheses,
    }

    HYP_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(HYP_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Hypothesis: {len(hypotheses)} hypotheses generated ===")


if __name__ == "__main__":
    main()
