#!/usr/bin/env python3
"""
Service Auto-Recovery — watchdog that restarts dead Hermes/VPS services
Runs every 5 min via cron. Restarts what it can autonomously.
Logs everything; Telegram alert only when recovery fails.
"""
import subprocess, json, os, sys, re
from pathlib import Path
from datetime import datetime

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = "864983959"
STATE_FILE         = Path("/root/.hermes/state/service_auto_recovery.json")
LOG_FILE           = Path("/root/.hermes/logs/service_auto_recovery.log")
LOCK_FILE          = Path("/root/.hermes/state/service_auto_recovery.lock")

# Docker containers we monitor (Docker daemon must be running)
DOCKER_CONTAINERS = [
    "postiz",
    "postiz-redis",
    "postiz-postgres",
]

# Services we monitor and can restart (systemd)
SAFE_TO_RESTART = [
    "hermes-gateway.service",
    "caddy.service",
]

# Load env
subprocess.run("export $(grep -v '^#' /root/.hermes-keys/.env | xargs) 2>/dev/null; true", shell=True)

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[SVC-RECOVERY {ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def send_telegram(msg):
    if not TELEGRAM_BOT_TOKEN:
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    subprocess.run(
        ["curl", "-s", "-X", "POST", url,
         "-d", f"chat_id={TELEGRAM_CHAT_ID}",
         "-d", f"text={msg}"],
        capture_output=True)

def run(cmd, timeout=20):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    return r.stdout.strip(), r.stderr.strip(), r.returncode

def get_service_status(svc):
    """Returns (is_active: bool, details: str)."""
    out, err, rc = run(f"systemctl is-active {svc}")
    active = out.strip() == "active"
    sub_out, _, _ = run(f"systemctl show {svc} -p SubState --value 2>/dev/null")
    sub_state = sub_out.strip()
    return active, sub_state

def restart_service(svc):
    """Attempt restart. Returns (success: bool, msg: str)."""
    log(f"Attempting restart of {svc}...")
    # First try daemon-reload in case binary was updated
    run("systemctl daemon-reload")
    out, err, rc = run(f"systemctl restart {svc}")
    if rc != 0:
        return False, f"Restart failed: {err[:100]}"
    # Verify it came up
    active, sub = get_service_status(svc)
    if active:
        return True, f"{svc} restarted successfully (substate: {sub})"
    return False, f"{svc} restart command succeeded but service not active"

def load_state():
    try:
        return json.load(open(STATE_FILE))
    except:
        return {"restart_history": [], "consecutive_failures": {}}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)

def acquire_lock():
    try:
        with open(LOCK_FILE, "x") as f:
            f.write(str(os.getpid()))
        return True
    except FileExistsError:
        return False

def release_lock():
    LOCK_FILE.unlink(missing_ok=True)

def main():
    if not acquire_lock():
        log("Already running — skipping")
        return 0
    try:
        log("=== Service Auto-Recovery START ===")
        state = load_state()
        history = state.setdefault("restart_history", [])
        failures = state.setdefault("consecutive_failures", {})

        recovered = []
        failed_recovery = []
        alerts_sent = []

        for svc in SAFE_TO_RESTART:
            active, sub_state = get_service_status(svc)

            if active:
                # Reset failure counter
                if svc in failures:
                    log(f"  ✅ {svc} is healthy (was down {failures.get(svc,0)} times)")
                failures[svc] = 0
                continue

            # Service is down
            log(f"  ⚠️  {svc} is DOWN (substate: {sub_state})")
            failures[svc] = failures.get(svc, 0) + 1

            # Only attempt restart if down for 2+ consecutive checks (avoid flapping)
            if failures[svc] < 2:
                log(f"    First occurrence ({failures[svc]}), waiting before restart...")
                continue

            success, msg = restart_service(svc)
            ts = datetime.now().isoformat()

            if success:
                recovered.append(f"{svc}: {msg}")
                history.append({"svc": svc, "action": "restart", "result": "success", "ts": ts})
                failures[svc] = 0  # reset on success
                log(f"  ✅ {msg}")
            else:
                failed_recovery.append(f"{svc}: {msg}")
                history.append({"svc": svc, "action": "restart", "result": "failed", "ts": ts, "error": msg})
                log(f"  ❌ {msg}")

                # Alert after 3 consecutive failures
                if failures[svc] >= 3 and svc not in alerts_sent:
                    send_telegram(f"🚨 Service CRITICAL: {svc}\n{msg}\nManual intervention required.")
                    alerts_sent.append(svc)

        # Trim history
        state["restart_history"] = history[-50:]
        state["consecutive_failures"] = failures
        save_state(state)

        log(f"=== Service Auto-Recovery END: {len(recovered)} recovered, {len(failed_recovery)} failed ===")
        return 0 if not failed_recovery else 1
    finally:
        release_lock()

if __name__ == "__main__":
    sys.exit(main())
