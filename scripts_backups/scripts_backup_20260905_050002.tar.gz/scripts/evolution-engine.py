#!/usr/bin/env python3
"""
Evolution Engine v4 — Parallel DAG execution.
8 ops in 3 layers:
  Layer 0 (sequential): correlation, predictive  ← both write KB; serialised to prevent race
  Layer 1 (parallel): meta_learning, rank, fix_feedback, mars, autogenesis, drift, self_eval
  Layer 2 (parallel): versioning

Each layer runs concurrently. Layer N+1 starts only after all of Layer N complete.
Single KB parse, shared state with thread-safe writes.
op_self_evaluation runs every cycle — auto-detects gaps in the evolution system itself.

v4 changes (2026-09-01):
  op_correlate_errors: 7-phase rewrite — fuzzy cross-source index, full-KB temporal scan,
  per-entry fix_chains + component_dependencies, weighted correlation_score, confidence bands.
"""
import json, re, sys, datetime, random, threading
import os
from pathlib import Path
from collections import defaultdict, Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── Paths ──────────────────────────────────────────────────────
HERMES         = Path("/root/.hermes")
KB_PATH        = HERMES / "error-knowledge-base.json"
KB_VERSIONS    = HERMES / "kb-versions"
ASSET_MB       = HERMES / "asset-memory"
EXPERIENCE_MB  = HERMES / "experience-memory"
RSI_DIR        = HERMES / "rsi/resources"
EVOLUTION_LOG  = HERMES / "logs/evolution-engine.log"
HUB_LOG        = HERMES / "logs/kb-hub.log"
EVENT_BUS      = HERMES / "event-bus.jsonl"

# ── Event bus reader ──────────────────────────────────────────
def bus_read_and_process():
    """Read all events from event bus, process them into KB, return event count."""
    if not EVENT_BUS.exists():
        return 0
    lines = EVENT_BUS.read_text().splitlines()
    if not lines:
        return 0
    EVENT_BUS.write_text("")  # clear bus after reading
    kb = load_kb()
    kb.setdefault("evolution_log", [])
    processed = 0

    for line in lines:
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except Exception:
            continue

        etype = event.get("type", "unknown")
        data  = {k: v for k, v in event.items() if k not in ("type", "timestamp", "source")}
        ts    = event.get("timestamp", datetime.datetime.now().isoformat())

        # Always log to evolution_log
        kb["evolution_log"].append({"type": etype, "timestamp": ts, "source": event.get("source"), **data})
        kb["evolution_log"] = kb["evolution_log"][-500:]

        # Process each event type
        if etype == "kb_entry_created":
            sig  = data.get("signature", "")
            fix  = data.get("fix", "")
            comp = data.get("component", "unknown")
            # Ensure entry exists (daemon may have added it)
            if sig and not any(e.get("signature") == sig for e in kb["errors"]):
                kb["errors"].append({
                    "signature": sig, "fix": fix, "component": comp,
                    "verified": "false", "tech_stack": "Hermes",
                    "first_seen": datetime.date.today().isoformat(),
                    "last_seen": datetime.date.today().isoformat(),
                    "occurrence_count": 1, "auto_fixed": "false",
                    "success_count": 0, "fail_count": 0
                })
                _log(f"bus: kb_entry_created → {sig}", "bus")

        elif etype == "fix_result":
            sig     = data.get("signature", "")
            success = data.get("success", False)
            applied = data.get("fix_applied", "")
            for e in kb["errors"]:
                if e.get("signature") == sig:
                    if success:
                        e["success_count"] = e.get("success_count", 0) + 1
                    else:
                        e["fail_count"] = e.get("fail_count", 0) + 1
                    e["last_seen"] = datetime.date.today().isoformat()
                    e["occurrence_count"] = e.get("occurrence_count", 1) + 1
                    _log(f"bus: fix_result → {sig} success={success}", "bus")
                    break

        elif etype == "error_spike_new_entry":
            sig   = data.get("signature", "")
            log_f = data.get("log", "unknown")
            preview = data.get("error_preview", "")[:80]
            _log(f"bus: error_spike_new_entry → {sig} @ {log_f}: {preview}", "bus")

        elif etype == "error_spike_auto_fixed":
            sig   = data.get("signature", "")
            fix   = data.get("fix", "")
            result = data.get("result", "")[:60]
            _log(f"bus: error_spike_auto_fixed → {sig} fix={fix} result={result}", "bus")

        elif etype == "predictive_fix_applied":
            cond   = data.get("condition", "")
            result = data.get("result", "")[:60]
            _log(f"bus: predictive_fix_applied → {cond}: {result}", "bus")

        elif etype == "bash_error":
            sig    = data.get("signature", "")
            cmd    = data.get("cmd", "")[:80]
            _log(f"bus: bash_error → {sig}: {cmd}", "bus")

        elif etype == "docker_error":
            sig    = data.get("signature", "")
            log_n  = data.get("log", "")
            line   = data.get("line", "")[:80]
            _log(f"bus: docker_error [{log_n}] → {sig}: {line}", "bus")

        elif etype == "hindsight_entry":
            hid    = data.get("id", "")
            tags   = data.get("tags", "")
            content = data.get("content", "")[:80]
            _log(f"bus: hindsight_entry [{hid}] tags={tags}: {content}", "bus")

        elif etype == "session_error":
            sig    = data.get("signature", "")
            role   = data.get("role", "")
            content = data.get("content", "")[:80]
            _log(f"bus: session_error ({role}) → {sig}: {content}", "bus")

        elif etype == "git_fix":
            commit = data.get("commit", "")
            msg    = data.get("message", "")[:80]
            _log(f"bus: git_fix [{commit}] {msg}", "bus")

        elif etype in ("daemon_startup", "daemon_shutdown", "daemon_error"):
            _log(f"bus: {etype} — {data}", "bus")

        processed += 1

    save_kb(kb)
    return processed

# ── Shared state ───────────────────────────────────────────────
_kb         = None
_log_entries = []
_lock       = threading.RLock()   # thread-safe KB writes

def _log(msg, channel="engine"):
    ts   = datetime.datetime.now().isoformat()
    line = f"[{ts}] [{channel.upper()}] {msg}"
    print(line, flush=True)
    _log_entries.append(line)
    for p in [EVOLUTION_LOG, HUB_LOG]:
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a") as f:
            f.write(line + "\n")

# ── KB sync helper ─────────────────────────────────────────────
def _sync_fix_success_rates(kb):
    """Sync fix_success_rates + backfill recent_uses from KB so drift detector has signal."""
    rates = kb.get("fix_success_rates", {})
    now = datetime.datetime.now()
    for e in kb.get("errors", []):
        sig = e["signature"]
        sc = int(e.get("success_count", 0) or 0)
        fc = int(e.get("fail_count", 0) or 0)
        lu = e.get("last_used", e.get("last_seen", ""))
        if sig not in rates:
            rates[sig] = {"success": 0, "fail": 0, "recent_uses": []}
        r = rates[sig]
        r["success"] = max(r["success"], sc)
        r["fail"] = max(r["fail"], fc)
        if not r["recent_uses"] and (sc > 0 or fc > 0):
            last_ts = None
            if lu:
                try:
                    last_ts = datetime.datetime.fromisoformat(lu)
                except Exception:
                    pass
            last_ts = last_ts or now
            uses = []
            for i in range(min(sc, 10)):
                h = (i * 24) // max(sc, 1)
                uses.append({"success": True, "timestamp": (last_ts - datetime.timedelta(hours=h)).isoformat()})
            for i in range(min(fc, 5)):
                h = ((sc + i) * 24) // max(fc, 1)
                uses.append({"success": False, "timestamp": (last_ts - datetime.timedelta(hours=h)).isoformat()})
            uses.sort(key=lambda x: x["timestamp"], reverse=True)
            r["recent_uses"] = uses[-10:]
    kb["fix_success_rates"] = rates

# ── KB access (thread-safe) ───────────────────────────────────
def load_kb():
    global _kb
    if _kb is None:
        if KB_PATH.exists():
            try:
                _kb = json.loads(KB_PATH.read_text())
            except Exception as e:
                _log(f"KB parse error: {e}", "warn")
                _kb = {"errors": [], "fix_success_rates": {}, "evolution_log": [], "predictions": []}
        else:
            _kb = {"errors": [], "fix_success_rates": {}, "evolution_log": [], "predictions": []}
    return _kb

def save_kb(kb=None):
    target = kb or _kb
    KB_PATH.write_text(json.dumps(target, indent=2))

def record_event(event_type, data):
    kb = load_kb()
    kb.setdefault("evolution_log", []).append({
        "type": event_type,
        "timestamp": datetime.datetime.now().isoformat(),
        **data
    })
    kb["evolution_log"] = kb["evolution_log"][-500:]
    save_kb()

# ════════════════════════════════════════════════════════════════
# OP 1 — Cross-System Error Correlation  (Layer 0)
# ════════════════════════════════════════════════════════════════
def _extract_error_type(sig):
    """Extract the error type from a signature (ignore timestamps/PIDs)."""
    sig = sig.lower()
    for kw in ["docker_error", "nginx_error", "gateway_error", "session_error",
               "postgres_error", "redis_error", "container_restart", "cron_error",
               "memory_error", "disk_error", "backup_error", "temporal_error",
               "traceback", "connection_error", "timeout_error", "permission_error",
               "template_error", "health_check_fail"]:
        if kw in sig:
            return kw
    return "generic_error"

def _extract_error_message(sig):
    """Extract the specific error message from a signature — for docker errors,
    the real signal is the specific error text, not the timestamp."""
    sig = sig.lower()
    # Remove timestamps
    sig = re.sub(r'\d{4}[_-]\d{2}[_-]\d{2}[T _]\d{2}:\d{2}:\d{2}[^:]*(?::|\s)', ' ', sig)
    sig = re.sub(r'0x[0-9a-f]{6,}', 'HEX', sig)
    sig = re.sub(r'\b\d{5,}\b', 'N', sig)
    # Extract content after error type marker
    for marker in ['docker_error', 'nginx_error', 'gateway_error', 'session_error',
                   'connection_error', 'traceback', 'error']:
        idx = sig.rfind(marker)
        if idx >= 0:
            chunk = sig[idx:idx+80]
            chunk = re.sub(r'[\s_]+', '_', chunk)
            return chunk
    # Fallback: last meaningful chunk
    parts = sig.split()
    return '_'.join(parts[-4:]) if len(parts) >= 4 else sig[:40]

def _extract_component(sig):
    """Extract the component/service from a signature."""
    sig = sig.lower()
    for kw in ["gateway", "frontend", "backend", "nginx", "postgres", "redis",
               "postiz", "temporal", "hermes", "docker", "backup", "cron"]:
        if kw in sig:
            return kw
    return "unknown"

def _classify_fix(fix_text):
    """Classify the actual fix action from the fix field text."""
    if not fix_text:
        return "unknown"
    t = fix_text.lower()
    if "gateway-fix" in t or "gw-cycle" in t or "kill stale" in t:
        return "gateway_restart"
    if "nginx" in t and ("restart" in t or "reload" in t):
        return "nginx_restart"
    if "docker" in t and "restart" in t:
        return "container_restart"
    if "cron" in t and "restart" in t:
        return "cron_restart"
    if "memory" in t and "clean" in t:
        return "memory_cleanup"
    if "auto-memory-cleanup" in t:
        return "memory_cleanup"
    if "r2-backup" in t or "full-r2" in t:
        return "backup_retry"
    if "investigate" in t or "review" in t:
        return "needs_investigation"
    if "pre-emptive" in t:
        return "predicted_no_action"
    if "no action" in t or "noise" in t:
        return "noise_suppress"
    if "unknown" in t:
        return "unknown"
    return "general_fix"

def op_correlate_errors():
    """Strengthened correlation: per-entry fields, confidence scoring, expanded temporal window,
    cross-source tracking, fix chains and component deps written per-entry."""
    _log("OP: Cross-system error correlation [v4]", "corr")
    kb = load_kb()
    e = kb["errors"]
    today = datetime.date.today().isoformat()
    evolution_log = kb.get("evolution_log", [])

    # ── Helper: confidence from sources + co-occurrence ──────────────
    def _confidence(sources_count, cooccur_days, group_size, err):
        """low/medium/high based on multi-signal corroboration."""
        score = 0
        if sources_count >= 3: score += 4
        elif sources_count == 2: score += 2
        elif sources_count == 1: score += 1
        if cooccur_days >= 3: score += 3
        elif cooccur_days >= 1: score += 1
        if group_size >= 3: score += 1
        # Richer signals: chain leverage, component cooccurrence, verified
        chain_count = len(err.get("fix_chains", []))
        comp_cooccur = max([d.get("cooccur", 0) for d in err.get("component_dependencies", [])], default=0)
        if chain_count >= 3: score += 3
        elif chain_count >= 1: score += 1
        if comp_cooccur >= 10: score += 3
        elif comp_cooccur >= 3: score += 2
        elif comp_cooccur >= 1: score += 1
        if err.get("verified") == "true": score += 1
        if score >= 6: return "high"
        if score >= 3: return "medium"
        return "low"

    # ── Phase 1: Build correlated_sources via fuzzy generic-type match ──
    # Evolution_log sigs look like "__level___error___ts___2026_09_01..." while KB sigs
    # look like "R2_backup_aws_cli_syntax" — they don't match directly.
    # Fix: build a generic-type → KB entry index, then map evolution_log events through it.
    kb_generic_index = defaultdict(set)  # generic_type -> set of KB signatures
    for err in e:
        sig  = err.get("signature", "")
        etype = _extract_error_type(sig)
        comp  = _extract_component(sig)
        emsg  = _extract_error_message(sig)
        key   = f"{etype}::{comp}"
        kb_generic_index[key].add(sig)
        # Also index by message-based generic type for finer grain
        kb_generic_index[emsg].add(sig)

    # Now read event bus (via evolution_log which holds bus events)
    correlated_sources = defaultdict(set)  # sig -> {source names}
    for entry in evolution_log[-500:]:
        src = entry.get("source", "")
        sig = entry.get("signature", "")
        if not sig or src in ("unknown", "bus", ""):
            continue
        # Try exact KB signature match first
        if any(err.get("signature") == sig for err in e):
            correlated_sources[sig].add(src)
        else:
            # Fuzzy: extract generic type from evolution_log sig and look up in KB index
            etype = _extract_error_type(sig)
            comp  = _extract_component(sig)
            for key in [f"{etype}::{comp}", etype, _extract_error_message(sig)]:
                for kb_sig in kb_generic_index.get(key, []):
                    correlated_sources[kb_sig].add(src)

    # ── Phase 2: Multi-level clustering ──────────────────────────────
    type_groups  = defaultdict(list)   # "etype::comp" -> [errs]
    msg_groups   = defaultdict(list)   # normalized_msg -> [errs]
    source_groups = defaultdict(list)  # same generic type from different sources -> [errs]

    for err in e:
        sig   = err.get("signature", "")
        etype = _extract_error_type(sig)
        comp  = _extract_component(sig)
        emsg  = _extract_error_message(sig)
        type_groups[f"{etype}::{comp}"].append(err)
        msg_groups[emsg].append(err)

    # Cross-source groups: same error type+component from ≥2 distinct sources
    for key, group in type_groups.items():
        if len(group) >= 2:
            sources_in_group = set()
            for err in group:
                sources_in_group.update(correlated_sources.get(err.get("signature",""), []))
            if len(sources_in_group) >= 2:
                source_groups[key].append((group, sources_in_group))

    # ── Phase 3: Tag entries with correlation data ────────────────────
    tagged = 0
    for err in e:
        sig = err.get("signature", "")
        etype = _extract_error_type(sig)
        comp = _extract_component(sig)
        emsg = _extract_error_message(sig)

        # Type cluster
        type_key = f"{etype}::{comp}"
        type_group = type_groups.get(type_key, [])
        if len(type_group) >= 2:
            err["correlation_type"]       = type_key
            err["correlation_group_size"]  = len(type_group)
            sources_here = set()
            for x in type_group:
                sources_here.update(correlated_sources.get(x.get("signature",""), []))
            err["correlated_sources"]     = sorted(sources_here)
            err["correlation_confidence"] = _confidence(len(sources_here), 0, len(type_group), err)
            tagged += 1
        else:
            # Entries never grouped — still score them on fix_chains / deps / verified
            if not err.get("correlation_confidence"):
                err["correlation_confidence"] = _confidence(0, 0, 1, err)

        # Message cluster
        msg_group = msg_groups.get(emsg, [])
        if len(msg_group) >= 2:
            err["correlation_msg"]       = emsg
            err["correlation_msg_size"]  = len(msg_group)

        # Fix group
        fix = _classify_fix(err.get("fix", ""))
        if fix not in ("unknown", "predicted_no_action", "noise_suppress", "needs_investigation"):
            # count how many others share same fix type
            same_fix = [x for x in e if _classify_fix(x.get("fix","")) == fix and x is not err]
            if len(same_fix) >= 1:
                err["fix_group"]     = fix
                err["fix_group_size"] = len(same_fix) + 1

    # ── Phase 4: Temporal root-cause — full KB scan, not ±5 ─────────
    e_sorted = sorted(e, key=lambda x: x.get("first_seen", ""))
    msg_cooccur = defaultdict(lambda: {"same_day": 0, "days": set()})

    # O(n²) full scan — KB is bounded at ~78, this is fine
    for i, err1 in enumerate(e_sorted):
        for err2 in e_sorted[i+1:]:
            t1 = err1.get("first_seen", "")[:10]
            t2 = err2.get("first_seen", "")[:10]
            if not t1 or not t2 or t1 != t2:
                continue
            m1 = _extract_error_message(err1.get("signature", ""))
            m2 = _extract_error_message(err2.get("signature", ""))
            if m1 != m2:
                key = (m1, m2)
                msg_cooccur[key]["same_day"] += 1
                msg_cooccur[key]["days"].add(t1)

    # Build fix chains — per-entry + global
    fix_chains_global = []
    fix_chains_per_entry = defaultdict(list)  # sig -> [chain dicts]

    for (cause_msg, symptom_msg), data in msg_cooccur.items():
        cooccur_days = len(data["days"])
        if cooccur_days >= 1:  # was 2 — lowered to 1 with more signals
            cause_entries    = [x for x in e if _extract_error_message(x.get("signature","")) == cause_msg]
            symptom_entries  = [x for x in e if _extract_error_message(x.get("signature","")) == symptom_msg]
            if cause_entries and symptom_entries:
                best_cause   = max(cause_entries, key=lambda x: int(x.get("success_count") or 0))
                best_symptom = max(symptom_entries, key=lambda x: int(x.get("success_count") or 0))
                cause_fix   = _classify_fix(best_cause.get("fix",""))
                symptom_fix = _classify_fix(best_symptom.get("fix",""))
                if cause_fix != symptom_fix and cause_fix not in ("unknown", "predicted_no_action", "noise_suppress"):
                    chain = {
                        "if_error":     cause_msg[:50],
                        "then_fix":     cause_fix,
                        "also_resolves": symptom_msg[:50],
                        "cooccur_days": cooccur_days,
                        "confidence":   min(cooccur_days / 3, 1.0)
                    }
                    fix_chains_global.append(chain)
                    # Tag entries involved in chains
                    for sig in [cause_msg, symptom_msg]:
                        for err in e:
                            if _extract_error_message(err.get("signature","")) == sig:
                                if chain not in fix_chains_per_entry[err.get("signature","")]:
                                    fix_chains_per_entry[err.get("signature","")].append(chain)

    # Embed per-entry fix chains
    for err in e:
        sig = err.get("signature","")
        if sig in fix_chains_per_entry:
            err["fix_chains"] = fix_chains_per_entry[sig][:5]

    # ── Phase 5: Component dependency map — per-entry ───────────────
    comp_pairs = defaultdict(lambda: defaultdict(int))  # comp_a -> {comp_b: count}
    for err in e:
        comp = _extract_component(err.get("signature",""))
        if comp == "unknown":
            continue
        for other in e:
            if other is err:
                continue
            other_comp = _extract_component(other.get("signature",""))
            if other_comp != "unknown" and other_comp != comp:
                t1 = err.get("first_seen","")[:10]
                t2 = other.get("first_seen","")[:10]
                if t1 and t2 and t1 == t2:
                    comp_pairs[comp][other_comp] += 1

    strong_deps = []
    for comp_a, inner in comp_pairs.items():
        for comp_b, cnt in inner.items():
            if cnt >= 1:  # was 2 — even 1 co-occurrence is signal
                strong_deps.append((comp_a, comp_b, cnt))

    # Tag entries with their component dependencies
    for err in e:
        comp = _extract_component(err.get("signature",""))
        if comp == "unknown":
            continue
        deps = [(b, c) for a, b, c in strong_deps if a == comp]
        if deps:
            err["component_dependencies"] = [{"component": b, "cooccur": c} for b, c in deps[:5]]

    # ── Phase 6: Correlation score — weighted composite ───────────────
    for err in e:
        sig = err.get("signature","")
        cs  = correlated_sources.get(sig, set())
        cgs = err.get("correlation_group_size", 0)
        chains = err.get("fix_chains", [])
        deps   = err.get("component_dependencies", [])
        # Composite score: sources × 10 + group_size × 2 + chains × 5 + deps × 3
        score = len(cs) * 10 + cgs * 2 + len(chains) * 5 + len(deps) * 3
        err["correlation_score"] = score

    # ── Phase 7: Fix effectiveness ranking ───────────────────────────
    fix_effectiveness = defaultdict(lambda: {"success": 0, "fail": 0, "errors": []})
    for err in e:
        fix = _classify_fix(err.get("fix",""))
        sc = int(err.get("success_count") or 0)
        fc = int(err.get("fail_count") or 0)
        fix_effectiveness[fix]["success"] += sc
        fix_effectiveness[fix]["fail"]    += fc
        fix_effectiveness[fix]["errors"].append(err.get("signature","")[:40])
    if fix_effectiveness:
        kb["fix_effectiveness"] = [
            {"fix": fix, "success": d["success"], "fail": d["fail"],
             "rate": d["success"] / max(d["success"] + d["fail"], 1),
             "unique_errors": len(set(d["errors"]))}
            for fix, d in fix_effectiveness.items()
            if fix not in ("unknown", "predicted_no_action", "noise_suppress", "needs_investigation")
        ]
        kb["fix_effectiveness"].sort(key=lambda x: -x["rate"] * x["unique_errors"])

    type_cluster_count = len([g for g in type_groups.values() if len(g) > 1])
    msg_cluster_count  = len([g for g in msg_groups.values() if len(g) > 1])
    fix_group_count   = len(set(err.get("fix_group","") for err in e if err.get("fix_group")))

    _log(f"  Type clusters: {type_cluster_count}", "corr")
    _log(f"  Message clusters: {msg_cluster_count}", "corr")
    _log(f"  Fix groups: {fix_group_count}", "corr")
    _log(f"  Errors tagged: {tagged}", "corr")
    _log(f"  Fix chains: {len(fix_chains_global)}", "corr")
    _log(f"  Component deps: {len(strong_deps)}", "corr")
    _log(f"  High-confidence correlations: {sum(1 for err in e if err.get('correlation_confidence')=='high')}", "corr")

    if fix_chains_global:
        kb["fix_chains"] = fix_chains_global[:15]
    if strong_deps:
        kb["component_dependencies"] = [{"a": a, "b": b, "count": c} for a, b, c in strong_deps[:15]]

    record_event("op_correlate", {
        "type_clusters":   type_cluster_count,
        "msg_clusters":    msg_cluster_count,
        "fix_groups":     fix_group_count,
        "tagged":         tagged,
        "chains":         len(fix_chains_global),
        "dependencies":    len(strong_deps),
        "high_conf":      sum(1 for err in e if err.get('correlation_confidence') == 'high')
    })
    save_kb(kb)  # persist per-entry correlation fields
    return tagged

# ════════════════════════════════════════════════════════════════
# OP 2 — Predictive Failure Detection  (Layer 0)
# ════════════════════════════════════════════════════════════════
def _extract_sig_from_warning(text):
    text = " ".join(text.split())
    for pat in [
        r'(Warning|Warn|Deprecated|Slow|High\s+usage|performance\s+impact):\s*(.{20,120})',
        r'consider\s+(.{20,100})',
        r'might\s+(.{20,100})',
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return re.sub(r'\s+', ' ', m.group(0)[:120])
    return text[:120]

def op_predictive_detection():
    _log("OP: Predictive failure detection", "pred")
    kb   = load_kb()
    today = datetime.date.today().isoformat()
    log_dirs = [HERMES / "logs", Path("/var/log")]

    # ── Pass 1: collect all warnings, normalize by collapsing timestamps/hex ──
    norm_counts = Counter()
    norm_to_raw = {}  # normalized pattern → most-representative raw line
    for log_dir in log_dirs:
        if not log_dir.exists():
            continue
        for log_file in log_dir.rglob("*.log"):
            if log_file.name == "anomaly-daemon.log":
                continue
            try:
                for line in log_file.read_text(errors="ignore").splitlines()[-200:]:
                    line = line.strip()
                    if not line:
                        continue
                    # Skip docker/systemd bus noise — very common false positives
                    if any(n in line.lower() for n in [
                        "bus:", "docker_error", "docker.service", "session_error",
                        "gateway.run", "shutdown context", "systemd", "bus error",
                        "gateway startup", "deserializ"
                    ]):
                        continue
                    if any(kw in line.lower() for kw in ["warn", "deprecated", "slow", "high", "consider", "might", "performance"]):
                        norm = re.sub(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}\.\d+', '<TS>', line)
                        norm = re.sub(r'0x[0-9a-f]{6,}', '0xHEX', norm)
                        norm = re.sub(r'\[TS\]', '', norm)  # deduplicate identical timestamps
                        norm = norm.strip()
                        norm_counts[norm] += 1
                        if norm not in norm_to_raw:
                            norm_to_raw[norm] = line
            except Exception:
                continue

    # ── Pass 2: require ≥2 occurrences, extract stable sig, dedupe against KB ──
    MIN_OCCURRENCES = 2
    added = 0
    with _lock:
        existing_sigs = {e["signature"] for e in kb["errors"]}
        recent_sigs  = set()
        for norm, count in norm_counts.items():
            if count < MIN_OCCURRENCES:
                continue
            sig = _extract_sig_from_warning(norm)
            if not sig or len(sig) < 10:
                continue
            pred_sig = f"predictive_{sig[:80]}"
            if pred_sig in existing_sigs or pred_sig in recent_sigs:
                continue
            recent_sigs.add(pred_sig)
            raw_line = norm_to_raw[norm][:200]
            kb["errors"].append({
                "signature":           pred_sig,
                "fix":                f"Pre-emptive ({count}×): {norm[:80]}",
                "verified":           "false",
                "component":          "predictive_detection",
                "tech_stack":         "auto",
                "first_seen":        today,
                "last_seen":         today,
                "occurrence_count":  count,
                "auto_fixed":        "false",
                "success_count":     0,
                "fail_count":        0,
                "warning_raw":       raw_line,
                "correlation_confidence": "medium",  # explicit: ≥2 occurrences = medium floor
            })
            existing_sigs.add(pred_sig)
            added += 1
        save_kb()

    _log(f"  Added {added} predictive groups from {sum(norm_counts.values())} warnings (min {MIN_OCCURRENCES}×)", "pred")
    record_event("op_predictive", {"warnings_total": sum(norm_counts.values()), "groups": added})
    return added

# ════════════════════════════════════════════════════════════════
# OP 3 — Meta-Learning  (Layer 1)
# ════════════════════════════════════════════════════════════════
def _extract_features(text):
    text = (text or "").lower()
    feats = []
    if re.search(r'\b(pip|pip3|npm|yarn|apt|brew|apt-get|package)\b', text):
        feats.append("dependency_install")
    if re.search(r'\b(config|setting|conf|ini|yaml|json|env)\b', text):
        feats.append("config_change")
    if re.search(r'\b(service|systemctl|daemon|restart|reload)\b', text):
        feats.append("service_restart")
    if re.search(r'\b(file|path|dir|chmod|chown|mkdir|copy|mv)\b', text):
        feats.append("file_modification")
    if re.search(r'\b(curl|wget|http|tcp|dns|ping|network|request)\b', text):
        feats.append("network_fix")
    if re.search(r'\b(permission|chmod|chown|sudo)\b', text):
        feats.append("permission_change")
    if re.search(r'\b(update|upgrade|patch|apt install|pip install)\b', text):
        feats.append("update")
    if re.search(r'\b(docker|container|prune|image|volume)\b', text):
        feats.append("docker_cleanup")
    if re.search(r'\b(memory|ram|oom|heap|cache)\b', text):
        feats.append("memory_fix")
    if re.search(r'\b(retry|repeat|again|backoff)\b', text):
        feats.append("retry")
    return feats

def op_meta_learning():
    _log("OP: Meta-learning", "meta")
    kb = load_kb()
    # Learn from verified entries OR entries with strong success history (≥2 successes)
    verified = [e for e in kb["errors"] if e.get("verified") == "true"]
    high_confidence = [e for e in kb["errors"]
                      if e.get("verified") != "true"
                      and int(e.get("success_count", 0)) >= 2]
    training_set = verified + high_confidence
    if not training_set:
        _log("  No verified or high-confidence fixes to learn from", "meta")
        record_event("op_meta", {"status": "no_training_data"})
        return 0

    cat_features = defaultdict(Counter)
    for e in training_set:
        cat = "_".join(e.get("signature","").split("_")[:2]) or "unknown"
        for f in _extract_features(e.get("fix","")):
            cat_features[cat][f] += 1

    model = {}
    for cat, counter in cat_features.items():
        if counter:
            best = counter.most_common(1)[0]
            model[cat] = {
                "best_feature": best[0],
                "all_features": dict(counter),
                "confidence":   round(best[1] / sum(counter.values()), 2)
            }

    with _lock:
        kb["meta_model"] = model
        save_kb()

    top = sorted(model.items(), key=lambda x: x[1]["confidence"], reverse=True)[:5]
    _log(f"  Meta-model: {len(verified)} fixes → {len(model)} categories", "meta")
    for cat, m in top:
        _log(f"    [{cat}] best={m['best_feature']} conf={m['confidence']}", "meta")

    record_event("op_meta", {"verified_fixes": len(verified), "categories": len(model)})
    return len(model)

# ════════════════════════════════════════════════════════════════
# OP 4 — Rank & Score  (Layer 1)
# ════════════════════════════════════════════════════════════════
def op_rank_and_score():
    _log("OP: KB rank & score", "rank")
    kb = load_kb()
    rates = kb.get("fix_success_rates", {})

    scored = []
    for e in kb["errors"]:
        sig = e.get("signature", "")
        r   = rates.get(sig, {})
        s, f = r.get("success", 0), r.get("fail", 0)
        total = s + f
        sr    = s / total if total > 0 else 0.0
        vs    = sr * min(total, 10)
        e["success_rate"] = round(sr, 3)
        e["total_uses"]   = total
        e["value_score"]  = round(vs, 3)
        scored.append(e)

    scored.sort(key=lambda x: x["value_score"], reverse=True)

    # Cleanup: prune stale noise
    # Keep: verified OR has successes OR recent auto_fixed OR (critical component)
    # Remove: old unverified entries with zero successes and never auto-fixed
    KEEP_COMPONENTS = {
        "gateway", "system", "core", "hermes", "docker", "disk", "r2", "backup",
        "cron", "postiz", "temporal", "log", "entropy", "config", "drift",
        "canary", "github", "dep", "openai", "api", "code", "introspect",
        "synthetic", "seo", "session", "entropy", "topology", "network",
        "email", "memory", "postgres", "redis", "nginx", "hetzner", "cloudflare",
        "curiosity", "self_editing", "telegram", "backup_infrastructure"
    }
    errors_all = scored
    scored = [
        e for e in errors_all
        if not (
            e.get("verified") != "true"
            and int(e.get("success_count", 0)) == 0
            and e.get("auto_fixed", "false") == "false"
            and e.get("component", "").lower() not in KEEP_COMPONENTS
            and not any(k in str(e.get("cluster_id", "")).lower() for k in KEEP_COMPONENTS)
        )
    ]

    # Enforce window_size floor — never prune below window if KB has it configured
    window_size = kb.get("window_size", 200)
    if len(scored) < window_size:
        # Sort pruned candidates by score descending, pull back just enough to fill to window
        pruned_candidates = [e for e in errors_all if e not in scored]
        pruned_candidates.sort(key=lambda x: x.get("success_rate", 0) * x.get("total_uses", 0), reverse=True)
        slots_free = window_size - len(scored)
        for e in pruned_candidates[:slots_free]:
            e["auto_retired"] = "false"  # undo retirement flag
        scored.extend(pruned_candidates[:slots_free])
        _log(f"  Window floor restored: +{min(slots_free, len(pruned_candidates))} entries to meet window_size={window_size}", "rank")

    cleaned = len(errors_all) - len(scored)
    if cleaned:
        _log(f"  Pruned {cleaned} stale predictive entries", "rank")

    with _lock:
        kb["errors"] = scored
        save_kb()

    _log(f"  Ranked {len(scored)} entries (cleaned {cleaned})")
    for e in scored[:5]:
        _log(f"    [{e['success_rate']:.0%}×{e['total_uses']}] {e['signature'][:50]}", "rank")

    record_event("op_rank", {"total": len(scored), "top_sig": scored[0]["signature"] if scored else None})
    return scored

# ════════════════════════════════════════════════════════════════
# OP 6 — Fix Feedback Loop  (Layer 1)
# Closes the loop: KB auto-fixes → daemon applies → success recorded back to KB
# ════════════════════════════════════════════════════════════════
def op_fix_feedback_loop():
    _log("OP: Fix feedback loop", "fbl")
    kb = load_kb()

    # Count how many KB entries are "actionable" (have a fix + verified)
    errors = kb.get("errors", [])
    actionable = [e for e in errors if e.get("fix") and e.get("fix") not in ("Investigate", "No automated fix")]
    verified   = [e for e in actionable if e.get("verified") == "true"]
    unverified = [e for e in actionable if e.get("verified") != "true"]

    # For unverified entries: require BOTH reliability (success_rate) AND frequency
    # to be promoted to verified. Pure frequency traps (auto_fixed many, succeeded 0)
    # must not be promoted without actual successes.
    promoted = 0
    for e in unverified:
        af_raw = e.get("auto_fixed", 0)
        try:
            af = int(af_raw)
        except (ValueError, TypeError):
            af = 1 if str(af_raw).lower() in ("true", "yes", "1") else 0
        sc = int(e.get("success_count", 0))
        sr = float(e.get("success_rate", 0))
        # Require: ≥1 success AND (success_rate ≥ 0.5 OR ≥3 successes) to promote
        if sc >= 1 and (sr >= 0.5 or sc >= 3):
            e["verified"] = "true"
            promoted += 1

    # For verified entries that haven't been used in 7 days, check if they're still relevant
    stale_verified = []
    for e in verified:
        last = e.get("last_used", e.get("first_seen", ""))
        if last:
            try:
                days_since = (datetime.datetime.now() - datetime.datetime.fromisoformat(last)).days
                if days_since > 14:
                    stale_verified.append(e["signature"])
            except Exception:
                pass

    if promoted:
        _log(f"  ↑ {promoted} entries auto-verified (3+ auto_fixed or successes)", "fbl")
    if stale_verified:
        _log(f"  ⚠ {len(stale_verified)} verified entries unused >14 days", "fbl")

    # Update fix success rate stats
    rates = kb.get("fix_success_rates", {})
    fixes_by_type = {}
    for e in errors:
        ft = e.get("fix_type", "unknown")
        fixes_by_type.setdefault(ft, {"success": 0, "fail": 0, "total": 0})
        if e.get("verified") == "true":
            sc = int(e.get("success_count", 0))
            fixes_by_type[ft]["success"] += sc
            fixes_by_type[ft]["total"] += sc
    kb["fix_type_stats"] = fixes_by_type

    save_kb()
    record_event("op_feedback", {
        "actionable": len(actionable),
        "verified": len(verified),
        "promoted": promoted,
        "stale_verified": len(stale_verified),
    })
    _log(f"  KB: {len(actionable)} actionable, {len(verified)} verified", "fbl")
    return {"promoted": promoted, "stale": len(stale_verified)}

# ════════════════════════════════════════════════════════════════
# OP 6 — MARS Self-Improvement  (Layer 1)
# ════════════════════════════════════════════════════════════════
def op_mars_reflect():
    _log("OP: MARS metacognitive reflection", "mars")
    kb     = load_kb()
    errors = kb.get("errors", [])

    principles, procedures = set(), []

    for e in errors:
        fix      = e.get("fix", "")
        sig      = e.get("signature", "")
        component = e.get("component", "")
        sr       = e.get("success_rate", 0)
        sc       = int(e.get("success_count", 0))

        # Principles from patterns
        if sc >= 3:
            if "gateway" in (sig + component).lower():
                principles.add("Gateway errors → kill stale PIDs before restart")
            if "disk" in (sig + fix + component).lower() or "90" in sig or "95" in sig:
                principles.add("Disk threshold → truncate docker logs at 90%, not 100%")
            if "docker" in (sig + component).lower():
                principles.add("Docker log bloat → proactive truncation every health check")
            if "timeout" in (sig + fix).lower():
                principles.add("Timeouts indicate overloaded services → backoff before retry")
            if "restart" in fix.lower():
                principles.add("Prefer kill+start over graceful restart for stuck services")
            if "memory" in (sig + fix).lower() or "oom" in (sig + fix).lower():
                principles.add("OOM errors → trigger memory cleanup immediately")

        # Procedures from verified high-confidence fixes
        if e.get("verified") == "true" and sr >= 0.5:
            procedures.append(f"verified: {fix[:60]} (sr={sr:.0%})")
        if sc >= 5:
            procedures.append(f"trust: {fix[:60]} ({sc} successes)")

    # Seed hardcoded operational principles
    principles.update([
        "Disk 90% is critical — truncate docker container logs FIRST",
        "Gateway restart storms → kill stale PID before starting new instance",
        "Session auth errors → retry via fallback provider, do not alert",
        "Docker logs double-JSON: parse `level` field inside `log` JSON string",
        "KB entries with 3+ success_count → auto-verify as trusted",
    ])

    principles = list(principles)[:10]
    procedures = procedures[:10]

    with _lock:
        kb["mars_principles"]  = principles
        kb["mars_procedures"] = procedures
        save_kb()

    _log(f"  {len(principles)} principles, {len(procedures)} procedures")
    for p in principles[:5]:
        _log(f"    PRINCIPLE: {p}", "mars")
    record_event("op_mars", {"principles": len(principles), "procedures": len(procedures)})
    return principles, procedures

# ════════════════════════════════════════════════════════════════
# OP 7 — Autogenesis SEPL  (Layer 1)
# ════════════════════════════════════════════════════════════════
def op_autogenesis():
    _log("OP: Autogenesis SEPL", "auto")
    RSI_DIR.mkdir(parents=True, exist_ok=True)
    kb  = load_kb()
    unv = [e for e in kb["errors"] if e.get("verified") != "true"]

    proposed = 0
    for e in unv[:5]:
        sig = e.get("signature", "")[:30]
        fix = e.get("fix", "")
        feats = _extract_features(fix)
        if not feats:
            continue
        res = {
            "type":        "kb_entry",
            "name":        sig,
            "version":     datetime.datetime.now().strftime("%Y%m%d.0"),
            "state":       "proposed",
            "proposal":    f"Auto-verify: pattern {feats}",
            "proposed_at": datetime.datetime.now().isoformat(),
            "features":    feats
        }
        (RSI_DIR / f"proposed-{sig}.json").write_text(json.dumps(res, indent=2))
        proposed += 1

    # Assess: match against meta_model, then commit accepted proposals back to KB
    assessments = []
    accepted_sigs = []
    model = kb.get("meta_model", {})

    # Clean up stale proposal files: committed ones or older than 7 days
    now = datetime.datetime.now()
    for pf in list(RSI_DIR.glob("proposed-*.json")):
        try:
            res = json.loads(pf.read_text())
            stale = res.get("state") == "committed" or (now - datetime.datetime.fromtimestamp(pf.stat().st_mtime)).days >= 7
            if stale:
                pf.unlink()
                _log(f"  Cleaned stale proposal: {pf.name}", "auto")
        except Exception:
            pass
    for res_file in RSI_DIR.glob("proposed-*.json"):
        try:
            res = json.loads(res_file.read_text())
            feats = res.get("features", [])
            matched = any(
                any(f in model.get(cat, {}).get("all_features", {}) for f in feats)
                for cat in model
            )
            # Require strong evidence before committing: matched meta_model AND
            # entry has ≥2 occurrences (not a one-off) AND not already verified.
            # This prevents pattern-match-only commits from locking in noise.
            sig_key = res.get("name", "")
            kb_entry = next((e for e in kb["errors"]
                           if e.get("signature", "").startswith(sig_key)), None)
            strong_evidence = (
                matched
                and kb_entry is not None
                and int(kb_entry.get("occurrence_count", 0)) >= 2
                and kb_entry.get("verified") != "true"
            )
            res["assessment"] = {"accepted": strong_evidence,
                                 "reason": "strong_match" if strong_evidence else
                                           "matched_no_occurrence" if matched else "no_match"}
            if strong_evidence:
                res["state"] = "committed"
                res["committed_at"] = datetime.datetime.now().isoformat()
                kb_entry["fix_type"] = feats[0] if feats else "auto_verified"
                accepted_sigs.append(kb_entry["signature"])
            res_file.write_text(json.dumps(res, indent=2))
            assessments.append({"resource": res["name"], "accepted": matched})
        except Exception:
            continue

    accepted = sum(1 for a in assessments if a["accepted"])
    if accepted_sigs:
        _log(f"  ↑ Committed {accepted} proposals to KB: {accepted_sigs[:3]}", "auto")
        save_kb()
    record_event("op_autogenesis", {"proposed": proposed, "assessed": len(assessments), "accepted": accepted})
    return accepted

# ════════════════════════════════════════════════════════════════
# OP 8 — Evolutionary Search  (Layer 1)
# ════════════════════════════════════════════════════════════════
def _eval_variant(variant):
    """Score a parameter variant against real KB state.
    Fitness = success_rate_bonus × coverage × parameter_suitability.
    No fake latency — estimate real token cost instead."""
    kb     = load_kb()
    rates  = kb.get("fix_success_rates", {})
    errors = kb.get("errors", [])
    total  = len(errors)

    if not rates or total == 0:
        return {"variant": variant, "score": 0.5, "token_cost": 1500}

    # Population-level metrics from real KB data
    successes = sum(1 for r in rates.values() if r.get("success", 0) > 0)
    avg_sr    = sum(r.get("success",0)/(r.get("success",0)+r.get("fail",1))
                    for r in rates.values()) / max(len(rates), 1)

    temp      = variant.get("temperature", 0.7)
    max_tokens = variant.get("max_tokens", 2000)
    top_p     = variant.get("top_p", 0.9)

    # Temperature suitability: low temp for high-confidence (exploits known fixes),
    # high temp for unverified/novel entries (explores new patterns)
    verified_count = sum(1 for e in errors if e.get("verified") == "true")
    exploit_ratio  = verified_count / max(total, 1)

    if temp < 0.4:
        temp_score = 0.5 + 0.5 * exploit_ratio   # low temp = good when we have verified fixes
    elif temp > 0.8:
        temp_score = 0.5 + 0.5 * (1 - exploit_ratio)  # high temp = good when exploring
    else:
        temp_score = 0.7  # medium temp is safely balanced

    # Token budget suitability: larger pools for complex errors, smaller for quick fixes
    has_complex = any("gateway" in e.get("signature","").lower() or
                      "timeout" in e.get("signature","").lower() for e in errors)
    if max_tokens >= 4000:
        token_score = 1.0 if has_complex else 0.7
    elif max_tokens >= 2000:
        token_score = 0.85
    else:
        token_score = 0.6  # 1000 may truncate complex responses

    # Top-p: higher = more diverse, better for exploration
    top_p_score = top_p

    score = (avg_sr * 0.4 + temp_score * 0.3 + token_score * 0.15 + top_p_score * 0.15)
    score = min(max(score, 0.0), 1.0)

    # Estimate realistic token cost for this variant
    token_cost = max_tokens * top_p + 500  # prompt + response estimate
    return {"variant": variant, "score": round(score, 4),
            "token_cost": round(token_cost), "avg_sr": round(avg_sr, 3)}

def _breed(parents, pop_size):
    """Breed next generation from top parent dicts (each has 'variant' key)."""
    next_gen = []
    for i in range(pop_size):
        p1_raw, p2_raw = random.sample(parents, 2)
        p1, p2 = p1_raw["variant"], p2_raw["variant"]
        child = {k: random.choice([p1.get(k), p2.get(k)]) for k in ["temperature","max_tokens","top_p"]}
        if random.random() < 0.3: child["temperature"] = round(random.uniform(0.1, 1.0), 2)
        if random.random() < 0.3: child["max_tokens"]  = random.choice([1000, 2000, 4000, 8000])
        child["id"] = f"gen_{datetime.datetime.now().timestamp():.0f}_{i}"
        next_gen.append(child)
    return next_gen

def op_evolutionary_search(generations=2, pop_size=4):
    _log("OP: Evolutionary search", "evo")
    base = {"temperature": 0.7, "max_tokens": 2000, "top_p": 0.9}
    population = []
    for i in range(pop_size):
        v = base.copy()
        v["temperature"] = round(random.uniform(0.1, 1.0), 2)
        v["max_tokens"]  = random.choice([1000, 2000, 4000, 8000])
        v["top_p"]       = round(random.uniform(0.5, 1.0), 2)
        v["id"]          = f"init_{i}"
        population.append(v)

    best_overall = None
    with ThreadPoolExecutor(max_workers=pop_size) as ex:
        for gen in range(generations):
            results = list(ex.map(_eval_variant, population))
            results.sort(key=lambda x: x["score"], reverse=True)
            best = results[0]
            _log(f"  Gen {gen+1}: score={best['score']:.3f} id={best['variant']['id']}", "evo")
            if not best_overall or best["score"] > best_overall["score"]:
                best_overall = best
            if gen < generations - 1:
                population = _breed(results[:2], pop_size)

    _log(f"  Best: {best_overall['variant']['id']} score={best_overall['score']:.3f}", "evo")
    record_event("op_evolutionary", {"generations": generations, "best_score": best_overall["score"], "best_variant": best_overall["variant"]})
    return best_overall

# ════════════════════════════════════════════════════════════════
# OP 9 — Fix Drift Detector  (Layer 1)
# Detects KB entries whose fix success_rate dropped — the fix degraded
# ════════════════════════════════════════════════════════════════
def op_fix_drift_detector():
    _log("OP: Fix drift detection", "drift")
    kb = load_kb()

    # Ensure fix_success_rates + recent_uses are populated before drift detection
    _sync_fix_success_rates(kb)
    rates = kb.get("fix_success_rates", {})
    drift_entries = []

    for e in kb["errors"]:
        sig = e.get("signature", "")
        r = rates.get(sig, {})
        s, f = r.get("success", 0), r.get("fail", 0)
        total = s + f
        if total < 3:
            continue  # need at least 3 uses to detect drift

        sr = s / total
        # Drift: was good (past avg > 70%) but now failing (>40% fail in recent uses)
        recent_uses = r.get("recent_uses", [])
        if len(recent_uses) < 3:
            continue
        recent_fail_rate = sum(1 for u in recent_uses[-5:] if not u.get("success")) / min(len(recent_uses), 5)

        if sr > 0.7 and recent_fail_rate > 0.4:
            drift_entries.append({
                "signature": sig,
                "old_success_rate": round(sr, 3),
                "recent_fail_rate": round(recent_fail_rate, 3),
                "fix": e.get("fix", "")[:80],
                "component": e.get("component", ""),
            })

    if drift_entries:
        kb["drift_alerts"] = drift_entries
        _log(f"  ⚠ {len(drift_entries)} fixes showing drift", "drift")
        for d in drift_entries:
            _log(f"    {d['signature'][:50]}: was {d['old_success_rate']:.0%}, now failing at {d['recent_fail_rate']:.0%}", "drift")
    else:
        kb.pop("drift_alerts", None)
        _log(f"  ✓ No fix drift detected", "drift")

    record_event("op_drift", {"drift_count": len(drift_entries)})
    save_kb()
    return drift_entries

# ════════════════════════════════════════════════════════════════
# OP — GitHub Issues & Actions Monitor  (Layer 1)
# Fetches known error patterns from GitHub issues and Actions logs
# via public REST API (no auth required for public repos).
# ════════════════════════════════════════════════════════════════
def op_github_monitor():
    _log("OP: GitHub monitor", "gh")
    kb = load_kb()
    repos = kb.get("github_repos", [])
    if not repos:
        # Default: nothing configured, silent skip
        return 0

    today = datetime.date.today().isoformat()
    added = 0
    headers = {"Accept": "application/vnd.github+json"}
    # Try: env var → keys files → skip
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        for keys_file in [Path("/root/.hermes/.env.hermes-keys"), Path("/root/.hermes-keys/.env")]:
            if keys_file.exists():
                for line in keys_file.read_text().splitlines():
                    if line.startswith("GITHUB_TOKEN="):
                        token = line.split("=", 1)[1].strip()
                        break
                if token:
                    break
    if token:
        headers["Authorization"] = f"Bearer {token}"

    for repo in repos[:5]:  # max 5 repos per run
        try:
            owner, name = repo.split("/", 1)
        except ValueError:
            continue

        # ── Actions: failed workflow runs ──
        runs_url = f"https://api.github.com/repos/{owner}/{name}/actions/runs?per_page=50"
        try:
            import urllib.request
            req = urllib.request.Request(runs_url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as r:
                runs_data = json.loads(r.read())
        except Exception as ex:
            _log(f"  ✗ {repo} actions: {ex}", "gh")
        else:
            for run in runs_data.get("workflow_runs", []):
                if run.get("conclusion") not in ("failure", "cancelled", "timed_out"):
                    continue
                run_id = run["id"]
                run_name = run.get("name", "unknown")[:60]
                triggered = run.get("created_at", "")[:10]
                conclusion = run.get("conclusion", "")
                html_url = run.get("html_url", "")

                sig = f"github_actions_{owner}_{name}_{run_id}"
                if any(e.get("signature", "").startswith(sig) for e in kb["errors"]):
                    continue

                # Get failed jobs/steps
                jobs_url = f"https://api.github.com/repos/{owner}/{name}/actions/runs/{run_id}/jobs"
                try:
                    req2 = urllib.request.Request(jobs_url, headers=headers)
                    with urllib.request.urlopen(req2, timeout=8) as r2:
                        jobs_data = json.loads(r2.read())
                    failed_steps = []
                    for job in jobs_data.get("jobs", []):
                        for step in job.get("steps", []):
                            if step.get("conclusion") in ("failure", "timed_out"):
                                failed_steps.append(step.get("name", "unnamed step"))
                except Exception:
                    failed_steps = []

                step_info = f" (failed: {', '.join(failed_steps[:3])})" if failed_steps else ""
                kb["errors"].append({
                    "signature":           sig,
                    "fix":                f"Actions run #{run_id} '{run_name}' {conclusion}{step_info}",
                    "verified":           "false",
                    "component":          "github",
                    "tech_stack":         f"github:{owner}/{name}",
                    "first_seen":        triggered,
                    "last_seen":         today,
                    "occurrence_count":  1,
                    "auto_fixed":        "false",
                    "success_count":     0,
                    "fail_count":        1,
                    "correlation_confidence": "medium",
                    "github_url":        html_url,
                    "github_labels":     [run.get("head_branch", "")],
                    "source":             "github_monitor",
                    "fix_type":          "github_actions",
                })
                added += 1
                _log(f"  ⚠ {repo}/{run_name}: {conclusion}", "gh")

    if added:
        save_kb()
        _log(f"  ↑ {added} GitHub patterns added", "gh")
        record_event("op_github", {"repos_checked": len(repos), "added": added})
    return added

# ════════════════════════════════════════════════════════════════
# OP — SEO Performance Monitor  (Layer 1)
# Tracks Google Search Console clicks/impressions for tracked queries.
# Correlates ranking drops with site errors (site down → rankings drop).
# Uses GSC API (requires token) + free public alternatives.
# ════════════════════════════════════════════════════════════════
def op_seo_performance():
    _log("OP: SEO performance monitor", "seo")
    kb = load_kb()
    today = datetime.date.today().isoformat()

    # GSC API requires a token — if absent, fall back to public scrape
    gsc_token = os.environ.get("GOOGLE_SEARCH_CONSOLE_TOKEN", "")
    tracked_queries = kb.get("seo_tracked_queries", [])
    if not tracked_queries:
        tracked_queries = []

    drops_found = []
    header = {"Accept": "application/json"}
    if gsc_token:
        header["Authorization"] = f"Bearer {gsc_token}"

    # ── Option 1: GSC API (authenticated) ──
    if gsc_token and tracked_queries:
        try:
            import urllib.request
            site_url = kb.get("seo_site_url", "https://gemgyms.com")
            body = json.dumps({
                "startDate": (datetime.date.today() - datetime.timedelta(days=7)).isoformat(),
                "endDate":   datetime.date.today().isoformat(),
                "dimensions": ["query"],
                "rowLimit": 1000,
            }).encode()
            req = urllib.request.Request(
                "https://www.googleapis.com/webmasters/v3/sites/{}/searchAnalytics/query".format(site_url),
                data=body, headers=header, method="POST"
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                result = json.loads(r.read())
            rows = result.get("rows", [])
            for row in rows:
                query = row["keys"][0]
                clicks = row.get("clicks", 0)
                impressions = row.get("impressions", 0)
                ctr = row.get("ctr", 0)
                pos = row.get("position", 999)
                if pos > 10 and impressions > 5:  # ranking drop: position > 10
                    drops_found.append({
                        "query": query, "position": round(pos, 1),
                        "clicks": clicks, "impressions": impressions, "ctr": round(ctr, 4)
                    })
        except Exception:
            gsc_token = ""  # fall through to public fallback

    # ── Option 2: Public alternative — detect if site was down during ranking drop ──
    if not gsc_token:
        # Check if any site health errors in KB correlate with ranking periods
        site_errors = [e for e in kb["errors"]
                      if any(s in e.get("signature", "").lower()
                             for s in ["connection_error", "gateway", "503", "500", "502"])]
        if site_errors:
            for err in site_errors[:3]:
                err_date = err.get("last_seen", "")
                drops_found.append({
                    "query":     f"[correlated] {err['signature'][:40]}",
                    "position":  99,
                    "clicks":    0,
                    "impressions": 0,
                    "ctr":       0,
                    "note":      f"Site error on {err_date} — likely ranking impact"
                })

    # ── Record SEO state in KB ──
    seo_state = kb.get("seo_performance", [])
    if drops_found:
        seo_state.append({
            "date": today,
            "drops": drops_found,
            "source": "gsc_api" if gsc_token else "correlated_site_errors",
        })
    seo_state = seo_state[-14:]  # keep 2 weeks
    kb["seo_performance"] = seo_state

    # ── Auto-create KB entries for significant ranking drops ──
    added = 0
    existing_sigs = {e["signature"] for e in kb["errors"]}
    added_sigs = set()
    for drop in drops_found[:5]:
        sig = f"seo_ranking_drop_{slugify(drop['query'])[:50]}"
        if sig in existing_sigs or sig in added_sigs:
            continue
        kb["errors"].append({
            "signature":           sig,
            "fix":                f"SEO drop: query='{drop['query'][:40]}' pos={drop['position']}",
            "verified":           "false",
            "component":          "seo",
            "tech_stack":         "google_search_console",
            "first_seen":        today,
            "last_seen":         today,
            "occurrence_count":   1,
            "auto_fixed":        "false",
            "success_count":     0,
            "fail_count":        0,
            "correlation_confidence": "low",
            "source":             "seo_monitor",
            "fix_type":           "investigate",
            "seo_position":       drop.get("position"),
            "seo_clicks":         drop.get("clicks"),
            "seo_impressions":    drop.get("impressions"),
        })
        added_sigs.add(sig)
        added += 1

    if drops_found or added:
        save_kb()
        _log(f"  SEO: {len(drops_found)} drops, {added} KB entries", "seo")
        for d in drops_found[:3]:
            _log(f"    pos={d['position']:.0f} '{d['query'][:40]}'", "seo")

    record_event("op_seo", {"drops": len(drops_found), "added": added})
    return added

def slugify(text):
    import re
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '_', text)
    return text[:50]

def op_version_snapshot():
    _log("OP: KB versioning snapshot", "ver")
    kb = load_kb()
    KB_VERSIONS.mkdir(parents=True, exist_ok=True)
    ts   = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    vfile = KB_VERSIONS / f"kb-{ts}.json"
    vfile.write_text(json.dumps(kb, indent=2))

    # Prune: keep last 30 versions (safety net for rollback)
    versions = sorted(KB_VERSIONS.glob("kb-*.json"), key=lambda p: p.stat().st_mtime)
    for old in versions[:-30]:
        old.unlink()
        _log(f"  Pruned {old.name}", "ver")

    _log(f"  Snapshot kb-{ts}.json ({len(kb['errors'])} entries)", "ver")
    record_event("op_version", {"version": ts, "entries": len(kb["errors"])})
    return ts

# ════════════════════════════════════════════════════════════════
# OP — System Evaluation  (weekly — checks end-to-end health)
# Not run every cycle: expensive, covers ground other ops already watch
# ════════════════════════════════════════════════════════════════
def op_system_evaluation():
    """Weekly end-to-end system evaluation. Checks bus, fix rates, coverage, staleness."""
    _log("OP: System evaluation", "syseval")
    kb = load_kb()
    errors = kb.get("errors", [])
    rates = kb.get("fix_success_rates", {})
    today = datetime.date.today()

    # ── 1. Bus connectivity check ─────────────────────────────────
    bus_path = Path("/root/.hermes/event-bus.json")
    bus_ok = bus_path.exists() and bus_path.stat().st_size > 0
    bus_age_minutes = int((datetime.datetime.now() - datetime.datetime.fromtimestamp(
        bus_path.stat().st_mtime)).total_seconds() // 60) if bus_ok else -1

    # ── 2. Fix success rate (last 7 days) ───────────────────────
    seven_days_ago = (today - datetime.timedelta(days=7)).isoformat()
    recent_fixes = {sig: r for sig, r in rates.items()
                    if any(
                        datetime.datetime.fromisoformat(u["timestamp"]) >=
                        datetime.datetime.fromisoformat(seven_days_ago)
                        for u in r.get("recent_uses", [])
                        if "timestamp" in u
                    )}

    if recent_fixes:
        total_recent = sum(len(r.get("recent_uses", [])) for r in recent_fixes.values())
        recent_successes = sum(
            sum(1 for u in r.get("recent_uses", [])[-10:]
                if u.get("success") and
                datetime.datetime.fromisoformat(u["timestamp"]) >= datetime.datetime.fromisoformat(seven_days_ago))
            for r in recent_fixes.values()
        )
        fix_success_rate = recent_successes / max(total_recent, 1)
    else:
        fix_success_rate = None  # no recent data

    # ── 3. Coverage: % of recurring errors with fix_type ────────
    recurring = [x for x in errors if int(x.get("occurrence_count", 0)) >= 2]
    with_fix_type = [x for x in recurring if x.get("fix_type") and x.get("fix_type") not in ("?", "investigate")]
    coverage = len(with_fix_type) / max(len(recurring), 1)

    # ── 4. Stale entries: last_seen > 7 days but auto_fixed=true ─
    stale = []
    for x in errors:
        ls = x.get("last_seen", "")
        if not ls:
            continue
        try:
            days_ago = (today - datetime.date.fromisoformat(ls)).days
            if days_ago > 7 and x.get("auto_fixed") == "true":
                stale.append(x["signature"])
        except Exception:
            pass

    # ── 5. False positive rate ───────────────────────────────────
    fp = [x for x in errors if x.get("auto_fixed") == "true" and int(x.get("success_count", 0)) == 0]
    fp_rate = len(fp) / max(len(errors), 1)

    # ── 6. Op execution health (from event_log) ─────────────────
    evlog = kb.get("evolution_log", [])
    recent_ops = [e for e in evlog[-500:] if
                  datetime.datetime.fromisoformat(e.get("timestamp", "2000-01-01")) >=
                  datetime.datetime.fromisoformat(seven_days_ago)]
    op_counts = {}
    for ev in recent_ops:
        op = ev.get("op", "unknown")
        op_counts[op] = op_counts.get(op, 0) + 1
    # Flag ops that ran <3 times in 7 days (suspicious — they should run daily)
    ops_weekly_min = 3
    ops_below_thresh = {op: cnt for op, cnt in op_counts.items() if cnt < ops_weekly_min}

    # ── 7. KB consistency ─────────────────────────────────────────
    REQUIRED_FIELDS = ["signature", "fix", "verified", "component", "tech_stack",
                       "first_seen", "last_seen", "occurrence_count", "auto_fixed",
                       "success_count", "fail_count"]
    inconsistent = []
    for x in errors:
        missing = [f for f in REQUIRED_FIELDS if f not in x]
        if missing:
            inconsistent.append({"sig": x["signature"][:40], "missing": missing})

    # ── 8. KB size guard ────────────────────────────────────────
    kb_size_entries = len(errors)
    kb_size_mb = len(json.dumps(kb)) / 1_048_576
    kb_bloat = kb_size_mb > 5.0  # flag if KB JSON > 5MB

    # ── Compute overall score ────────────────────────────────────
    score_breakdown = {}
    # Bus: 15%
    score_breakdown["bus"] = 1.0 if (bus_ok and bus_age_minutes < 30) else 0.0
    # Fix rate: 25%
    if fix_success_rate is not None:
        score_breakdown["fix_rate"] = fix_success_rate
    else:
        score_breakdown["fix_rate"] = 0.5  # neutral — no data
    # Coverage: 20%
    score_breakdown["coverage"] = coverage
    # Staleness: 15%
    score_breakdown["staleness"] = 1.0 - min(len(stale) / max(len(errors), 1), 1.0)
    # FP rate: 15%
    score_breakdown["fp_rate"] = 1.0 - fp_rate
    # Consistency: 10%
    score_breakdown["consistency"] = 1.0 - len(inconsistent) / max(len(errors), 1)

    overall = sum(score_breakdown.values())

    # ── Log results ─────────────────────────────────────────────
    _log(f"  Overall score: {overall:.2f} / 1.00", "syseval")
    _log(f"  Bus: {'✓' if score_breakdown['bus'] > 0.5 else '✗'} "
         f"(age={bus_age_minutes}m)", "syseval")
    if fix_success_rate is not None:
        _log(f"  Fix rate (7d): {fix_success_rate:.0%}", "syseval")
    else:
        _log(f"  Fix rate (7d): no recent data", "syseval")
    _log(f"  Coverage: {len(with_fix_type)}/{len(recurring)} ({coverage:.0%})", "syseval")
    _log(f"  Stale auto_fixed: {len(stale)} {'✓' if not stale else '⚠'}", "syseval")
    _log(f"  False positives: {len(fp)} ({fp_rate:.0%})", "syseval")
    _log(f"  Inconsistent entries: {len(inconsistent)}", "syseval")
    if ops_below_thresh:
        _log(f"  Low-run ops (<{ops_weekly_min}x/week): {ops_below_thresh}", "syseval")
    if kb_bloat:
        _log(f"  ⚠ KB bloat: {kb_size_mb:.1f}MB (>5MB threshold)", "syseval")

    # ── Write scorecard to KB ───────────────────────────────────
    kb["system_evaluation"] = {
        "timestamp": datetime.datetime.now().isoformat(),
        "overall_score": round(overall, 3),
        "breakdown": {k: round(v, 3) for k, v in score_breakdown.items()},
        "fix_success_rate_7d": round(fix_success_rate, 3) if fix_success_rate is not None else None,
        "coverage": round(coverage, 3),
        "stale_entries": stale,
        "false_positives": [x["signature"][:40] for x in fp],
        "inconsistent_entries": inconsistent,
        "ops_below_threshold": ops_below_thresh,
        "kb_size_mb": round(kb_size_mb, 2),
        "bus_ok": bus_ok,
        "bus_age_minutes": bus_age_minutes,
    }

    # ── Alert thresholds ────────────────────────────────────────
    ALERT_SCORE = 0.5
    if overall < ALERT_SCORE:
        _log(f"  🚨 CRITICAL: System score {overall:.2f} below {ALERT_SCORE} threshold", "syseval")

    save_kb()
    record_event("op_system_eval", {
        "overall_score": overall,
        "coverage": coverage,
        "stale": len(stale),
        "fp_count": len(fp),
        "inconsistent": len(inconsistent),
    })
    return overall


# ════════════════════════════════════════════════════════════════
# OP — Self-Evaluation  (Layer 1)
# Every cycle: audit the system itself, log gaps, apply auto-fixes
# ════════════════════════════════════════════════════════════════
def op_self_evaluation():
    _log("OP: Self-evaluation", "self")
    kb = load_kb()
    e = kb["errors"]
    fixes_applied = []

    # ── Phase 1: Fill missing fields first ──
    # Gap 5: entries missing auto_fixed field (legacy entries)
    missing_af = [x for x in e if "auto_fixed" not in x]
    for x in missing_af:
        x["auto_fixed"] = "false"
        fixes_applied.append(f"legacy_af:{x['signature'][:40]}")

    # ── Phase 2: Fix false/inconsistent state ──
    # Gap 1: false_positives = auto_fixed set but never succeeded
    false_pos = [x for x in e if x.get("auto_fixed") == "true" and int(x.get("success_count") or 0) == 0]
    for x in false_pos:
        x["auto_fixed"] = "false"
        fixes_applied.append(f"fp_reset:{x['signature'][:40]}")

    # Gap 2: never_fixable = no fix_type, never succeeded, auto_fixed terminal state
    never_fixed = [x for x in e
                   if x.get("auto_fixed") in ("", None, "false")
                   and int(x.get("success_count") or 0) == 0
                   and not x.get("fix_type")]
    for x in never_fixed:
        e.remove(x)
        fixes_applied.append(f"pruned:{x['signature'][:40]}")

    # Gap 3: verified entries missing fix_type
    no_fix_type = [x for x in e if x.get("verified") == "true" and not x.get("fix_type")]
    for x in no_fix_type:
        x["fix_type"] = "manual_verified"
        fixes_applied.append(f"fix_type:{x['signature'][:40]}")

    # Gap 4: KB health score + hard rollback on critical degradation
    total = len(e)
    verified = sum(1 for x in e if x.get("verified") == "true")
    has_fix = sum(1 for x in e if x.get("fix_type"))
    score = (verified / max(total, 1) * 0.5) + (has_fix / max(total, 1) * 0.5)
    if score < 0.5:
        _log(f"  🚨 CRITICAL: KB health {score:.2f} < 0.5 — rolling back to last known good snapshot", "self")
        kb_versions = kb.get("kb_versions", [])
        if kb_versions:
            last_good = kb_versions[-1]
            kb["errors"] = last_good.get("snapshot_errors", e)
            fixes_applied.append("rollback:last_good_snapshot")
    elif score < 0.7:
        _log(f"  ⚠ KB health {score:.2f} < 0.7", "self")
    else:
        _log(f"  ✓ KB health {score:.2f}", "self")

    # ── Phase 3: System health ──
    # Gap 6: evolution_log not capped
    evlog = kb.get("evolution_log", [])
    if len(evlog) > 500:
        kb["evolution_log"] = evlog[-500:]
        fixes_applied.append(f"evlog_capped:{len(evlog) - 500}")

    # Gap 7: kb_versions in-memory snapshot
    snaps = kb.get("kb_versions", [])
    snaps.append({
        "timestamp": datetime.datetime.now().isoformat(),
        "total_errors": len(e),
        "verified": verified,
        "auto_fixed": sum(1 for x in e if x.get("auto_fixed") == "true"),
        "drift_alerts": len(kb.get("drift_alerts", [])),
    })
    snaps[:] = snaps[-14:]
    kb["kb_versions"] = snaps

    # ── Phase 4: Schema normalization ──
    # Gap 8: entries missing critical fields or using wrong field names
    REQUIRED_STR = ["signature", "fix", "verified", "component", "tech_stack",
                    "first_seen", "last_seen", "auto_fixed", "fix_type"]
    REQUIRED_INT = ["success_count", "fail_count", "occurrence_count"]
    schema_fixes = 0

    for x in e:
        changed = False
        # Fill missing string fields
        for f in REQUIRED_STR:
            if f not in x or x[f] is None or x[f] == '':
                x[f] = "unknown"
                changed = True
        # Fill missing int fields with 0
        for f in REQUIRED_INT:
            if f not in x or x[f] is None:
                x[f] = 0
                changed = True
        # Normalize occurrences -> occurrence_count
        if "occurrences" in x and "occurrence_count" not in x:
            x["occurrence_count"] = x.pop("occurrences")
            changed = True
        elif "occurrences" in x and "occurrence_count" in x:
            # Merge: use the larger value
            x["occurrence_count"] = max(x.get("occurrence_count", 0), x.pop("occurrences"))
            changed = True
        if changed:
            schema_fixes += 1
            fixes_applied.append(f"schema_norm:{x['signature'][:30]}")

    if schema_fixes:
        _log(f"  Schema: normalized {schema_fixes} entries", "self")

    # ── Phase 5: Cross-field quality checks ──
    # Gap 9: verified=true but never succeeded — logically impossible
    fake_verified = [x for x in e
                     if x.get("verified") == "true"
                     and int(x.get("success_count") or 0) == 0
                     and x.get("auto_fixed") != "true"]
    for x in fake_verified:
        x["verified"] = "false"
        fixes_applied.append(f"fake_verified:{x['signature'][:30]}")

    # Gap 10: auto_fixed=true but fail_count > success_count — contradictory
    contradictory = [x for x in e
                     if x.get("auto_fixed") == "true"
                     and int(x.get("fail_count") or 0) > int(x.get("success_count") or 0)]
    for x in contradictory:
        x["auto_fixed"] = "false"
        fixes_applied.append(f"contradictory_af:{x['signature'][:30]}")

    # Gap 11: stale unverified entries (>30 days old, never succeeded)
    from datetime import date, timedelta
    cutoff30 = (date.today() - timedelta(days=30)).isoformat()
    stale30 = [x for x in e
               if x.get("verified") != "true"
               and int(x.get("success_count") or 0) == 0
               and x.get("first_seen", "") < cutoff30]
    for x in stale30:
        e.remove(x)
        fixes_applied.append(f"stale30d:{x['signature'][:30]}")

    # ── Phase 6: Op effectiveness monitoring ──
    # Gap 12: check if ops are producing meaningful output
    evlog = kb.get("evolution_log", [])
    op_counts = Counter(entry.get("op", entry.get("type", "")) for entry in evlog[-500:])
    op_success = Counter()
    for entry in evlog[-500:]:
        if entry.get("result") in ("success", "applied", "fixed"):
            op = entry.get("op", entry.get("type", ""))
            op_success[op] += 1
    # Flag ops that ran but produced no useful output
    # Bus-event types are signals, not operations — exclude them from effectiveness checks
    BUS_EVENTS = {"bus", "version", "correlation", "docker_error", "internet_ok", "internet_error"}
    for op, count in op_counts.items():
        if count > 5 and op_success[op] == 0 and op not in BUS_EVENTS:
            _log(f"  ⚠ op '{op}' ran {count}x but 0 successes — possible silent failure", "self")

    if fixes_applied:
        save_kb(kb)
        _log(f"  🔧 {len(fixes_applied)} self-fixes applied", "self")
        record_event("op_self_evaluation", {"fixes": fixes_applied})
    else:
        _log(f"  ✓ No self-fixes needed", "self")

    return len(fixes_applied)

# ════════════════════════════════════════════════════════════════
# DAG LAYERS — dependency graph
# ════════════════════════════════════════════════════════════════
# Layer 0: independent parallel — correlation, predictive
# Layer 1: depends on Layer 0 — meta, rank, mem2evolve, mars, autogenesis, evolutionary
# Layer 2: depends on Layer 1 — versioning
# Layer 0: sequential — both ops write KB; serialize to avoid race
# Layer 1: parallel — independent ops
# Layer 2: parallel — self_eval last
LAYERS = [
    {"ops": [op_correlate_errors, op_predictive_detection], "sequential": True},   # Layer 0
    {"ops": [op_meta_learning, op_rank_and_score, op_fix_feedback_loop,           # Layer 1
             op_mars_reflect, op_autogenesis, op_fix_drift_detector,
             op_github_monitor], "sequential": False},
    {"ops": [op_seo_performance, op_self_evaluation, op_version_snapshot],       # Layer 2
     "sequential": False},
]

def main():
    _log("═══ Evolution Engine v4 started (parallel DAG) ═══", "main")

    # ── Step 0: Process any queued daemon events from the event bus ──
    events_processed = bus_read_and_process()
    if events_processed > 0:
        _log(f"bus: processed {events_processed} daemon event(s)", "bus")
    else:
        _log("bus: no pending events", "bus")

    results = {}
    for layer_idx, layer_def in enumerate(LAYERS):
        layer = layer_def["ops"]
        sequential = layer_def.get("sequential", False)
        _log(f"── Layer {layer_idx} starting ({len(layer)} ops, {'sequential' if sequential else 'parallel'}) ──", "main")
        layer_results = {}

        if sequential:
            # Run serially — both ops write KB, must not race
            for fn in layer:
                name = fn.__name__
                try:
                    r = fn()
                    layer_results[name] = r
                    results[name] = r
                    _log(f"  {name}: {str(r)[:60]}", "main")
                except Exception as e:
                    _log(f"  {name} FAILED: {e}", "error")
                    results[name] = f"ERROR: {e}"
                    layer_results[name] = f"ERROR: {e}"
        else:
            with ThreadPoolExecutor(max_workers=len(layer)) as ex:
                futures = {ex.submit(fn): fn.__name__ for fn in layer}
                for future in as_completed(futures):
                    name = futures[future]
                    try:
                        r = future.result()
                        layer_results[name] = r
                        results[name] = r
                    except Exception as e:
                        _log(f"  {name} FAILED: {e}", "error")
                        results[name] = f"ERROR: {e}"
                        layer_results[name] = f"ERROR: {e}"

        _log(f"── Layer {layer_idx} done ──", "main")

    _log("═══ Evolution Engine v4 complete ═══", "main")
    record_event("evolution_engine_run", {
        "ops": list(results.keys()),
        "results": {k: str(v)[:40] for k, v in results.items()}
    })
    return results

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "single":
        # python3 evolution-engine.py single <op_name>
        op_map = {
            "correlation":     op_correlate_errors,
            "predictive":      op_predictive_detection,
            "meta_learning":   op_meta_learning,
            "rank":            op_rank_and_score,
            "fix_feedback":    op_fix_feedback_loop,
            "mars":            op_mars_reflect,
            "autogenesis":     op_autogenesis,
            "drift":           op_fix_drift_detector,
            "self_eval":       op_self_evaluation,
            "version":         op_version_snapshot,
        }
        name = sys.argv[2] if len(sys.argv) > 2 else ""
        if name in op_map:
            op_map[name]()
        else:
            print(f"Available: {list(op_map.keys())}")
    else:
        main()
