#!/usr/bin/env python3
"""
KB Auto-Tag — auto-assign tags to KB error entries based on keywords
found in correlation_type, component, and fix fields.

Tags: docker, email, cron, network, disk, memory, postgres, telegram,
      nginx, github, webhook, scheduled, system, unknown
"""

import json
import fcntl
import sys
from datetime import datetime
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_auto_tag.log")

# Keyword → tag mapping (order matters: longer/more-specific first)
KEYWORD_TAGS = [
    # Infrastructure / runtime
    ("docker",        "docker"),
    ("container",     "docker"),
    ("podman",        "docker"),
    ("kubernetes",    "kubernetes"),
    ("k8s",           "kubernetes"),

    # Web / networking
    ("nginx",         "nginx"),
    ("apache",        "apache"),
    ("webhook",       "webhook"),
    ("http",          "network"),
    ("https",         "network"),
    ("connection",    "network"),
    ("network",       "network"),
    ("socket",        "network"),
    ("timeout",      "network"),
    ("refused",       "network"),
    ("unreachable",  "network"),
    ("dns",           "network"),

    # Email / messaging
    ("email",         "email"),
    ("smtp",          "email"),
    ("mail",          "email"),
    ("telegram",      "telegram"),
    ("bot",           "telegram"),
    ("discord",       "discord"),
    ("slack",         "slack"),
    ("webhook",       "webhook"),

    # Scheduling
    ("cron",          "cron"),
    ("scheduled",     "scheduled"),
    ("schedule",      "scheduled"),
    ("at job",        "scheduled"),
    ("periodic",     "scheduled"),

    # Storage / disk / memory
    ("disk",          "disk"),
    ("storage",      "disk"),
    ("space",         "disk"),
    ("inodes",       "disk"),
    ("memory",       "memory"),
    ("oom",           "memory"),
    ("out of memory", "memory"),
    ("ram",           "memory"),
    ("heap",          "memory"),

    # Databases
    ("postgres",      "postgres"),
    ("postgresql",    "postgres"),
    ("mysql",         "database"),
    ("mariadb",       "database"),
    ("sqlite",        "database"),
    ("mongodb",       "database"),
    ("redis",         "database"),
    ("database",      "database"),
    ("sql",           "database"),

    # Git / code
    ("github",        "github"),
    ("git",           "git"),
    ("commit",        "git"),
    ("branch",        "git"),

    # System
    ("systemd",       "system"),
    ("init.d",        "system"),
    ("service",       "system"),
    ("permission",    "system"),
    ("denied",        "system"),
    ("forbidden",     "system"),
    ("unauthorized",  "system"),
    ("auth",          "auth"),
    ("token",         "auth"),
    ("oauth",         "auth"),
    ("sudo",          "system"),
    ("root",          "system"),
    ("signal",        "system"),
    ("segfault",      "system"),
    ("panic",         "system"),
    ("crash",         "system"),
]

# Single-word tag synonyms
COMPONENT_TAGS = {
    "docker":     "docker",
    "postgres":   "postgres",
    "Postgres":   "postgres",
    "email":      "email",
    "cron":       "cron",
    "memory":     "memory",
    "disk":       "disk",
    "network":    "network",
    "nginx":      "nginx",
    "telegram":   "telegram",
    "github":     "github",
    "webhook":    "webhook",
    "system":     "system",
    "errors.log": "system",
    "gateway":    "gateway",
    "Gateway":    "gateway",
    "hermes":     "hermes",
    "Hermes":     "hermes",
    "agent":      "agent",
}


def log(msg):
    ts = datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def extract_tags(entry):
    """Infer tags from correlation_type, component, fix, and signature fields."""
    found = set()

    # correlation_type like "generic_error::docker" or "generic_error::unknown"
    corr_type = entry.get("correlation_type", "")
    if corr_type:
        parts = corr_type.split("::")
        for part in parts:
            part_lower = part.lower().strip()
            if part_lower in ("generic_error", "unknown", "error"):
                continue
            tag = COMPONENT_TAGS.get(part) or COMPONENT_TAGS.get(part.title())
            if tag:
                found.add(tag)

    # component field
    component = entry.get("component", "")
    if component:
        comp_lower = component.lower().strip()
        tag = COMPONENT_TAGS.get(component) or COMPONENT_TAGS.get(comp_lower)
        if tag:
            found.add(tag)

    # fix field — scan for keywords
    fix = entry.get("fix", "")
    text_to_scan = " ".join([corr_type, component, fix]).lower()

    for keyword, tag in KEYWORD_TAGS:
        if keyword.lower() in text_to_scan:
            found.add(tag)

    # signature-based hints (e.g. "synthetic__curiosity__docker__...")
    signature = entry.get("signature", "").lower()
    for keyword, tag in KEYWORD_TAGS:
        if keyword.lower() in signature:
            found.add(tag)

    # Remove 'unknown' tag — it has no diagnostic value
    found.discard("unknown")

    return sorted(found)


def auto_tag(dry_run=False):
    """Scan KB entries, auto-assign tags, update in place."""
    log("=== KB Auto-Tag started ===")
    kb = read_kb()
    errors = kb.get("errors", [])

    updated = 0
    skipped = 0
    report = []

    for entry in errors:
        existing = set(entry.get("tags", []))
        inferred = set(extract_tags(entry))
        if not inferred:
            skipped += 1
            continue

        # Merge: keep existing tags, add any new ones
        new_tags = sorted(existing | inferred)

        if new_tags == existing:
            skipped += 1
            continue

        report.append({
            "signature": entry.get("signature", "")[:60],
            "old_tags": existing,
            "new_tags": new_tags,
        })

        if not dry_run:
            entry["tags"] = new_tags

        updated += 1

    if not dry_run and updated > 0:
        write_kb(kb)

    log(f"Auto-tagged: {updated} entries updated, {skipped} skipped")
    for r in report:
        log(f"  {r['signature']}: {r['old_tags']} → {r['new_tags']}")

    return updated, skipped, report


def main():
    dry_run = "--dry-run" in sys.argv
    if dry_run:
        log("DRY RUN — no changes will be written")

    updated, skipped, report = auto_tag(dry_run=dry_run)
    print(f"\nSummary: {updated} tagged, {skipped} unchanged")
    if report and dry_run:
        print("\nPreview of tag changes:")
        for r in report:
            print(f"  {r['signature']}: {r['old_tags']} → {r['new_tags']}")


if __name__ == "__main__":
    main()
