#!/usr/bin/env python3
"""KB Self-Packaging — packages KB as a deployable tool for other servers."""
import json, os, shutil, tarfile, glob
from datetime import datetime

KB_PATH = "/root/.hermes/error-knowledge-base.json"
PKG_DIR = "/root/.hermes/packages"
SCRIPTS_DIR = "/root/.hermes/scripts"

SCRIPTS = [
    "kb_combined.py",
    "kb_self_heal.py",
    "kb_self_query.py",
    "kb_self_awareness.py",
    "kb_benchmark.py",
    "kb_cost_model.py",
    "kb_dependency.py",
    "kb_recovery.py",
    "kb_safety.py",
    "kb_replicate.py",
    "kb_self_test.py",
    "kb_self_document.py",
    "kb_nl_query.py",
    "kb_predictor.py",
]

def build_package():
    os.makedirs(PKG_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    
    pkg_name = f"kb_self_aware_{ts}"
    pkg_path = f"{PKG_DIR}/{pkg_name}"
    os.makedirs(pkg_path, exist_ok=True)
    
    # Copy scripts
    scripts_dest = f"{pkg_path}/scripts"
    os.makedirs(scripts_dest, exist_ok=True)
    
    for script in SCRIPTS:
        src = f"{SCRIPTS_DIR}/{script}"
        if os.path.exists(src):
            shutil.copy2(src, scripts_dest)
    
    # Copy KB
    if os.path.exists(KB_PATH):
        shutil.copy2(KB_PATH, pkg_path)
    
    # Copy state dir structure
    state_dest = f"{pkg_path}/state"
    os.makedirs(state_dest, exist_ok=True)
    
    # Write install script
    install_script = """#!/bin/bash
# KB Self-Aware Installer
# Run: bash install.sh

echo "Installing KB Self-Aware..."

# Create dirs
mkdir -p ~/.hermes/scripts
mkdir -p ~/.hermes/state

# Copy scripts
cp -r scripts/* ~/.hermes/scripts/
chmod +x ~/.hermes/scripts/kb_*.py

# Copy KB
cp error-knowledge-base.json ~/.hermes/ 2>/dev/null || true

# Copy state
cp -r state/* ~/.hermes/state/ 2>/dev/null || true

# Add to crontab
(crontab -l 2>/dev/null | grep -v "kb_combined"; echo "*/30 * * * * python3 ~/.hermes/scripts/kb_combined.py >> ~/.hermes/logs/kb_combined.log 2>&1") | crontab -

echo "✅ KB Self-Aware installed!"
echo "Run: python3 ~/.hermes/scripts/kb_combined.py"
"""
    
    with open(f"{pkg_path}/install.sh", "w") as f:
        f.write(install_script)
    
    os.chmod(f"{pkg_path}/install.sh", 0o755)
    
    # Write README
    readme = f"""# KB Self-Aware Package
Built: {datetime.now().isoformat()}

## What's Inside
- 14 KB scripts (self-heal, self-query, self-awareness, etc.)
- Current error knowledge base
- Auto-install script

## Quick Start
    bash install.sh
    python3 ~/.hermes/scripts/kb_combined.py

## Scripts
"""
    for s in SCRIPTS:
        readme += f"- scripts/{s}\n"
    
    with open(f"{pkg_path}/README.md", "w") as f:
        f.write(readme)
    
    # Create tarball
    tar_path = f"{PKG_DIR}/{pkg_name}.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tar:
        tar.add(pkg_path, arcname=pkg_name)
    
    size = os.path.getsize(tar_path) / 1024
    
    # Also make latest symlink
    latest = f"{PKG_DIR}/kb_latest.tar.gz"
    if os.path.exists(latest):
        os.remove(latest)
    os.symlink(tar_path, latest)
    
    return tar_path, size, len(SCRIPTS)

if __name__ == "__main__":
    path, size_kb, count = build_package()
    print(f"✅ KB Package built: {path}")
    print(f"   Size: {size_kb:.1f} KB")
    print(f"   Scripts: {count}")
    
    # List all packages
    packages = sorted(glob.glob(f"{PKG_DIR}/kb_*.tar.gz"))
    print(f"\n📦 {len(packages)} packages available:")
    for p in packages[-3:]:
        print(f"   {p.split('/')[-1]}")
