#!/usr/bin/env python3
"""
KB Failed - Failed Attempts Tracker.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
FAILED_FILE = Path("/root/.hermes/state/kb_failed.json")
LOG_FILE = Path("/root/.hermes/logs/kb_failed.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB Failed started ===")

    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": []}

    failed = []
    for entry in kb.get("knowledge_base", []):
        for fix in entry.get("fixes", []):
            if fix.get("failed"):
                failed.append({
                    "error": entry.get("error", ""),
                    "fix": fix,
                    "failed_at": fix.get("failed_at", ""),
                })

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "failed_count": len(failed),
        "failed_fixes": failed,
    }

    FAILED_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(FAILED_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Failed: {len(failed)} failed fixes tracked ===")


if __name__ == "__main__":
    main()
