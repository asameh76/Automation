#!/usr/bin/env python3
"""
KB Session Ingest - Ingest from session JSONL files.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
SESSION_DIR = Path("/root/.hermes/sessions")
INGEST_FILE = Path("/root/.hermes/state/kb_session_ingest.json")
LOG_FILE = Path("/root/.hermes/logs/kb_session_ingest.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_jsonl(path):
    entries = []
    try:
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except Exception:
                        pass
    except Exception:
        pass
    return entries


def main():
    log("=== KB Session Ingest started ===")

    if not SESSION_DIR.exists():
        log("No sessions directory found")
        return

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    new_entries = 0
    for session_file in SESSION_DIR.glob("*.jsonl"):
        sessions = read_jsonl(session_file)
        for session in sessions:
            if "error" in session:
                new_entry = {
                    "error": session.get("error", ""),
                    "status": "investigate",
                    "fixes": session.get("fixes", []),
                    "tags": session.get("tags", ["session"]),
                    "created_at": session.get("timestamp", datetime.datetime.now().isoformat()),
                    "source": "session_ingest",
                }
                if "errors" not in kb:
                    kb["errors"] = []
                kb["errors"].append(new_entry)
                new_entries += 1

    if new_entries > 0:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "new_entries": new_entries,
    }

    INGEST_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(INGEST_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Session Ingest: {new_entries} entries added ===")


if __name__ == "__main__":
    main()
