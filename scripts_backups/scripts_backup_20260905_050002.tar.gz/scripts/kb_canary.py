#!/usr/bin/env python3
"""
KB Canary - Canary deployment checker.
"""

import json
import subprocess
import datetime
from pathlib import Path


CANARY_FILE = Path("/root/.hermes/state/kb_canary.json")
LOG_FILE = Path("/root/.hermes/logs/kb_canary.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def check_canary_containers():
    """Check canary container health."""
    try:
        result = subprocess.run(
            ["docker", "ps", "--filter", "name=canary", "--format", "{{.Names}}|{{.Status}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        containers = []
        for line in result.stdout.strip().split("\n"):
            if line:
                parts = line.split("|")
                containers.append({
                    "name": parts[0] if len(parts) > 0 else "unknown",
                    "status": parts[1] if len(parts) > 1 else "unknown",
                })
        return containers
    except Exception:
        return []


def main():
    log("=== KB Canary started ===")

    containers = check_canary_containers()
    healthy = [c for c in containers if "Up" in c.get("status", "")]

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_canaries": len(containers),
        "healthy": len(healthy),
        "unhealthy": len(containers) - len(healthy),
        "containers": containers,
    }

    CANARY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CANARY_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    if healthy:
        log(f"=== KB Canary: {len(healthy)}/{len(containers)} healthy ===")
    else:
        log("=== KB Canary: No canary containers found ===")


if __name__ == "__main__":
    main()
