#!/usr/bin/env python3
"""
KB FBL Runner - Fix Feedback Loop Runner.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
FBL_FILE = Path("/root/.hermes/state/kb_fbl_runner.json")
LOG_FILE = Path("/root/.hermes/logs/kb_fbl_runner.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB FBL Runner started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    applied = []
    for entry in kb.get("knowledge_base", []):
        for fix in entry.get("fixes", []):
            if fix.get("applied") and not fix.get("validated"):
                applied.append({
                    "error": entry.get("error", ""),
                    "fix": fix,
                    "applied_at": fix.get("applied_at", ""),
                })

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "pending_validation": len(applied),
        "applied_fixes": applied,
    }

    FBL_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(FBL_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB FBL Runner: {len(applied)} pending validation ===")


if __name__ == "__main__":
    main()
