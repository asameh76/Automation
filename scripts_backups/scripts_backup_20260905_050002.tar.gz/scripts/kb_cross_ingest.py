#!/usr/bin/env python3
"""
KB Cross-Ingest - Cross-source ingestion.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
CROSS_STATE_FILE = Path("/root/.hermes/state/kb_cross_ingest.json")
LOG_FILE = Path("/root/.hermes/logs/kb_cross_ingest.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def ingest_docker_logs():
    """Ingest from docker logs."""
    entries = []
    try:
        import subprocess
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        containers = result.stdout.strip().split("\n")
        for container in containers:
            if container:
                entries.append({
                    "error": f"Docker container issue: {container}",
                    "status": "investigate",
                    "source": "docker_ps",
                })
    except Exception:
        pass
    return entries


def ingest_systemd():
    """Ingest from systemctl."""
    entries = []
    try:
        import subprocess
        result = subprocess.run(
            ["systemctl", "list-units", "--failed", "--no-pager"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        lines = result.stdout.strip().split("\n")
        for line in lines:
            if ".service" in line:
                entries.append({
                    "error": f"Systemd failure: {line.strip()}",
                    "status": "investigate",
                    "source": "systemd",
                })
    except Exception:
        pass
    return entries


def main():
    log("=== KB Cross Ingest started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    all_new = []
    all_new.extend(ingest_docker_logs())
    all_new.extend(ingest_systemd())

    for entry in all_new:
        entry["created_at"] = datetime.datetime.now().isoformat()
        if "errors" not in kb:
            kb["errors"] = []
        kb["errors"].append(entry)

    if all_new:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "new_entries": len(all_new),
    }

    CROSS_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CROSS_STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Cross Ingest: {len(all_new)} entries added ===")


if __name__ == "__main__":
    main()
