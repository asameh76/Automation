#!/bin/bash
set -euo pipefail

LOG_FILE="/root/.hermes/logs/survival-capsule-rotate.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
mkdir -p "$(dirname "$LOG_FILE")"

echo "[$TIMESTAMP] Starting survival capsule rotation" >> "$LOG_FILE"

CAPSULE_DIR="/root"
CAPSULE_BASE="survival-capsule"

# Build capsule in temp dir
TMPDIR=$(mktemp -d)
CAPSULE_SRC="$TMPDIR/survival-capsule"
mkdir -p "$CAPSULE_SRC"

# Copy essential files
cp /root/.hermes-keys/.env "$CAPSULE_SRC/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/hermes"
cp -r /root/.hermes/memory/* "$CAPSULE_SRC/hermes/memory/" 2>/dev/null || true
cp /root/.hermes/SOUL.md "$CAPSULE_SRC/hermes/" 2>/dev/null || true
cp /root/.hermes/config.yaml "$CAPSULE_SRC/hermes/" 2>/dev/null || true
cp /root/.hermes/error-knowledge-base.json "$CAPSULE_SRC/hermes/" 2>/dev/null || true
cp /root/.hermes/event-bus.jsonl "$CAPSULE_SRC/hermes/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/hermes/profiles/default"
cp -r /root/.hermes/profiles/default/* "$CAPSULE_SRC/hermes/profiles/default/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/hermes/scripts"
cp /root/.hermes/scripts/anomaly-daemon.py "$CAPSULE_SRC/hermes/scripts/" 2>/dev/null || true
cp /root/.hermes/scripts/evolution-engine.py "$CAPSULE_SRC/hermes/scripts/" 2>/dev/null || true
cp /root/.hermes/scripts/system-health-check.py "$CAPSULE_SRC/hermes/scripts/" 2>/dev/null || true
cp /root/.hermes/scripts/kanban-ideas.py "$CAPSULE_SRC/hermes/scripts/" 2>/dev/null || true
cp /root/.hermes/scripts/survival-capsule-rotate.sh "$CAPSULE_SRC/" 2>/dev/null || true
cp /root/.hermes/scripts/restore-capsule.sh "$CAPSULE_SRC/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/systemd/user"
cp /root/.config/systemd/user/hermes-gateway.service "$CAPSULE_SRC/systemd/user/" 2>/dev/null || true
cp /root/.config/systemd/user/anomaly-daemon.service "$CAPSULE_SRC/systemd/user/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/hermes/cron"
cp -r /root/.hermes/cron/* "$CAPSULE_SRC/hermes/cron/" 2>/dev/null || true
mkdir -p "$CAPSULE_SRC/hermes/skills"
cp -r /root/.hermes/skills/* "$CAPSULE_SRC/hermes/skills/" 2>/dev/null || true
cp /root/recovery-plan.md "$CAPSULE_SRC/" 2>/dev/null || true
cp /root/daily-article.py "$CAPSULE_SRC/" 2>/dev/null || true

# Clean heavy cron outputs
find "$CAPSULE_SRC/hermes/cron" -name '*.md' -o -name '*.jsonl' | xargs rm -f 2>/dev/null || true

# Create BOTH formats
NEW_ZIP="$TMPDIR/${CAPSULE_BASE}.zip"
NEW_TAR="$TMPDIR/${CAPSULE_BASE}.tar.gz"

echo "[$TIMESTAMP] Creating capsule zip + tarball" >> "$LOG_FILE"
cd "$CAPSULE_SRC" && zip -r "$NEW_ZIP" . >> "$LOG_FILE" 2>&1
tar -czf "$NEW_TAR" . >> "$LOG_FILE" 2>&1
cd - > /dev/null

# Rotate existing (keep 3 versions: base, .1, .2)
echo "[$TIMESTAMP] Rotating existing capsules" >> "$LOG_FILE"
rm -f "$CAPSULE_DIR/$CAPSULE_BASE.3.tar.gz" 2>>"$LOG_FILE" || true
rm -f "$CAPSULE_DIR/$CAPSULE_BASE.3.zip" 2>>"$LOG_FILE" || true
for i in 2 1; do
    mv -f "$CAPSULE_DIR/$CAPSULE_BASE.$i.tar.gz" "$CAPSULE_DIR/$CAPSULE_BASE.$((i+1)).tar.gz" 2>>"$LOG_FILE" || true
    mv -f "$CAPSULE_DIR/$CAPSULE_BASE.$i.zip" "$CAPSULE_DIR/$CAPSULE_BASE.$((i+1)).zip" 2>>"$LOG_FILE" || true
done
mv -f "$CAPSULE_DIR/$CAPSULE_BASE.tar.gz" "$CAPSULE_DIR/$CAPSULE_BASE.1.tar.gz" 2>>"$LOG_FILE" || true
mv -f "$CAPSULE_DIR/$CAPSULE_BASE.zip" "$CAPSULE_DIR/$CAPSULE_BASE.1.zip" 2>>"$LOG_FILE" || true

# Move new capsules in place
mv "$NEW_ZIP" "$CAPSULE_DIR/$CAPSULE_BASE.zip"
mv "$NEW_TAR" "$CAPSULE_DIR/$CAPSULE_BASE.tar.gz"
rm -rf "$TMPDIR"

# ── R2 Upload (zip for hermes import) ────────────────────────
source /root/.hermes-keys/.env 2>/dev/null || true
if [ -n "$CLOUDFLARE_ACCOUNT_ID" ]; then
    echo "[$TIMESTAMP] Uploading capsules to R2..." >> "$LOG_FILE"
    rclone copy "$CAPSULE_DIR/$CAPSULE_BASE.zip" \
        "cloudflare_hermes:gem-gyms76/backups/survival-capsule/" 2>>"$LOG_FILE"
    echo "[$TIMESTAMP] R2 upload done" >> "$LOG_FILE"
fi

# ── Telegram Delivery (send zip for easy hermes import) ───────
echo "[$TIMESTAMP] Sending capsule to Telegram..." >> "$LOG_FILE"
hermes send -t telegram -s "📦 Survival Capsule $(date '+%Y-%m-%d')" \
    "MEDIA:$CAPSULE_DIR/$CAPSULE_BASE.zip" 2>>"$LOG_FILE"
echo "[$TIMESTAMP] Telegram delivery done" >> "$LOG_FILE"

echo "[$TIMESTAMP] Survival capsule rotation completed" >> "$LOG_FILE"
