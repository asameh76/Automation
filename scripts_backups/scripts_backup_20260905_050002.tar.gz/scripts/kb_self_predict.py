#!/usr/bin/env python3
"""
KB Self-Predict — Forecast its own health/scale needs.

Predicts:
  - KB size growth rate (from state.db size history, kb-versions/)
  - Script failure probability (from error-knowledge-base.json patterns)
  - Cron overload (from ticker_heartbeat gaps / cron missed ticks)
  - Disk pressure from KB growth (state.db growth rate → disk full timeline)

Pre-seeds preventive fixes into the knowledge base before predicted failures occur.
Stores predictions in /root/.hermes/state/kb_self_predict.json.

Usage:
  python3 kb_self_predict.py           # full analysis + write state + pre-seed fixes
  python3 kb_self_predict.py --dry-run    # print only, no KB writes
  python3 kb_self_predict.py --once       # single run (default)
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# ─── Paths ────────────────────────────────────────────────────────────────────
HERMES_ROOT   = Path("/root/.hermes")
STATE_FILE    = HERMES_ROOT / "state" / "kb_self_predict.json"
ERROR_KB      = HERMES_ROOT / "error-knowledge-base.json"
HEALTH_METRICS = HERMES_ROOT / "health-metrics.jsonl"
TICKER_HEARTBEAT = HERMES_ROOT / "cron" / "ticker_heartbeat"
TICKER_LAST_SUCCESS = HERMES_ROOT / "cron" / "ticker_last_success"
STATE_DB      = HERMES_ROOT / "state.db"
KB_VERSIONS   = HERMES_ROOT / "kb-versions"
CRON_DIR      = HERMES_ROOT / "cron"
SCRIPTS_DIR   = HERMES_ROOT / "scripts"

# ─── Thresholds / tuning ───────────────────────────────────────────────────────
STATE_DB_GROWTH_ALERT_MB_PER_DAY = 500   # alert if KB growing faster than this
DISK_CRITICAL_PCT = 85
DISK_WARNING_PCT  = 70
FAILURE_COOLDOWN  = 24 * 3600  # seconds before re-flagging same failure type
PREDICTION_HORIZON_SECS = 12 * 3600   # predict up to 12h ahead


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════

def ts_now():
    return datetime.now(timezone.utc).isoformat()


def log(msg):
    print(f"[{ts_now()}] {msg}", flush=True)


def read_json(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def get_file_age_hours(path):
    """Return file age in hours, or None if missing."""
    try:
        return (time.time() - os.path.getmtime(path)) / 3600
    except Exception:
        return None


def get_file_size_mb(path):
    """Return file size in MB, or None if missing."""
    try:
        return os.path.getsize(path) / (1024 * 1024)
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# 1. KB SIZE GROWTH RATE
# ═══════════════════════════════════════════════════════════════════════════════

def get_kb_version_sizes():
    """Read kb-versions/*.json for recorded KB sizes over time."""
    sizes = []
    try:
        for vf in sorted(KB_VERSIONS.glob("kb-*.json")):
            data = read_json(vf)
            if data:
                # most version files have a 'size' or 'total_errors' or similar
                # or we derive from file size
                fsize = get_file_size_mb(vf)
                ts_str = data.get("timestamp", vf.stem)
                sizes.append({"ts": ts_str, "fsize_mb": fsize})
    except Exception as e:
        log(f"Warning: could not read kb-versions: {e}")
    return sizes


def get_state_db_size_mb():
    """Get current state.db + wal + shm combined size in MB."""
    total = 0
    for suffix in ["", "-wal", "-shm"]:
        path = Path(str(STATE_DB) + suffix) if suffix else STATE_DB
        if path.exists():
            total += get_file_size_mb(path) or 0
    return total if total > 0 else None


def compute_kb_growth_rate():
    """
    Returns dict with:
      - current_size_mb: float
      - growth_rate_mb_per_day: float (estimated from kb-versions or state.db)
      - days_until_disk_full: float or None
      - disk_free_gb: float
      - status: "ok" | "warning" | "critical"
    """
    result = {
        "current_size_mb": 0,
        "growth_rate_mb_per_day": 0,
        "days_until_disk_full": None,
        "disk_free_gb": 0,
        "status": "ok",
    }

    # Current KB size (state.db)
    current_mb = get_state_db_size_mb()
    if current_mb:
        result["current_size_mb"] = round(current_mb, 2)

    # Disk free space
    try:
        stat = shutil.disk_usage("/")
        free_gb = stat.free / (1024**3)
        used_gb  = stat.used / (1024**3)
        total_gb  = stat.total / (1024**3)
        result["disk_free_gb"] = round(free_gb, 2)
    except Exception:
        free_gb = None

    # Growth rate from kb-versions
    versions = get_kb_version_sizes()
    if len(versions) >= 2:
        v0 = versions[0]
        vn = versions[-1]
        try:
            ts0 = datetime.fromisoformat(v0["ts"].replace("Z", "+00:00"))
            tsn = datetime.fromisoformat(vn["ts"].replace("Z", "+00:00"))
            delta_days = max((tsn - ts0).total_seconds() / 86400, 0.001)
            delta_mb   = max((vn["fsize_mb"] or 0) - (v0["fsize_mb"] or 0), 0)
            result["growth_rate_mb_per_day"] = round(delta_mb / delta_days, 2)
        except Exception:
            pass

    # Also try state.db size history via os.path.getsize timestamps
    # (already captured above; state.db itself is the KB)

    # Days until disk full at current growth rate
    growth_rate = result["growth_rate_mb_per_day"]
    if growth_rate > 0 and free_gb is not None:
        # KB only occupies part of disk; estimate days until KB alone hits "critical" level
        # Use the growth rate to project when KB size would double, or when disk fills
        # We track state.db growth; disk filling is a proxy
        # Conservative: assume KB will fill disk when free_gb is exhausted at growth_rate
        result["days_until_disk_full"] = round(free_gb / (growth_rate / 1024), 1) if growth_rate > 0 else None

    # Status
    if free_gb is not None:
        if free_gb < 2:
            result["status"] = "critical"
        elif free_gb < 10:
            result["status"] = "warning"

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 2. SCRIPT FAILURE PROBABILITY
# ═══════════════════════════════════════════════════════════════════════════════

def get_error_patterns():
    """
    Parse error-knowledge-base.json for failure patterns.
    Returns list of {script, error_type, count, last_seen, first_seen}.
    """
    kb = read_json(ERROR_KB, {"errors": []})
    errors = kb.get("errors", [])
    patterns = {}

    for err in errors:
        # Identify the script/source
        msg = str(err.get("message", "")) + str(err.get("error", ""))
        script = "unknown"
        for candidate in SCRIPTS_DIR.glob("kb_*.py"):
            if candidate.name.replace("kb_", "").replace(".py", "") in msg.lower():
                script = candidate.name
                break
        if "cron" in msg.lower():
            script = "cron-job"
        if "ticker" in msg.lower():
            script = "ticker"

        etype = err.get("error_type") or err.get("type", "unknown")
        key = f"{script}::{etype}"
        if key not in patterns:
            patterns[key] = {"script": script, "error_type": etype, "count": 0,
                              "first_seen": None, "last_seen": None}
        patterns[key]["count"] += 1

        ts = err.get("timestamp") or err.get("ts")
        if ts:
            if patterns[key]["first_seen"] is None or ts < patterns[key]["first_seen"]:
                patterns[key]["first_seen"] = ts
            if patterns[key]["last_seen"] is None or ts > patterns[key]["last_seen"]:
                patterns[key]["last_seen"] = ts

    return list(patterns.values())


def compute_script_failure_probability():
    """
    Returns dict with:
      - total_unique_failures: int
      - high_risk_scripts: list of {script, error_type, count, probability}
      - predictions: list of {script, error_type, probability, horizon_secs, fix_pre_seeded}
    """
    patterns = get_error_patterns()

    # Estimate failure probability per script from recency + frequency
    now_ts = time.time()
    predictions = []
    high_risk = []

    for p in patterns:
        count = p["count"]
        # Probability heuristic: more failures = higher probability
        # Cap at 0.9; base on count with log scaling
        prob = min(0.9, round(0.1 * (count ** 0.7), 3))

        if prob >= 0.3:
            high_risk.append({
                "script": p["script"],
                "error_type": p["error_type"],
                "count": count,
                "probability": prob,
            })
            predictions.append({
                "type": "script_failure",
                "script": p["script"],
                "error_type": p["error_type"],
                "probability": prob,
                "horizon_secs": PREDICTION_HORIZON_SECS,
                "fix_pre_seeded": False,  # updated below if we seed a fix
            })

    return {
        "total_unique_failures": len(patterns),
        "high_risk_scripts": high_risk,
        "predictions": predictions,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 3. CRON OVERLOAD
# ═══════════════════════════════════════════════════════════════════════════════

def compute_cron_overload():
    """
    Returns dict with:
      - status: "ok" | "overloaded" | "stuck"
      - last_heartbeat_age_secs: float or None
      - last_success_age_secs: float or None
      - missed_heartbeats: int
      - ticker_gap_secs: list of gaps
    """
    result = {
        "status": "ok",
        "last_heartbeat_age_secs": None,
        "last_success_age_secs": None,
        "missed_heartbeats": 0,
        "ticker_gap_secs": [],
    }

    # Read ticker heartbeat (Unix timestamp)
    try:
        with open(TICKER_HEARTBEAT) as f:
            hb_ts = float(f.read().strip())
        result["last_heartbeat_age_secs"] = round(time.time() - hb_ts, 1)
    except Exception:
        result["status"] = "stuck"
        result["last_heartbeat_age_secs"] = None
        return result

    # Check last success
    try:
        with open(TICKER_LAST_SUCCESS) as f:
            ts_str = f.read().strip()
        success_ts = float(ts_str)
        result["last_success_age_secs"] = round(time.time() - success_ts, 1)
    except Exception:
        pass

    # Count missed heartbeats (expected every 60s, allow 120s tolerance)
    hb_age = result["last_heartbeat_age_secs"]
    if hb_age is not None:
        expected_interval = 60
        tolerance = 120
        if hb_age > tolerance:
            result["missed_heartbeats"] = int((hb_age - tolerance) / expected_interval) + 1
            result["status"] = "overloaded"

    # Cron overload: running many cron jobs?
    cron_count = 0
    try:
        res = subprocess.run(["pgrep", "-f", "cron"], capture_output=True, text=True, timeout=5)
        cron_count = len(res.stdout.strip().splitlines()) if res.stdout.strip() else 0
    except Exception:
        pass

    result["cron_process_count"] = cron_count
    if cron_count > 10:
        result["status"] = "overloaded"

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 4. DISK PRESSURE FROM KB GROWTH
# ═══════════════════════════════════════════════════════════════════════════════

def compute_disk_pressure():
    """
    Returns dict with:
      - disk_usage_pct: float
      - kb_size_mb: float
      - growth_rate_mb_per_day: float
      - days_until_70pct: float or None
      - days_until_85pct: float or None
      - status: "ok" | "warning" | "critical"
    """
    result = {
        "disk_usage_pct": 0,
        "kb_size_mb": 0,
        "growth_rate_mb_per_day": 0,
        "days_until_70pct": None,
        "days_until_85pct": None,
        "status": "ok",
    }

    # Disk usage
    try:
        usage = shutil.disk_usage("/")
        result["disk_usage_pct"] = round((usage.used / usage.total) * 100, 1)
    except Exception:
        return result

    # KB size + growth rate
    kb_info = compute_kb_growth_rate()
    result["kb_size_mb"] = kb_info["current_size_mb"]
    result["growth_rate_mb_per_day"] = kb_info["growth_rate_mb_per_day"]

    # Days until disk % thresholds
    # We estimate based on overall disk growth, not just KB
    # Use overall usage trend if available; else use KB growth as proxy
    growth_rate = kb_info["growth_rate_mb_per_day"]
    if growth_rate > 0:
        used_gb = (usage.used / 1024**3)
        total_gb = (usage.total / 1024**3)

        # How many days until disk hits 70% / 85%?
        # Disk % = (used_gb / total_gb) * 100
        # d(days_until_70) = (0.70*total_gb - used_gb) / (growth_rate_gb_per_day)
        growth_rate_gb_per_day = growth_rate / 1024
        if growth_rate_gb_per_day > 0:
            target_70_used = 0.70 * total_gb
            target_85_used = 0.85 * total_gb
            result["days_until_70pct"] = round((target_70_used - used_gb) / growth_rate_gb_per_day, 1) if used_gb < target_70_used else 0
            result["days_until_85pct"] = round((target_85_used - used_gb) / growth_rate_gb_per_day, 1) if used_gb < target_85_used else None

    # Status
    pct = result["disk_usage_pct"]
    if pct >= DISK_CRITICAL_PCT:
        result["status"] = "critical"
    elif pct >= DISK_WARNING_PCT:
        result["status"] = "warning"

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 5. AGENT HEALTH METRICS (memory/poll trend from health-metrics.jsonl)
# ═══════════════════════════════════════════════════════════════════════════════

def compute_agent_health_trend():
    """
    Parse health-metrics.jsonl for memory/poll_s trend.
    Returns {memory_mb_avg, memory_mb_trend, poll_ms_avg, poll_ms_trend, status}
    """
    result = {"memory_mb_avg": 0, "memory_mb_trend": 0,
              "poll_ms_avg": 0, "poll_ms_trend": 0, "status": "ok", "samples": 0}

    try:
        lines = []
        with open(HEALTH_METRICS) as f:
            # Read last 200 lines
            f.seek(0)
            all_lines = f.readlines()
            lines = all_lines[-200:] if len(all_lines) > 200 else all_lines

        memory_vals, poll_vals = [], []
        for line in lines:
            try:
                rec = json.loads(line)
                memory_vals.append(rec.get("memory_mb", 0))
                poll_vals.append(rec.get("poll_ms", 0))
            except Exception:
                pass

        if not memory_vals:
            return result

        result["samples"] = len(memory_vals)
        result["memory_mb_avg"] = round(sum(memory_vals) / len(memory_vals), 1)

        half = len(memory_vals) // 2
        first_half_mem = memory_vals[:half] if half else memory_vals
        second_half_mem = memory_vals[half:] if half else []
        if first_half_mem and second_half_mem:
            result["memory_mb_trend"] = round(
                (sum(second_half_mem) / len(second_half_mem)) -
                (sum(first_half_mem) / len(first_half_mem)), 1
            )

        result["poll_ms_avg"] = round(sum(poll_vals) / len(poll_vals), 1)
        half_p = len(poll_vals) // 2
        if half_p:
            first_half_poll = poll_vals[:half_p]
            second_half_poll = poll_vals[half_p:]
            if first_half_poll and second_half_poll:
                result["poll_ms_trend"] = round(
                    (sum(second_half_poll) / len(second_half_poll)) -
                    (sum(first_half_poll) / len(first_half_poll)), 1
                )

        # Status: warn if memory trending up > 10MB per half-dataset
        if result["memory_mb_trend"] > 10:
            result["status"] = "warning"
        if result["memory_mb_trend"] > 50:
            result["status"] = "critical"

    except Exception as e:
        log(f"Warning: could not parse health-metrics: {e}")

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 6. PRE-SEED FIXES INTO KNOWLEDGE BASE
# ═══════════════════════════════════════════════════════════════════════════════

def pre_seed_fixes(predictions, dry_run=False):
    """
    For each predicted failure, write a preventive fix entry into the KB
    so future runs can reference it before the failure occurs.

    Returns list of fixes that were (or would be) seeded.
    """
    seeded = []
    kb = read_json(ERROR_KB, {"errors": []})
    existing_sigs = {e.get("signature") for e in kb.get("errors", []) if e.get("signature")}

    for pred in predictions:
        if pred.get("probability", 0) < 0.3:
            continue

        sig_base = f"fix_pre_seed_{pred.get('type', 'unknown')}_{pred.get('script', 'unknown')}"
        sig = hashlib.md5(sig_base.encode()).hexdigest()[:12]
        signature = f"pred_{datetime.now().strftime('%Y_%m_%d_%H_%M_%S')}_{sig}"

        if signature in existing_sigs:
            continue

        fix_entry = {
            "error_type": "predicted_failure",
            "message": f"PRE-SEEDED FIX for predicted {pred.get('type')}: "
                       f"script={pred.get('script')} error_type={pred.get('error_type')} "
                       f"probability={pred.get('probability')} horizon={pred.get('horizon_secs')}s",
            "script": pred.get("script", "unknown"),
            "prediction": {
                "type": pred.get("type"),
                "script": pred.get("script"),
                "error_type": pred.get("error_type"),
                "probability": pred.get("probability"),
                "horizon_secs": pred.get("horizon_secs"),
                "pre_seeded_at": ts_now(),
            },
            "fix": f"Preventive fix pre-seeded based on prediction. "
                   f"Review script {pred.get('script')} before predicted failure window.",
            "timestamp": ts_now(),
            "source": "kb_self_predict",
            "signature": signature,
        }

        if dry_run:
            log(f"[DRY RUN] Would seed fix: {signature}")
        else:
            kb["errors"].append(fix_entry)
            existing_sigs.add(signature)
            log(f"Seeded preventive fix: {signature}")

        seeded.append(fix_entry)

    if not dry_run and seeded:
        # Write updated KB
        tmp = str(ERROR_KB) + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(kb, f, indent=2)
            os.replace(tmp, ERROR_KB)
        except Exception as e:
            log(f"Warning: could not write to error-knowledge-base.json: {e}")

    return seeded


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="KB Self-Predict")
    parser.add_argument("--dry-run", action="store_true", help="Print only, no KB writes")
    parser.add_argument("--once", action="store_true", default=True, help="Single run (default)")
    args = parser.parse_args()

    log("=== KB Self-Predict started ===")

    # Run all prediction modules
    kb_growth     = compute_kb_growth_rate()
    failures      = compute_script_failure_probability()
    cron_overload = compute_cron_overload()
    disk_pressure = compute_disk_pressure()
    agent_health  = compute_agent_health_trend()

    # Consolidate all predictions
    all_predictions = []
    all_predictions.extend(failures.get("predictions", []))

    # Cron overload prediction
    if cron_overload.get("status") != "ok":
        all_predictions.append({
            "type": "cron_overload",
            "status": cron_overload["status"],
            "missed_heartbeats": cron_overload.get("missed_heartbeats", 0),
            "last_heartbeat_age_secs": cron_overload.get("last_heartbeat_age_secs"),
            "probability": 0.8 if cron_overload["status"] == "overloaded" else 0.95,
            "horizon_secs": PREDICTION_HORIZON_SECS,
            "fix_pre_seeded": False,
        })

    # Disk pressure prediction
    if disk_pressure.get("status") != "ok":
        all_predictions.append({
            "type": "disk_pressure",
            "status": disk_pressure["status"],
            "disk_usage_pct": disk_pressure.get("disk_usage_pct"),
            "days_until_85pct": disk_pressure.get("days_until_85pct"),
            "probability": 0.7,
            "horizon_secs": PREDICTION_HORIZON_SECS,
            "fix_pre_seeded": False,
        })

    # Agent health trend prediction
    if agent_health.get("status") != "ok":
        all_predictions.append({
            "type": "agent_health_trend",
            "status": agent_health["status"],
            "memory_mb_trend": agent_health.get("memory_mb_trend"),
            "poll_ms_trend": agent_health.get("poll_ms_trend"),
            "probability": 0.6,
            "horizon_secs": PREDICTION_HORIZON_SECS,
            "fix_pre_seeded": False,
        })

    # KB size growth prediction
    if kb_growth.get("status") != "ok":
        all_predictions.append({
            "type": "kb_size_growth",
            "status": kb_growth["status"],
            "current_size_mb": kb_growth.get("current_size_mb"),
            "growth_rate_mb_per_day": kb_growth.get("growth_rate_mb_per_day"),
            "days_until_disk_full": kb_growth.get("days_until_disk_full"),
            "probability": 0.6,
            "horizon_secs": PREDICTION_HORIZON_SECS,
            "fix_pre_seeded": False,
        })

    # Mark which predictions already have fixes pre-seeded
    seeded_fixes = pre_seed_fixes(all_predictions, dry_run=args.dry_run)
    seeded_sigs = {f.get("signature") for f in seeded_fixes}
    for p in all_predictions:
        p["fix_pre_seeded"] = p.get("signature") in seeded_sigs if p.get("signature") else False

    # Build output state
    state = {
        "timestamp": ts_now(),
        "kb_size_growth": kb_growth,
        "script_failures": {
            "total_unique_failures": failures.get("total_unique_failures", 0),
            "high_risk_scripts": failures.get("high_risk_scripts", []),
        },
        "cron_overload": cron_overload,
        "disk_pressure": disk_pressure,
        "agent_health": agent_health,
        "predictions": all_predictions,
        "fixes_pre_seeded": len(seeded_fixes),
        "prediction_horizon_secs": PREDICTION_HORIZON_SECS,
    }

    # Print summary
    log(f"KB size: {kb_growth.get('current_size_mb', '?')} MB | "
        f"growth: {kb_growth.get('growth_rate_mb_per_day', 0)} MB/day | "
        f"status: {kb_growth.get('status', 'ok')}")
    log(f"Cron overload: {cron_overload.get('status', 'ok')} | "
        f"missed_hb: {cron_overload.get('missed_heartbeats', 0)} | "
        f"last_hb_age: {cron_overload.get('last_heartbeat_age_secs', '?')}s")
    log(f"Disk pressure: {disk_pressure.get('disk_usage_pct', 0)}% | "
        f"KB growth: {disk_pressure.get('growth_rate_mb_per_day', 0)} MB/day | "
        f"status: {disk_pressure.get('status', 'ok')}")
    log(f"Agent health: mem_trend={agent_health.get('memory_mb_trend', 0)} MB | "
        f"poll_trend={agent_health.get('poll_ms_trend', 0)} ms | "
        f"status: {agent_health.get('status', 'ok')}")
    log(f"Total predictions: {len(all_predictions)} | fixes pre-seeded: {len(seeded_fixes)}")

    # Write state
    if not args.dry_run:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = str(STATE_FILE) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, STATE_FILE)
        log(f"Wrote state to {STATE_FILE}")

    log("=== KB Self-Predict finished ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
