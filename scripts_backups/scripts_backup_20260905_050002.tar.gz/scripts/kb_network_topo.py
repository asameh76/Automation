#!/usr/bin/env python3
"""
KB Network Topo - Network topology.
"""

import json
import subprocess
import datetime
from pathlib import Path


TOPO_FILE = Path("/root/.hermes/state/kb_network_topo.json")
LOG_FILE = Path("/root/.hermes/logs/kb_network_topo.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def get_listening_ports():
    ports = []
    try:
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        for line in result.stdout.split("\n"):
            if "LISTEN" in line:
                parts = line.split()
                if len(parts) >= 4:
                    addr = parts[3]
                    if ":" in addr:
                        port_part = addr.split(":")[-1]
                        try:
                            port = int(port_part)
                            ports.append(port)
                        except ValueError:
                            pass
    except Exception:
        pass
    return ports


def get_ips():
    ips = []
    try:
        result = subprocess.run(
            ["ip", "addr", "show"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        for line in result.stdout.split("\n"):
            if "inet " in line:
                parts = line.strip().split()
                if len(parts) >= 2:
                    ips.append(parts[1])
    except Exception:
        pass
    return ips


def main():
    log("=== KB Network Topo started ===")

    topo = {
        "timestamp": datetime.datetime.now().isoformat(),
        "listening_ports": get_listening_ports(),
        "ip_addresses": get_ips(),
    }

    TOPO_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TOPO_FILE, "w") as fh:
        json.dump(topo, fh, indent=2)

    log(f"=== KB Network Topo: {len(topo['listening_ports'])} ports, {len(topo['ip_addresses'])} IPs ===")


if __name__ == "__main__":
    main()
