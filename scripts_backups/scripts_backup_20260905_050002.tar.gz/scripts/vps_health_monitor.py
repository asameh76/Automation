#!/usr/bin/env python3
"""
VPS Health Monitor — real-world sensor layer for gemgyms.com
Tests: HTTP 200, SSL cert, WooCommerce API, key page content
Runs every 5 min via cron. Silent when healthy; Telegram alert when any sensor fails.
"""
import subprocess, json, os, sys, re, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime

# ── Config ──────────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = "864983959"
STATE_FILE         = Path("/root/.hermes/state/vps_health_monitor.json")
LOG_FILE           = Path("/root/.hermes/logs/vps_health_monitor.log")
LOCK_FILE          = Path("/root/.hermes/state/vps_health_monitor.lock")
ERRORS_LOG         = Path("/root/.hermes/logs/errors.log")

# Load env
subprocess.run("export $(grep -v '^#' /root/.hermes-keys/.env | xargs) 2>/dev/null; true", shell=True)

# ── Targets ─────────────────────────────────────────────────────────────────
TARGETS = [
    {
        "name":    "gemgyms.com (HTTPS)",
        "url":     "https://gemgyms.com/",
        "expect":  200,
        "check":   "content",
        "content_match": ["gym", "fitness", "Gem", "gym"],
    },
    {
        "name":    "gemgyms.com SSL",
        "url":     "https://gemgyms.com/",
        "expect":  200,
        "check":   "ssl_days_left",
        "min_days": 7,
    },
    {
        "name":    "gemgyms.com WooCommerce API",
        "url":     "https://gemgyms.com/wp-json/wc/v3/products",
        "auth":    True,   # use WooCommerce credentials from env
        "expect":  200,
        "check":   "status",
    },
    {
        "name":    "gemgyms.com WordPress REST",
        "url":     "https://gemgyms.com/wp-json/",
        "expect":  200,
        "check":   "content",
        "content_match": ["name", "description"],
    },
    {
        "name":    "gemgyms.com /wp-admin",
        "url":     "https://gemgyms.com/wp-admin/",
        "expect":  200,
        "check":   "content",
        "content_match": ["dashboard", "WordPress"],
        "follow_redirects": True,
    },
]

# ── Helpers ─────────────────────────────────────────────────────────────────
def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[VPS-MONITOR {ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def send_telegram(msg):
    if not TELEGRAM_BOT_TOKEN:
        log(f"[ALERT] {msg}")
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    subprocess.run(
        ["curl", "-s", "-X", "POST", url,
         "-d", f"chat_id={TELEGRAM_CHAT_ID}",
         "-d", f"text={msg}"],
        capture_output=True)

def get_ssl_days(hostname):
    """Return days until SSL cert expires, or -1 on error. Uses openssl."""
    try:
        result = subprocess.run(
            ["openssl", "s_client", "-connect", f"{hostname}:443", "-servername", hostname],
            input="", capture_output=True, text=True, timeout=10
        )
        # Extract expiry date from openssl output
        match = re.search(r"[Nn]ot[Aa]fter[:=]\s*(.+)", result.stderr + result.stdout)
        if not match:
            return -1
        not_after = match.group(1).strip()
        # Try multiple date formats
        for fmt in ["%b %d %H:%M:%S %Y %Z", "%b %d %H:%M:%S %Y %Z", "%Y-%m-%d %H:%M:%SZ"]:
            try:
                exp_date = datetime.strptime(not_after, fmt)
                return (exp_date - datetime.now()).days
            except ValueError:
                continue
        return -1
    except Exception as e:
        log(f"SSL check failed: {e}")
        return -1

def check_url(target):
    """Run a single URL check. Returns (passed: bool, detail: str)."""
    url     = target["url"]
    expect  = target.get("expect", 200)
    check   = target.get("check", "status")
    auth    = target.get("auth", False)

    headers = {"User-Agent": "Hermes-VPS-Monitor/1.0"}

    try:
        if auth:
            ck = os.getenv("WOOCOMMERCE_CK", "")
            cs = os.getenv("WOOCOMMERCE_CS", "")
            if ck and cs:
                url += f"?consumer_key={ck}&consumer_secret={cs}&per_page=1"
            else:
                return True, "SKIP (no WooCommerce creds)"

        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as resp:
            status = resp.getcode()
            body   = resp.read().decode("utf-8", errors="ignore")

            if status != expect:
                return False, f"HTTP {status} (expected {expect})"

            elif check == "ssl_days_left":
                hostname = target["url"].split("//")[1].split("/")[0]
                days = get_ssl_days(hostname)
                min_days = target.get("min_days", 7)
                if days < 0:
                    return False, "Could not check SSL cert"
                if days < min_days:
                    return False, f"SSL expires in {days} days (min: {min_days})"
                return True, f"SSL OK ({days} days)"

            elif check == "content":
                matches = target.get("content_match", [])
                if matches:
                    found = [m for m in matches if m.lower() in body.lower()]
                    if not found:
                        return False, f"No content match for: {matches[:2]}"
                return True, f"Content OK ({len(body)} bytes)"

            else:
                return True, f"HTTP {status}"

    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}"
    except urllib.error.URLError as e:
        return False, f"Connection failed: {e.reason}"
    except Exception as e:
        return False, str(e)

def load_state():
    try:
        return json.load(open(STATE_FILE))
    except:
        return {"prev_failing": [], "last_ok": None}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)

def acquire_lock():
    """Prevent overlapping runs."""
    try:
        with open(LOCK_FILE, "x") as f:
            f.write(str(os.getpid()))
        return True
    except FileExistsError:
        return False

def release_lock():
    LOCK_FILE.unlink(missing_ok=True)

def _write_sensor_failure(newly_failing, results):
    """Write sensor failures to errors.log for KB capture loop."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ERRORS_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(ERRORS_LOG, "a") as f:
        for r in results:
            if not r["passed"]:
                f.write(f"{ts} SENSOR_FAILURE [{r['name']}] {r['detail']}\n")

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    if not acquire_lock():
        log("Already running — skipping this tick")
        return 0
    try:
        log("=== VPS Health Monitor START ===")
        state      = load_state()
        prev_fail  = set(state.get("prev_failing", []))
        new_fail   = []
        all_passed = True
        results    = []

        for target in TARGETS:
            name   = target["name"]
            passed, detail = check_url(target)
            results.append({"name": name, "passed": passed, "detail": detail})
            if passed:
                log(f"  ✅ {name}: {detail}")
            else:
                all_passed = False
                new_fail.append(name)
                log(f"  ❌ {name}: {detail}")

        # Detect new failures (alert only on new failures, not sustained ones)
        newly_failing = [n for n in new_fail if n not in prev_fail]
        if newly_failing:
            msg = "🚨 VPS ALERT — NEW FAILURES:\n" + "\n".join(f"• {r['name']}: {r['detail']}" for r in results if not r["passed"])
            log(f"[ALERT] New failures detected: {newly_failing}")
            send_telegram(msg)
            # Write to errors.log so KB capture loop picks these up
            _write_sensor_failure(newly_failing, results)

        # Update state
        state["prev_failing"] = new_fail
        state["last_run"]     = datetime.now().isoformat()
        if all_passed:
            state["last_ok"] = datetime.now().isoformat()
        save_state(state)

        if all_passed:
            log("=== VPS Health Monitor END: ALL PASSED ===")
        else:
            log(f"=== VPS Health Monitor END: {len(new_fail)} failing ===")

        return 0 if all_passed else 1
    finally:
        release_lock()

if __name__ == "__main__":
    sys.exit(main())
