#!/usr/bin/env python3
"""
KB Predictive Alerts — monitor disk/memory/CPU/containers, warn before thresholds hit,
write predicted errors to the knowledge base.

Usage:
  python3 kb_predictive_alerts.py --once   # single run, print + write alerts
  python3 kb_predictive_alerts.py           # loop every 60s, print + write alerts
  python3 kb_predictive_alerts.py --dry-run # no KB writes, print only
  python3 kb_predictive_alerts.py --test    # generate fake above-threshold values for testing

Thresholds (all configurable):
  --disk-warn  70  (root disk %)
  --disk-crit  85
  --mem-warn   70  (system memory % used)
  --mem-crit   85
  --cpu-warn   70  (system load avg / nproc %)
  --cpu-crit   85
  --swap-warn  50  (swap % used)
  --swap-crit  75
  --inode-warn 70  (inode %)
  --inode-crit 85
  --container-disk-warn  80  (container block IO % of limit)
  --container-mem-warn   80  (container memory % of limit)
  --container-cpu-warn   80  (container CPU %)
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# ─── Paths ────────────────────────────────────────────────────────────────────
KB_PATH = "/root/.hermes/error-knowledge-base.json"
STATE_FILE = "/root/.hermes/state/kb_predictive_alerts.state"

# ─── Default thresholds ───────────────────────────────────────────────────────
DEFAULTS = {
    "disk_warn": 70, "disk_crit": 85,
    "mem_warn":  70, "mem_crit":  85,
    "cpu_warn":  70, "cpu_crit":  85,
    "swap_warn": 50, "swap_crit": 75,
    "inode_warn": 70, "inode_crit": 85,
    "container_disk_warn": 80, "container_mem_warn": 80,
    "container_cpu_warn": 80,
}

# ─── State ────────────────────────────────────────────────────────────────────
def load_kb():
    if os.path.exists(KB_PATH):
        try:
            with open(KB_PATH) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"errors": []}


def save_kb(kb):
    Path(KB_PATH).parent.mkdir(parents=True, exist_ok=True)
    tmp = KB_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(kb, f, indent=2)
    os.replace(tmp, KB_PATH)


def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"seen_signatures": [], "last_run": None}


def save_state(state):
    Path(STATE_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_stateful_seen():
    """Return set of signatures already in the KB from prior runs."""
    kb = load_kb()
    return {e["signature"] for e in kb.get("errors", [])
            if e.get("component") == "predictive_alert"}


# ─── Metric collectors ────────────────────────────────────────────────────────

def get_disk_usage(path="/"):
    """Return (percent_used, avail_gb, total_gb)."""
    try:
        out = subprocess.check_output(
            ["df", "-B1", path], text=True, stderr=subprocess.DEVNULL
        )
        lines = out.strip().split("\n")
        if len(lines) < 2:
            return 0, 0, 0
        fields = lines[1].split()
        total = int(fields[1])
        used  = int(fields[2])
        avail = int(fields[3])
        pct   = (used / total * 100) if total else 0
        return round(pct, 1), round(avail / (1024**3), 2), round(total / (1024**3), 2)
    except Exception:
        return 0, 0, 0


def get_inode_usage(path="/"):
    """Return inode percent used."""
    try:
        out = subprocess.check_output(
            ["df", "-i", path], text=True, stderr=subprocess.DEVNULL
        )
        lines = out.strip().split("\n")
        if len(lines) < 2:
            return 0
        fields = lines[1].split()
        itotal = int(fields[1])
        iused  = int(fields[2])
        return round(iused / itotal * 100, 1) if itotal else 0
    except Exception:
        return 0


def get_memory():
    """Return (mem_pct, swap_pct, total_gb)."""
    try:
        out = subprocess.check_output(["free", "-b"], text=True, stderr=subprocess.DEVNULL)
        lines = out.strip().split("\n")
        mem_fields  = lines[1].split()
        swap_fields = lines[2].split()
        mem_total = int(mem_fields[1])
        mem_used  = int(mem_fields[2])
        mem_pct   = (mem_used / mem_total * 100) if mem_total else 0
        swap_total = int(swap_fields[1])
        swap_used  = int(swap_fields[2])
        swap_pct   = (swap_used / swap_total * 100) if swap_total else 0
        return round(mem_pct, 1), round(swap_pct, 1), round(mem_total / (1024**3), 2)
    except Exception:
        return 0, 0, 0


def get_cpu_load():
    """Return (load_pct, load1, load5, nproc). load_pct = load1/nproc*100."""
    try:
        with open("/proc/loadavg") as f:
            lavg = f.read().strip().split()
        load1 = float(lavg[0])
        load5 = float(lavg[1])
        nproc = os.sysconf("SC_NPROCESSORS_ONLN")
        load_pct = round(load1 / nproc * 100, 1) if nproc else 0
        return load_pct, load1, load5, nproc
    except Exception:
        return 0, 0, 0, 1


def get_docker_stats():
    """
    Return list of dicts with keys: name, id, mem_pct, cpu_pct, block_io_mb.
    Only returns running containers.
    """
    try:
        out = subprocess.check_output(
            ["docker", "stats", "--no-stream", "--format",
             "{{json .}}"],
            text=True, stderr=subprocess.DEVNULL
        )
        containers = []
        for line in out.strip().split("\n"):
            if not line:
                continue
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue

            def parse_mb(s):
                """Parse docker human-readable sizes like '13.3GB'."""
                s = s.strip()
                multipliers = {
                    "B": 1, "KB": 1024, "MB": 1024**2,
                    "GB": 1024**3, "TB": 1024**4,
                    "K": 1024, "M": 1024**2, "G": 1024**3,
                }
                for unit, mult in multipliers.items():
                    if s.endswith(unit):
                        num = float(s[:-len(unit)])
                        return round(num * mult / (1024**2), 2)
                return 0.0

            def parse_pct(s):
                return float(s.strip().rstrip("%"))

            mem_str = d.get("MemUsage", "")
            if "/" in mem_str:
                total_str = mem_str.split("/")[-1].strip()
                mem_total_mb = parse_mb(total_str)
            else:
                mem_total_mb = 0

            # mem perc is given directly
            try:
                mem_pct = float(d.get("MemPerc", "0").strip().rstrip("%"))
            except ValueError:
                mem_pct = 0.0

            try:
                cpu_pct = float(d.get("CPUPerc", "0").strip().rstrip("%"))
            except ValueError:
                cpu_pct = 0.0

            block_str = d.get("BlockIO", "")
            if "/" in block_str:
                read_mb  = parse_mb(block_str.split("/")[0])
                write_mb = parse_mb(block_str.split("/")[-1])
            else:
                read_mb = write_mb = 0.0

            containers.append({
                "name":      d.get("Name", "?"),
                "id":        d.get("ID", "?"),
                "mem_pct":   mem_pct,
                "mem_total_gb": round(mem_total_mb / 1024, 2),
                "cpu_pct":   cpu_pct,
                "block_read_mb":  read_mb,
                "block_write_mb": write_mb,
            })
        return containers
    except Exception as e:
        return []


# ─── Alert building ───────────────────────────────────────────────────────────

def make_signature(alert_type, resource, value, threshold, direction):
    ts = datetime.now(timezone.utc).strftime("%Y_%m_%d_%H_%M_%S")
    tag = hash(f"{alert_type}:{resource}:{threshold}") & 0xFFFFFF
    return f"pred_{ts}_{alert_type}_{resource}_{direction}_{tag:06x}"


def make_alert(alert_type, resource, current, threshold, direction,
               severity, message, extra=None):
    now = datetime.now(timezone.utc)
    sig = make_signature(alert_type, resource, current, threshold, direction)
    alert = {
        "signature":         sig,
        "component":         "predictive_alert",
        "tech_stack":        "system",
        "correlation_type":  f"predictive::{alert_type}",
        "correlation_group_size": 1,
        "correlation_confidence": "high",
        "first_seen":        now.strftime("%Y-%m-%d"),
        "last_seen":         now.strftime("%Y-%m-%d"),
        "occurrence_count":  1,
        "auto_fixed":        "false",
        "verified":          "false",
        "fix":               message,
        "correlated_sources": [],
        "fix_chains":        [],
        # Custom predictive fields
        "predictive": {
            "alert_type": alert_type,
            "resource":   resource,
            "current_value": current,
            "threshold":  threshold,
            "direction":  direction,
            "severity":   severity,
            "message":    message,
            "timestamp":  now.isoformat(),
        },
    }
    if extra:
        alert["predictive"].update(extra)
    return alert


def check_disk(thresholds):
    alerts = []
    disk_pct, avail_gb, total_gb = get_disk_usage("/")
    inode_pct = get_inode_usage("/")

    if disk_pct >= thresholds["disk_crit"]:
        alerts.append(make_alert(
            "disk_space", "root", disk_pct, thresholds["disk_crit"], "above",
            "critical",
            f"[CRITICAL] Disk usage at {disk_pct}% on / ({avail_gb}GB free of {total_gb}GB). "
            f"Threshold: {thresholds['disk_crit']}% — action required NOW.",
            {"avail_gb": avail_gb, "total_gb": total_gb}
        ))
    elif disk_pct >= thresholds["disk_warn"]:
        alerts.append(make_alert(
            "disk_space", "root", disk_pct, thresholds["disk_warn"], "above",
            "warning",
            f"[WARNING] Disk usage at {disk_pct}% on / ({avail_gb}GB free of {total_gb}GB). "
            f"Approaching critical threshold ({thresholds['disk_crit']}%). "
            f"Consider cleanup or volume expansion.",
            {"avail_gb": avail_gb, "total_gb": total_gb}
        ))

    if inode_pct >= thresholds["inode_crit"]:
        alerts.append(make_alert(
            "inode_space", "root", inode_pct, thresholds["inode_crit"], "above",
            "critical",
            f"[CRITICAL] Inode usage at {inode_pct}% on /. "
            f"Threshold: {thresholds['inode_crit']}%. "
            "Many small files may be filling up inodes."
        ))
    elif inode_pct >= thresholds["inode_warn"]:
        alerts.append(make_alert(
            "inode_space", "root", inode_pct, thresholds["inode_warn"], "above",
            "warning",
            f"[WARNING] Inode usage at {inode_pct}% on /. "
            f"Approaching critical threshold ({thresholds['inode_crit']}%)."
        ))

    return alerts


def check_memory(thresholds):
    alerts = []
    mem_pct, swap_pct, total_gb = get_memory()

    if mem_pct >= thresholds["mem_crit"]:
        alerts.append(make_alert(
            "memory", "system", mem_pct, thresholds["mem_crit"], "above",
            "critical",
            f"[CRITICAL] Memory usage at {mem_pct}% ({total_gb}GB total). "
            f"Threshold: {thresholds['mem_crit']}%. "
            "OOM killer may trigger soon."
        ))
    elif mem_pct >= thresholds["mem_warn"]:
        alerts.append(make_alert(
            "memory", "system", mem_pct, thresholds["mem_warn"], "above",
            "warning",
            f"[WARNING] Memory usage at {mem_pct}% ({total_gb}GB total). "
            f"Approaching critical threshold ({thresholds['mem_crit']}%)."
        ))

    if swap_pct >= thresholds["swap_crit"]:
        alerts.append(make_alert(
            "swap", "system", swap_pct, thresholds["swap_crit"], "above",
            "critical",
            f"[CRITICAL] Swap usage at {swap_pct}%. "
            f"System is heavily swapping — memory pressure severe."
        ))
    elif swap_pct >= thresholds["swap_warn"]:
        alerts.append(make_alert(
            "swap", "system", swap_pct, thresholds["swap_warn"], "above",
            "warning",
            f"[WARNING] Swap usage at {swap_pct}%. "
            "Memory pressure increasing."
        ))

    return alerts


def check_cpu(thresholds):
    alerts = []
    load_pct, load1, load5, nproc = get_cpu_load()

    if load_pct >= thresholds["cpu_crit"]:
        alerts.append(make_alert(
            "cpu_load", "system", load_pct, thresholds["cpu_crit"], "above",
            "critical",
            f"[CRITICAL] CPU load at {load_pct}% ({load1:.2f} 1m, {load5:.2f} 5m, "
            f"{nproc} cores). Threshold: {thresholds['cpu_crit']}%."
        ))
    elif load_pct >= thresholds["cpu_warn"]:
        alerts.append(make_alert(
            "cpu_load", "system", load_pct, thresholds["cpu_warn"], "above",
            "warning",
            f"[WARNING] CPU load at {load_pct}% ({load1:.2f} 1m, {load5:.2f} 5m, "
            f"{nproc} cores). Approaching critical ({thresholds['cpu_crit']}%)."
        ))

    return alerts


def check_containers(thresholds):
    alerts = []
    containers = get_docker_stats()

    for c in containers:
        name = c["name"]

        if c["mem_pct"] >= thresholds["container_mem_warn"]:
            sev = "critical" if c["mem_pct"] >= 95 else "warning"
            alerts.append(make_alert(
                "container_memory", name, c["mem_pct"],
                thresholds["container_mem_warn"], "above", sev,
                f"[{'CRITICAL' if sev=='critical' else 'WARNING'}] "
                f"Container '{name}' memory at {c['mem_pct']}% "
                f"(limit ~{c['mem_total_gb']}GB).",
                {"container_id": c["id"], "mem_total_gb": c["mem_total_gb"]}
            ))

        if c["cpu_pct"] >= thresholds["container_cpu_warn"]:
            alerts.append(make_alert(
                "container_cpu", name, c["cpu_pct"],
                thresholds["container_cpu_warn"], "above", "warning",
                f"[WARNING] Container '{name}' CPU at {c['cpu_pct']}%.",
                {"container_id": c["id"]}
            ))

    return alerts


# ─── KB merge ─────────────────────────────────────────────────────────────────

def dedup_and_merge(kb, new_alerts, seen_signatures):
    """Add new_alerts to kb, skip if already seen (idempotent on re-run)."""
    added = []
    for alert in new_alerts:
        sig = alert["signature"]
        if sig in seen_signatures:
            continue
        seen_signatures.add(sig)
        kb["errors"].append(alert)
        added.append(alert)
    return added


# ─── Main logic ───────────────────────────────────────────────────────────────

def run_once(args, thresholds):
    kb = load_kb()
    state = load_state()
    # Build seen set: stateful (from prior runs) + what we loaded from KB
    seen = set(state.get("seen_signatures", []))
    seen.update(load_stateful_seen())

    all_alerts = []
    all_alerts += check_disk(thresholds)
    all_alerts += check_memory(thresholds)
    all_alerts += check_cpu(thresholds)
    all_alerts += check_containers(thresholds)

    # Deduplicate within this run
    new_alerts = [a for a in all_alerts if a["signature"] not in seen]
    for a in new_alerts:
        seen.add(a["signature"])

    # Print
    if new_alerts:
        print(f"\n[{datetime.now().isoformat()}] Predictive Alerts Generated: {len(new_alerts)}")
        for a in new_alerts:
            pred = a["predictive"]
            print(f"  [{pred['severity'].upper():8s}] {pred['message']}")
    else:
        print(f"\n[{datetime.now().isoformat()}] No threshold breaches detected. All clear.")

    # Persist
    if not args.dry_run:
        if new_alerts:
            dedup_and_merge(kb, new_alerts, seen)
            save_kb(kb)
        # Update seen list (cap at 5000)
        state["seen_signatures"] = list(seen)[-5000:]
        state["last_run"] = datetime.now(timezone.utc).isoformat()
        save_state(state)

    return len(new_alerts)


def run_loop(args, thresholds, interval=60):
    print(f"Predictive alert monitor started (interval={interval}s). "
          f"Thresholds: {thresholds}")
    while True:
        try:
            run_once(args, thresholds)
        except Exception as e:
            print(f"[{datetime.now().isoformat()}] Error: {e}", file=sys.stderr)
        time.sleep(interval)


def test_mode(args, thresholds):
    """Override collectors to produce above-threshold values for every check."""
    import functools

    orig_disk   = get_disk_usage
    orig_mem    = get_memory
    orig_cpu    = get_cpu_load
    orig_docker = get_docker_stats

    def fake_disk(path="/"):
        return max(87.0, orig_disk(path)[0] + 5), 2.0, 38.0

    def fake_mem():
        m, s, t = orig_mem()
        return max(88.0, m + 5), max(60.0, s + 10), t

    def fake_cpu():
        p, l1, l5, n = orig_cpu()
        return max(90.0, p + 10), l1 + 1.0, l5 + 0.5, n

    def fake_docker():
        base = orig_docker()
        if not base:
            return [{
                "name": "test-container", "id": "test000",
                "mem_pct": 85.0, "mem_total_gb": 3.7,
                "cpu_pct": 82.0, "block_read_mb": 100, "block_write_mb": 50,
            }]
        return [{
            "name":      c["name"],
            "id":        c["id"],
            "mem_pct":   min(98.0, c["mem_pct"] + 15),
            "mem_total_gb": c["mem_total_gb"],
            "cpu_pct":   min(99.0, c["cpu_pct"] + 20),
            "block_read_mb":  c["block_read_mb"],
            "block_write_mb": c["block_write_mb"],
        } for c in base]

    # Monkey-patch
    import sys as _sys
    globs = _sys.modules[__name__].__dict__
    globs["get_disk_usage"] = fake_disk
    globs["get_memory"]     = fake_mem
    globs["get_cpu_load"]   = fake_cpu
    globs["get_docker_stats"] = fake_docker

    print("\n[TEST MODE] Injecting above-threshold values to verify alert generation.\n")
    return run_once(args, thresholds)


# ─── CLI ──────────────────────────────────────────────────────────────────────

def parse_thresholds(args):
    t = dict(DEFAULTS)
    if args.disk_warn:   t["disk_warn"]   = args.disk_warn
    if args.disk_crit:   t["disk_crit"]   = args.disk_crit
    if args.mem_warn:    t["mem_warn"]    = args.mem_warn
    if args.mem_crit:    t["mem_crit"]    = args.mem_crit
    if args.cpu_warn:    t["cpu_warn"]    = args.cpu_warn
    if args.cpu_crit:    t["cpu_crit"]    = args.cpu_crit
    if args.swap_warn:   t["swap_warn"]   = args.swap_warn
    if args.swap_crit:   t["swap_crit"]   = args.swap_crit
    if args.inode_warn:  t["inode_warn"]  = args.inode_warn
    if args.inode_crit:  t["inode_crit"]  = args.inode_crit
    if args.container_disk_warn: t["container_disk_warn"] = args.container_disk_warn
    if args.container_mem_warn:  t["container_mem_warn"]  = args.container_mem_warn
    if args.container_cpu_warn:  t["container_cpu_warn"]  = args.container_cpu_warn
    return t


def main():
    parser = argparse.ArgumentParser(
        description="KB Predictive Alerts — warn before system thresholds are breached."
    )
    parser.add_argument("--once", action="store_true",
                        help="Run once and exit (default: loop every 60s)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print alerts but do not write to the KB")
    parser.add_argument("--test", action="store_true",
                        help="Inject above-threshold fake values to test alert generation")
    parser.add_argument("--interval", type=int, default=60,
                        help="Loop interval in seconds (default: 60)")
    # Thresholds
    g = parser.add_argument_group("thresholds (warn/crit)")
    g.add_argument("--disk-warn",   type=float, help="Root disk %% warn (default: 70)")
    g.add_argument("--disk-crit",   type=float, help="Root disk %% crit (default: 85)")
    g.add_argument("--mem-warn",    type=float, help="Memory %% warn (default: 70)")
    g.add_argument("--mem-crit",    type=float, help="Memory %% crit (default: 85)")
    g.add_argument("--cpu-warn",    type=float, help="CPU load %% warn (default: 70)")
    g.add_argument("--cpu-crit",    type=float, help="CPU load %% crit (default: 85)")
    g.add_argument("--swap-warn",   type=float, help="Swap %% warn (default: 50)")
    g.add_argument("--swap-crit",   type=float, help="Swap %% crit (default: 75)")
    g.add_argument("--inode-warn",  type=float, help="Inode %% warn (default: 70)")
    g.add_argument("--inode-crit",  type=float, help="Inode %% crit (default: 85)")
    g.add_argument("--container-disk-warn",  type=float, help="Container block IO %% warn")
    g.add_argument("--container-mem-warn",   type=float, help="Container memory %% warn")
    g.add_argument("--container-cpu-warn",   type=float, help="Container CPU %% warn")

    args = parser.parse_args()
    thresholds = parse_thresholds(args)

    if args.test:
        count = test_mode(args, thresholds)
        sys.exit(0 if count > 0 else 1)

    if args.once:
        count = run_once(args, thresholds)
        sys.exit(0 if count >= 0 else 1)

    run_loop(args, thresholds, args.interval)


if __name__ == "__main__":
    main()
