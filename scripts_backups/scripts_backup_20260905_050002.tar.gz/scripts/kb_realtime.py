#!/usr/bin/env python3
"""
KB Realtime - Real-Time Monitor for errors.
"""

import json
import time
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
REALTIME_FILE = Path("/root/.hermes/state/kb_realtime.json")
LOG_FILE = Path("/root/.hermes/logs/kb_realtime.log")

POLL_INTERVAL = 5


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def tail_log(path, lines=50):
    """Get last N lines of a file."""
    if not path.exists():
        return []
    try:
        with open(path) as fh:
            all_lines = fh.readlines()
        return all_lines[-lines:]
    except Exception:
        return []


def detect_errors(lines, kb):
    """Detect known errors from KB in log lines."""
    known_errors = {}
    for entry in kb.get("knowledge_base", []):
        error_pattern = entry.get("error", "").lower()
        if error_pattern:
            known_errors[error_pattern] = entry.get("status", "unknown")

    detected = []
    for line in lines:
        lower = line.lower()
        for pattern, status in known_errors.items():
            if pattern in lower:
                detected.append({
                    "pattern": pattern[:60],
                    "status": status,
                    "line": line.strip()[:200],
                    "timestamp": datetime.datetime.now().isoformat(),
                })
    return detected


def main():
    log("=== KB Realtime Monitor started ===")

    last_pos = 0
    if REALTIME_FILE.exists():
        try:
            with open(REALTIME_FILE) as fh:
                state = json.load(fh)
                last_pos = state.get("last_log_pos", 0)
        except Exception:
            pass

    kb = read_kb()

    # Poll for new errors
    if ERRORS_LOG.exists():
        current_size = ERRORS_LOG.stat().st_size
        if current_size > last_pos:
            with open(ERRORS_LOG) as fh:
                fh.seek(last_pos)
                new_lines = fh.readlines()
            last_pos = current_size

            detected = detect_errors(new_lines, kb)

            state = {
                "timestamp": datetime.datetime.now().isoformat(),
                "last_log_pos": last_pos,
                "new_errors": len(detected),
                "detected_errors": detected[-10:],
            }

            REALTIME_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(REALTIME_FILE, "w") as fh:
                json.dump(state, fh, indent=2)

            if detected:
                log(f"Detected {len(detected)} known errors")
        else:
            state = {
                "timestamp": datetime.datetime.now().isoformat(),
                "last_log_pos": last_pos,
                "new_errors": 0,
                "detected_errors": [],
            }
            REALTIME_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(REALTIME_FILE, "w") as fh:
                json.dump(state, fh, indent=2)

    log("=== KB Realtime Monitor cycle complete ===")


if __name__ == "__main__":
    main()
