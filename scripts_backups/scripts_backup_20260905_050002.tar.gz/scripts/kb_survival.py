#!/usr/bin/env python3
"""
KB Survival - Survival Capsule backup.
"""

import json
import shutil
import tarfile
import datetime
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
CAPSULE_DIR = Path("/root/.hermes/capsule")
LOG_FILE = Path("/root/.hermes/logs/kb_survival.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def main():
    log("=== KB Survival started ===")

    CAPSULE_DIR.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    capsule_name = f"capsule-{timestamp}.tar.gz"
    capsule_path = CAPSULE_DIR / capsule_name

    # Create capsule backup
    try:
        with tarfile.open(capsule_path, "w:gz") as tar:
            # Add KB
            if KB_FILE.exists():
                tar.add(KB_FILE, arcname="error-knowledge-base.json")

            # Add state files
            state_dir = Path("/root/.hermes/state")
            if state_dir.exists():
                for f in state_dir.glob("*.json"):
                    tar.add(f, arcname=f"state/{f.name}")

            # Add logs
            log_dir = Path("/root/.hermes/logs")
            if log_dir.exists():
                for f in log_dir.glob("*.log"):
                    tar.add(f, arcname=f"logs/{f.name}")

        log(f"Created capsule: {capsule_path}")

        # Prune old capsules (keep last 10)
        capsules = sorted(CAPSULE_DIR.glob("capsule-*.tar.gz"), key=lambda p: p.stat().st_mtime)
        for old in capsules[:-10]:
            old.unlink()
            log(f"Pruned: {old.name}")

    except Exception as e:
        log(f"Capsule creation failed: {e}")

    log("=== KB Survival finished ===")


if __name__ == "__main__":
    main()
