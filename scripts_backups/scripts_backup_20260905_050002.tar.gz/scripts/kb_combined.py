#!/usr/bin/env python3
"""
KB Combined - Main cron script
Runs verify + accelerate + certify in one pass.
Reads KB from /root/.hermes/error-knowledge-base.json
Uses fcntl flock for locking.
Calls subprocess for kb_capture_fix.py, kb_self_edit.py etc.
"""

import json
import os
import sys
import fcntl
import subprocess
import datetime
from pathlib import Path


SCRIPTS_DIR = Path("/root/.hermes/scripts")
KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOCK_FILE = Path("/root/.hermes/.kb_combined.lock")
STATE_DIR = Path("/root/.hermes/state")
LOG_FILE = Path("/root/.hermes/logs/kb_combined.log")


def log(msg):
    """Log a message with timestamp."""
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    """Read KB with flock."""
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    """Write KB with flock."""
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def run_script(name):
    """Run a KB script via subprocess."""
    script = SCRIPTS_DIR / name
    if not script.exists():
        log(f"WARNING: {name} not found, skipping")
        return False
    try:
        result = subprocess.run(
            [sys.executable, str(script)],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            log(f"OK: {name}")
            return True
        else:
            log(f"FAIL: {name} -> {result.stderr[:200]}")
            return False
    except Exception as e:
        log(f"ERROR: {name} -> {e}")
        return False


def main():
    log("=== KB Combined started ===")
    start = datetime.datetime.now()

    # Ensure state dir
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    # Acquire lock
    with open(LOCK_FILE, "w") as lf:
        fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
        try:
            # Run capture/fix first
            run_script("kb_capture_fix.py")

            # Run self-edit curiosity loop
            run_script("kb_self_edit.py")

            # Run verification loop (authoritative — works on errors[])
            run_script("kb_verify_engine.py")

            # Run self-certify
            run_script("kb_self_certify.py")

            # Run self-evaluate
            run_script("kb_self_evaluate.py")

            # Run self-heal
            run_script("kb_self_heal.py")

            # Run feedback loop
            run_script("kb_feedback_loop.py")

            # Run prune
            run_script("kb_prune.py")

            # Run predictor
            run_script("kb_predictor.py")

            # Backup KB to GitHub + R2
            run_script("kb_self_replicate.py")

            # Survival capsule — full identity snapshot (rotate + deliver)
            run_script("kb_survival_capsule.py")

        finally:
            fcntl.flock(lf.fileno(), fcntl.LOCK_UN)

    elapsed = (datetime.datetime.now() - start).total_seconds()
    log(f"=== KB Combined finished in {elapsed:.1f}s ===")


if __name__ == "__main__":
    main()
