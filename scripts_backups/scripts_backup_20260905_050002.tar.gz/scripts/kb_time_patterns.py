#!/usr/bin/env python3
"""
KB Time Patterns - Detect time-based error patterns from the error knowledge base.
Groups errors by hour-of-day and day-of-week, detects recurring patterns
(e.g. "crashes at 3am", "fails every Monday"), writes findings to KB state file.
"""

import json
import datetime
import fcntl
from pathlib import Path
from collections import defaultdict

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE = Path("/root/.hermes/state/kb_time_patterns.json")
LOG_FILE = Path("/root/.hermes/logs/kb_time_patterns.log")

# Minimum occurrences to flag a time pattern
MIN_PATTERN_OCCURRENCES = 2


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def parse_timestamp(ts_str):
    """Parse an ISO timestamp string, trying multiple formats."""
    if not ts_str:
        return None
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ):
        try:
            return datetime.datetime.strptime(ts_str, fmt)
        except ValueError:
            pass
    return None


def weekday_name(idx):
    return ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][idx]


def main():
    log("=== KB Time Patterns started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"Could not read KB: {e}")
        kb = {"errors": []}

    errors = kb.get("errors", []) if isinstance(kb, dict) else kb

    # ── Per-bucket counters ──────────────────────────────────────────────────
    hourly   = defaultdict(list)   # hour (0-23)  -> [(dt, sig, component), ...]
    daily    = defaultdict(list)   # weekday idx  -> [(dt, sig, component), ...]
    monthly  = defaultdict(list)   # day-of-month -> [(dt, sig, component), ...]

    skipped = 0

    for entry in errors:
        sig      = entry.get("signature", "")
        comp     = entry.get("component", "")
        ts_str   = entry.get("timestamp") or entry.get("first_seen", "")

        dt = parse_timestamp(ts_str)
        if not dt:
            skipped += 1
            continue

        key = (dt, sig, comp)

        hourly[dt.hour].append(key)
        daily[dt.weekday()].append(key)
        monthly[dt.day].append(key)

    log(f"Parsed {sum(len(v) for v in hourly.values())} timestamped errors, skipped {skipped}")

    # ── Pattern detection ────────────────────────────────────────────────────
    def detect_peaks(buckets, threshold=None, label=""):
        peaks = []
        total = sum(len(v) for v in buckets.values())
        for bucket, items in sorted(buckets.items()):
            if len(items) >= (threshold or (total // 7 or MIN_PATTERN_OCCURRENCES)):
                peaks.append({
                    "bucket":  bucket,
                    "label":   label,
                    "count":   len(items),
                    "samples": [
                        {"signature": s, "component": c, "timestamp": str(dt)}
                        for dt, s, c in items[:5]   # up to 5 sample signatures
                    ],
                })
        return peaks

    # Hourly: flag any hour with ≥ 2× average occurrences
    avg_hourly = sum(len(v) for v in hourly.values()) / max(len(hourly), 1)
    hour_peaks = detect_peaks(hourly, threshold=max(2, int(avg_hourly * 1.5)),
                              label="hourly")

    # Daily: flag any weekday with above-average occurrences
    avg_daily = sum(len(v) for v in daily.values()) / max(len(daily), 1)
    day_peaks = detect_peaks(daily, threshold=max(MIN_PATTERN_OCCURRENCES, int(avg_daily * 1.3)),
                             label="weekday")

    # Monthly: flag any day-of-month with ≥ 2× average
    avg_monthly = sum(len(v) for v in monthly.values()) / max(len(monthly), 1)
    month_peaks = detect_peaks(monthly, threshold=max(MIN_PATTERN_OCCURRENCES, int(avg_monthly * 2)),
                               label="day_of_month")

    # ── Human-readable summary ───────────────────────────────────────────────
    def fmt_bucket(bucket, kind):
        if kind == "hourly":
            return f"{bucket:02d}:00–{bucket:02d}:59"
        if kind == "weekday":
            return weekday_name(bucket)
        return f"day {bucket}"

    summaries = []
    for peaks, kind in [(hour_peaks, "hourly"), (day_peaks, "weekday"), (month_peaks, "day_of_month")]:
        for p in peaks:
            summaries.append(f"  [{kind}] {fmt_bucket(p['bucket'], kind)} — {p['count']} occurrences")

    if summaries:
        log("Detected patterns:\n" + "\n".join(summaries))
    else:
        log("No significant time patterns detected.")

    # ── Build and write state ────────────────────────────────────────────────
    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_errors_analyzed": sum(len(v) for v in hourly.values()),
        "skipped_no_timestamp": skipped,
        "hourly_patterns":       hour_peaks,
        "weekday_patterns":       day_peaks,
        "day_of_month_patterns": month_peaks,
        "summary": [
            f"{fmt_bucket(p['bucket'], p['label'])}: {p['count']} occurrences"
            for p in (hour_peaks + day_peaks + month_peaks)
        ],
    }

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Time Patterns done — {len(state['summary'])} patterns written ===")


if __name__ == "__main__":
    main()
