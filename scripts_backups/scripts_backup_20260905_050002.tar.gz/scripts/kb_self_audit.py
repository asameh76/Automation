#!/usr/bin/env python3
"""
kb_self_audit.py — Self-audit cron (hourly)
Scans for capability gaps: missing sync, broken services, stale creds, health drops.
Fixes what it can autonomously. Reports to Hermes KB + Telegram only on unresolved.
"""
import subprocess, json, os, sys, re
from pathlib import Path
from datetime import datetime

# ── Paths ──────────────────────────────────────────────────────────────────
HERMES_DIR   = Path("/root/.hermes")
SCRIPTS_DIR  = HERMES_DIR / "scripts"
STATE_DIR    = HERMES_DIR / "state"
KEYS_FILE    = Path("/root/.hermes-keys/.env")
KB_FILE      = HERMES_DIR / "error-knowledge-base.json"
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")

STATE_AUDIT  = STATE_DIR / "kb_self_audit_state.json"
LOCK_FILE    = STATE_DIR / "kb_self_audit.lock"

# ── Helpers ─────────────────────────────────────────────────────────────────
def run(cmd, capture=True):
    r = subprocess.run(cmd, shell=True, capture_output=capture, text=True)
    return r.stdout.strip() if capture else (r.returncode, r.stderr.strip())

def read_json(path):
    try:
        return json.load(open(path))
    except Exception:
        return None

def write_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)

def load_state():
    d = read_json(STATE_AUDIT) or {}
    d.setdefault("runs", [])
    d.setdefault("gaps_found", [])
    d.setdefault("gaps_fixed", [])
    return d

def save_state(d):
    write_json(STATE_AUDIT, d)

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[SELF-AUDIT {ts}] {msg}"
    print(line)
    with open(STATE_DIR / "kb_self_audit.log", "a") as f:
        f.write(line + "\n")

# ── Audit Checks ────────────────────────────────────────────────────────────
def check_kb_health():
    """KB must have health >= 80%. If below, trigger self-healing."""
    kb = read_json(KB_FILE)
    if not kb:
        return "KB_FILE_MISSING", "KB file not found", True
    
    errors = kb.get("errors", [])
    total = len(errors)
    if total == 0:
        return "KB_EMPTY", f"0 entries — KB wiped/corrupted", True
    
    verified_types = ['verified','manual_verified','canary_verified','cross_verified','self_healed']
    v = sum(1 for e in errors if e.get("verified") in verified_types)
    health = round(v * 100 / max(total, 1), 1)
    
    if health < 80:
        return "KB_HEALTH_LOW", f"{health}% ({v}/{total} verified)", True
    return "OK", f"{health}% ({v}/{total})", False

def check_github_sync():
    """Ensure KB scripts are synced to GitHub repo."""
    repo_paths = [
        Path("/root/Gersy-Hermes"),
        Path("/root/asameh76/Gersy-Hermes"),
        Path("/root/Automation"),
        Path("/root/asameh76/Automation"),
    ]
    found = [p for p in repo_paths if p.exists()]
    if found:
        # Test push access
        for rp in found:
            result = run(f"cd {rp} && git fetch origin 2>&1")
            if "Cloning" not in result and "fatal" not in result.lower():
                return "OK", f"Synced: {rp.name}", False
        return "GITHUB_WRITE_BLOCKED", f"Repos exist but no write access", True
    
    # Try to clone if token exists
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        # Source from keys file
        run("export $(grep -v '^#' /root/.hermes-keys/.env | xargs) 2>/dev/null; true")
        token = os.environ.get("GITHUB_TOKEN", "")
    
    if not token:
        return "GITHUB_NO_TOKEN", "No GITHUB_TOKEN — cannot clone repos", False
    
    # Attempt clone Gersy-Hermes
    result = run(f"cd /root && git clone https://{token}@github.com/asameh76/Gersy-Hermes.git 2>&1")
    if "Cloning" in result or "Receiving" in result or result == "" or "warning" in result.lower():
        run(f"cd /root && git clone https://{token}@github.com/asameh76/Automation.git 2>&1")
        return "GITHUB_SYNCED", "Cloned Gersy-Hermes + Automation", True
    return "GITHUB_CLONE_FAILED", f"Clone failed: {result[:200]}", False

def check_gemgyms_reachable():
    """Is gemgyms.com responding?"""
    code = run("curl -s -o /dev/null -w '%{http_code}' https://gemgyms.com --max-time 10 --fail 2>/dev/null || echo '000'")
    if code == "200":
        return "OK", "gemgyms.com is up", False
    return "GEMGYMS_DOWN", f"HTTP {code}", True

def check_jollyjewelry_dns():
    """Is jollyjewelry.com resolving?"""
    code = run("curl -s -o /dev/null -w '%{http_code}' http://jollyjewelry.com --max-time 8 2>&1 || true")
    if code == "200":
        return "OK", "jollyjewelry.com resolves", False
    if "Could not resolve" in code or "Name or service not known" in code:
        return "JOLLYJEWELRY_NXDOMAIN", "jollyjewelry.com not resolving (NXDOMAIN)", True
    return "JOLLYJEWELRY_WARN", f"HTTP {code}", False

def check_services():
    """Check critical systemd services — find failed Hermes/systemd units."""
    issues = []
    
    # Source env for WOOCOMMERCE creds check
    run("export $(grep -v '^#' /root/.hermes-keys/.env | xargs) 2>/dev/null; true")
    
    # Check failed units
    out = run("systemctl list-units --failed --no-legend 2>/dev/null || true")
    for line in out.splitlines():
        line = line.strip().lstrip("● ")
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2 or '*' in parts[0]:
            continue
        unit = parts[0]
        # Some lines are: UNIT LOAD ACTIVE SUB DESCRIPTION
        if unit == "UNIT" or not unit.endswith(".service"):
            continue
        # Ignore vendor/ignorable services
        ignore = ["cloud-init", "snapd", "cloud-final", "polkit", "hermes.service"]
        if any(x in unit for x in ignore):
            continue
        if "hermes" in unit.lower() or "caddy" in unit.lower():
            issues.append(f"FAILED_UNIT:{unit}")
    
    # Check deleted binaries for Hermes services
    hermes_svcs = ["hermes-gateway.service", "hermes-agent.service", "hermes.service"]
    for svc in hermes_svcs:
        exec_path = run(f"systemctl show {svc} -p ExecStart --value 2>/dev/null || true")
        m = re.search(r'path=([^\s;]+)', exec_path)
        candidate = m.group(1) if m else ""
        if not candidate:
            continue
        # Normalize: strip leading */ and resolve
        candidate = candidate.lstrip("*/").split()[0]
        if candidate.startswith("~"):
            candidate = os.path.expanduser(candidate)
        if candidate and not os.path.exists("/" + candidate) and not os.path.exists(candidate):
            status = run(f"systemctl is-active {svc} 2>/dev/null || true")
            if status == "active":
                issues.append(f"DELETED_BIN:{svc}")
    
    if not issues:
        return "OK", "All services healthy", False
    return "SERVICE_ISSUES", "; ".join(issues), True

def check_disk_space():
    """Disk must have > 10% free."""
    out = run("df -h / | tail -1")
    try:
        pct = int(re.sub(r'[^\d]', '', out.split()[-2]))
        if pct > 90:
            return "DISK_CRITICAL", f"{pct}% used", True
        if pct > 80:
            return "DISK_WARNING", f"{pct}% used", False
    except Exception:
        pass
    return "OK", "Disk OK", False

def check_kb_woo_sync():
    """Verify WooCommerce creds still work."""
    ck = os.environ.get("WOOCOMMERCE_CK", "")
    cs = os.environ.get("WOOCOMMERCE_CS", "")
    url = os.environ.get("WOOCOMMERCE_URL", "https://gemgyms.com")
    if not ck or not cs:
        return "WOOCOMMERCE_NO_CREDS", "No WooCommerce credentials in env", False
    
    resp = run(f"curl -s '{url}/wp-json/woocommerce/v1/orders?consumer_key={ck}&consumer_secret={cs}&per_page=1' --max-time 10")
    if '"id"' in resp or '"orders"' in resp:
        return "OK", "WooCommerce API reachable", False
    if "Invalid" in resp or "authentication_failed" in resp.lower():
        return "WOOCOMMERCE_AUTH_FAIL", "WooCommerce auth failed — creds may be revoked", True
    return "WOOCOMMERCE_WARN", f"Unexpected response: {resp[:100]}", False

def check_dkim():
    """Check if DKIM is configured (returns unknown if can't verify)."""
    # This requires DNS access — just check if email log has dkim=
    result = run("grep -i dkim /var/log/mail.log 2>/dev/null | tail -1 || true")
    if "dkim=Pass" in result:
        return "OK", "DKIM passing", False
    if result:
        return "DKIM_WARN", "DKIM not confirmed in mail.log", False
    return "DKIM_UNKNOWN", "Cannot verify DKIM from this host", False

def check_woo_seo_products():
    """Count WooCommerce products — SEO fixture needs products."""
    ck = os.environ.get("WOOCOMMERCE_CK", "")
    cs = os.environ.get("WOOCOMMERCE_CS", "")
    url = os.environ.get("WOOCOMMERCE_URL", "https://gemgyms.com")
    if not ck or not cs:
        return "WOOCOMMERCE_NO_CREDS", "No credentials", False
    
    resp = run(f"curl -s '{url}/wp-json/wc/v3/products?consumer_key={ck}&consumer_secret={cs}&per_page=1' --max-time 10")
    if '"id"' in resp:
        try:
            data = json.loads(resp)
            total = int(data.get('headers', {}).get('X-WP-Total', '?'))
            return "OK", f"{total} products found", False
        except:
            return "OK", "Products accessible", False
    return "WOOCOMMERCE_NO_PRODUCTS", "No products found or API error", False

# ── Autofix ─────────────────────────────────────────────────────────────────
def try_fix(gap_id, detail):
    """Attempt autonomous fix. Returns (fixed: bool, message: str)."""
    fixed_msgs = []
    
    if gap_id == "KB_HEALTH_LOW":
        # Run kb_combined to regenerate KB entries
        result = run("python3 /root/.hermes/scripts/kb_combined.py 2>&1 | tail -5")
        if "Health" in result or "entries" in result:
            return True, f"kb_combined ran: {result[:150]}"
        return False, f"kb_combined did not improve health: {result[:100]}"
    
    if gap_id == "GEMGYMS_DOWN":
        # Try to restart any related containers
        run("docker ps --format '{{.Names}}' | grep -i gem || true")
        return False, "gemgyms.com down — requires human attention (could be CDN/hosting)"
    
    if gap_id == "SERVICE_ISSUES":
        # Try to restart failed Hermes services
        if "DELETED_BIN" in detail:
            run("systemctl daemon-reload 2>/dev/null")
            m = re.search(r'DELETED_BIN:([^\s;]+)', detail)
            if m:
                svc = m.group(1)
                run(f"systemctl restart {svc} 2>/dev/null || true")
                return True, f"Daemon-reloaded + restarted {svc}"
        return False, f"Service issues require human review: {detail}"
    
    if gap_id == "WOOCOMMERCE_AUTH_FAIL":
        return False, "WooCommerce auth failed — credentials may have been revoked. User must regenerate."
    
    if gap_id == "JOLLYJEWELRY_NXDOMAIN":
        return False, "jollyjewelry.com needs DNS configuration in Hostinger/Cloudflare — human required"
    
    if gap_id == "GITHUB_NO_TOKEN":
        return False, "No GITHUB_TOKEN in environment — cannot sync to GitHub"
    
    if gap_id == "GITHUB_CLONE_FAILED":
        return False, f"GitHub clone failed: {detail[:200]}"
    
    return False, "No autonomous fix available"

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    # Load env vars
    run("export $(grep -v '^#' /root/.hermes-keys/.env | xargs) 2>/dev/null; true")
    log("=== Self-Audit START ===")
    
    state = load_state()
    run_ts = datetime.now().isoformat()
    
    checks = [
        ("KB_HEALTH",         check_kb_health),
        ("GITHUB_SYNC",       check_github_sync),
        ("GEMGYMS_REACHABLE", check_gemgyms_reachable),
        ("JOLLYJEWELRY_DNS",  check_jollyjewelry_dns),
        ("SERVICES",          check_services),
        ("DISK_SPACE",        check_disk_space),
        ("WOOCOMMERCE_API",   check_kb_woo_sync),
        ("DKIM",              check_dkim),
        ("WOOCOMMERCE_PRODUCTS", check_woo_seo_products),
    ]
    
    all_ok = True
    gaps = []
    fixed = []
    unresolved = []
    
    for name, fn in checks:
        try:
            status, msg, needs_fix = fn()
        except Exception as e:
            status = f"ERROR:{name}"
            msg = str(e)[:100]
            needs_fix = True
        
        if status != "OK" and needs_fix:
            all_ok = False
            gaps.append({"check": name, "status": status, "msg": msg, "ts": run_ts})
            
            log(f"[FIX] {status}: {msg}")
            did_fix, fix_msg = try_fix(status, msg)
            if did_fix:
                fixed.append({"check": name, "status": status, "fix": fix_msg, "ts": run_ts})
                log(f"[FIXED] {status}: {fix_msg}")
            else:
                unresolved.append({"check": name, "status": status, "msg": msg, "fix_attempted": fix_msg, "ts": run_ts})
        elif status != "OK":
            log(f"[WARN] {status}: {msg}")
    
    # Update state
    state["runs"].append({
        "ts": run_ts,
        "all_ok": all_ok,
        "gaps": len(gaps),
        "fixed": len(fixed),
        "unresolved": len(unresolved),
    })
    state["gaps_found"] = state["gaps_found"][-20:] + gaps  # keep last 20
    state["gaps_fixed"] = state["gaps_fixed"][-20:] + fixed
    save_state(state)
    
    log(f"=== Self-Audit END: {'ALL OK' if all_ok else f'{len(unresolved)} unresolved, {len(fixed)} fixed'} ===")
    
    # Write unresolved gaps to KB for evolution engine to pick up
    if unresolved:
        kb = read_json(KB_FILE) or {"errors": []}
        for g in unresolved:
            sig = f"self_audit::{g['status']}"
            if not any(e.get("signature","").startswith("self_audit::") and e.get("status") == g["status"] for e in kb.get("errors", [])):
                kb["errors"].append({
                    "signature": sig,
                    "error": f"Self-audit gap: {g['check']}",
                    "component": "self_audit",
                    "fix_type": "investigate",
                    "status": g["status"],
                    "msg": g["msg"],
                    "fix_attempted": g.get("fix_attempted",""),
                    "verified": False,
                    "auto_fixed": False,
                    "success_count": 0,
                    "correlation_confidence": "medium",
                    "first_seen": run_ts,
                    "last_seen": run_ts,
                })
                write_json(KB_FILE, kb)
                log(f"[KB] Added unresolved gap: {sig}")
    
    # Print summary
    if all_ok:
        print("✅ Self-audit PASSED — all checks OK")
    else:
        print(f"⚠️  Self-audit: {len(unresolved)} unresolved, {len(fixed)} fixed")
        for g in unresolved:
            print(f"  [{g['check']}] {g['status']}: {g['msg']}")
    
    return 0 if all_ok else 1

if __name__ == "__main__":
    sys.exit(main())
