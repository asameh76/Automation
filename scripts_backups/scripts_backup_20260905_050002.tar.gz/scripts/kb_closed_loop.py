#!/usr/bin/env python3
"""
KB Closed-Loop - KB Closed-Loop Engine.
All phases correlated.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
CLOSED_LOOP_FILE = Path("/root/.hermes/state/kb_closed_loop.json")
LOG_FILE = Path("/root/.hermes/logs/kb_closed_loop.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def correlate_phases():
    """Correlate all KB phases."""
    phases = [
        "capture",
        "verify",
        "fix",
        "certify",
        "predict",
        "evolve",
    ]

    correlations = {}
    for phase in phases:
        state_file = Path(f"/root/.hermes/state/kb_{phase}.json")
        if state_file.exists():
            try:
                with open(state_file) as fh:
                    correlations[phase] = json.load(fh)
            except Exception:
                correlations[phase] = {}
        else:
            correlations[phase] = {}

    return correlations


def main():
    log("=== KB Closed-Loop started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    correlations = correlate_phases()

    total_entries = len(kb.get("knowledge_base", []))
    verified = sum(1 for e in kb.get("knowledge_base", []) if e.get("status") == "verified")
    investigate = sum(1 for e in kb.get("knowledge_base", []) if e.get("status") == "investigate")

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_entries": total_entries,
        "verified": verified,
        "investigate": investigate,
        "phase_correlations": correlations,
    }

    CLOSED_LOOP_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CLOSED_LOOP_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Closed-Loop: {total_entries} entries, {verified} verified, {investigate} investigate ===")


if __name__ == "__main__":
    main()
