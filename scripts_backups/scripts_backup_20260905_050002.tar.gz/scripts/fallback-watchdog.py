#!/usr/bin/env python3
"""
Fallback Watchdog - Fallback chain watchdog.
"""

import json
import time
import datetime
import fcntl
from pathlib import Path


WATCHDOG_FILE = Path("/root/.hermes/state/fallback_watchdog.json")
LOG_FILE = Path("/root/.hermes/logs/fallback_watchdog.log")
PID_FILE = Path("/root/.hermes/.fallback_watchdog.pid")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def is_running():
    """Check if watchdog is already running."""
    if not PID_FILE.exists():
        return False
    try:
        with open(PID_FILE) as fh:
            pid = int(fh.read().strip())
        import os
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def write_pid():
    """Write our PID."""
    import os
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(PID_FILE, "w") as fh:
        fh.write(str(os.getpid()))


def check_fallback_chain():
    """Check fallback chain health."""
    chain_state = Path("/root/.hermes/state/fallback_chain.json")
    if not chain_state.exists():
        return "unknown", "No fallback state"

    try:
        with open(chain_state) as fh:
            state = json.load(fh)
        active = state.get("active_provider", "unknown")
        return "ok", f"Active provider: {active}"
    except Exception as e:
        return "error", str(e)


def main():
    log("=== Fallback Watchdog started ===")

    if is_running():
        log("Already running, exiting")
        return

    write_pid()

    status, msg = check_fallback_chain()
    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "status": status,
        "message": msg,
    }

    WATCHDOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(WATCHDOG_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"Status: {status} - {msg}")
    log("=== Fallback Watchdog finished ===")


if __name__ == "__main__":
    main()
