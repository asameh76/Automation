#!/usr/bin/env python3
"""
KB Confidence — rank fix quality by past success rate.

Reads the KB at /root/.hermes/error-knowledge-base.json.

Per-fix-type + per-component stats are computed from:
  1. errors[] entries (fix, component, success_count, fail_count)
  2. fix_success_rates{} entries (already keyed by signature)

Updates fix_success_rates in the KB with per-fix-type and per-component
aggregates, then writes the KB back.

Outputs a ranked list of fix quality (best → worst) to stdout.
"""

import json
import sys
from pathlib import Path
from collections import defaultdict

KB_PATH = Path("/root/.hermes/error-knowledge-base.json")


def load_kb():
    if not KB_PATH.exists():
        print(f"ERROR: KB not found at {KB_PATH}", file=sys.stderr)
        sys.exit(1)
    with open(KB_PATH) as f:
        return json.load(f)


def save_kb(kb):
    tmp = KB_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(kb, f, indent=2)
    tmp.replace(KB_PATH)


def compute_rates(errors):
    """
    Walk errors[] and accumulate success/fail counts.

    Returns:
      fix_type_stats  — {fix: {success, fail, components: {component: {success, fail}}}}
      comp_stats      — {component: {success, fail}}
    """
    fix_type_stats = defaultdict(lambda: {
        "success": 0,
        "fail": 0,
        "components": defaultdict(lambda: {"success": 0, "fail": 0}),
    })
    comp_stats = defaultdict(lambda: {"success": 0, "fail": 0})

    for entry in errors:
        fix_raw = entry.get("fix", "")
        component = entry.get("component", "unknown")
        success = entry.get("success_count", 0) or 0
        fail = entry.get("fail_count", 0) or 0

        # Normalise fix label
        fix = normalise_fix(fix_raw)

        fix_type_stats[fix]["success"] += success
        fix_type_stats[fix]["fail"] += fail
        fix_type_stats[fix]["components"][component]["success"] += success
        fix_type_stats[fix]["components"][component]["fail"] += fail

        comp_stats[component]["success"] += success
        comp_stats[component]["fail"] += fail

    return fix_type_stats, comp_stats


def normalise_fix(fix_raw):
    """Coarse fix_type bucketing from free-text fix strings."""
    f = fix_raw.lower()
    if not f or f == "null" or f == "none":
        return "no_fix"
    if f.startswith("[curious]"):
        return "curiosity_monitor"
    if "investigate" in f:
        return "investigate"
    if "seo drop" in f or "seo_ranking" in f:
        return "seo_ranking_fix"
    if "docker" in f:
        return "docker_fix"
    if "retry" in f or "backoff" in f:
        return "retry_fix"
    if "exponential" in f:
        return "retry_fix"
    return fix_raw[:60]  # truncate long strings as the type


def build_rates_dict(stats_dict):
    """Convert {key: {success, fail, ...}} → {key: {success, fail, total, rate}}."""
    result = {}
    for key, data in stats_dict.items():
        success = data["success"]
        fail = data["fail"]
        total = success + fail
        rate = (success / total) if total > 0 else 0.0
        result[key] = {
            "success": success,
            "fail": fail,
            "total": total,
            "rate": round(rate, 4),
        }
    return result


def merge_into_fsr(fsr, fix_key, component, fix_data, comp_data):
    """
    Update or create fix_success_rates entries for a fix_type and component.

    fix_key is stored under the fix_type entry.
    component is stored under the component entry.
    """
    # Fix-type entry
    ft_key = f"fix_type__{fix_key}"
    if ft_key not in fsr:
        fsr[ft_key] = {"success": 0, "fail": 0, "recent_uses": []}
    fsr[ft_key]["success"] += fix_data["success"]
    fsr[ft_key]["fail"] += fix_data["fail"]

    # Component entry
    cp_key = f"component__{component}"
    if cp_key not in fsr:
        fsr[cp_key] = {"success": 0, "fail": 0, "recent_uses": []}
    fsr[cp_key]["success"] += comp_data["success"]
    fsr[cp_key]["fail"] += comp_data["fail"]


def rank_fixes(fix_rates, comp_rates):
    """
    Combine fix_type and component rates into a unified ranked list.
    Each entry: (label, rate, total, success, fail, kind)
    """
    ranked = []

    for fix, data in fix_rates.items():
        ranked.append({
            "label": fix,
            "rate": data["rate"],
            "total": data["total"],
            "success": data["success"],
            "fail": data["fail"],
            "kind": "fix_type",
        })

    for comp, data in comp_rates.items():
        ranked.append({
            "label": comp,
            "rate": data["rate"],
            "total": data["total"],
            "success": data["success"],
            "fail": data["fail"],
            "kind": "component",
        })

    # Sort: highest rate first; tie-break by total descending
    ranked.sort(key=lambda x: (x["rate"], x["total"]), reverse=True)
    return ranked


def print_ranked(ranked, top_n=30):
    header = (f"{'#':>3}  {'rate':>6}  {'total':>6}  {'ok':>5}  {'fail':>5}  "
              f"{'kind':<12}  label")
    print(header)
    print("-" * len(header))
    for i, entry in enumerate(ranked[:top_n], 1):
        print(
            f"{i:>3}  "
            f"{entry['rate']:>6.2%}  "
            f"{entry['total']:>6}  "
            f"{entry['success']:>5}  "
            f"{entry['fail']:>5}  "
            f"{entry['kind']:<12}  "
            f"{entry['label']}"
        )
    if len(ranked) > top_n:
        print(f"... ({len(ranked) - top_n} more)")


def main():
    kb = load_kb()

    errors = kb.get("errors", [])
    fsr = kb.setdefault("fix_success_rates", {})

    print(f"KB loaded: {len(errors)} errors, {len(fsr)} existing fix_success_rates entries")

    # Compute per-fix-type and per-component stats
    fix_type_stats, comp_stats = compute_rates(errors)

    # Build clean rate dicts
    fix_rates = build_rates_dict(fix_type_stats)
    comp_rates = build_rates_dict(comp_stats)

    # Update fix_success_rates in KB
    for fix_key, fix_data in fix_type_stats.items():
        for component, comp_data in fix_data["components"].items():
            merge_into_fsr(fsr, fix_key, component, fix_data, comp_data)

    # Save updated KB
    save_kb(kb)
    print(f"KB saved with {len(fsr)} fix_success_rates entries")

    # Rank and print
    ranked = rank_fixes(fix_rates, comp_rates)
    print()
    print("=== Fix Quality Ranking (by success rate) ===")
    print_ranked(ranked)


if __name__ == "__main__":
    main()
