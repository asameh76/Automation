#!/usr/bin/env python3
"""
KB Dep Changelog - Scrape dependency changelogs.
"""

import json
import urllib.request
import datetime
from pathlib import Path


CHANGELOG_DIR = Path("/root/.hermes/state/changelogs")
LOG_FILE = Path("/root/.hermes/logs/kb_dep_changelog.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


CHANGELOG_URLS = {
    "python": "https://docs.python.org/3/whatsnew/",
    "docker": "https://docs.docker.com/engine/release-notes/",
    "nginx": "https://nginx.org/en/CHANGES",
}


def fetch_url(url):
    """Fetch URL content."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        log(f"Failed to fetch {url}: {e}")
        return ""


def main():
    log("=== KB Dep Changelog started ===")

    CHANGELOG_DIR.mkdir(parents=True, exist_ok=True)

    for name, url in CHANGELOG_URLS.items():
        log(f"Fetching changelog for {name}...")
        content = fetch_url(url)
        if content:
            out_file = CHANGELOG_DIR / f"{name}_changelog.txt"
            with open(out_file, "w") as fh:
                fh.write(content[:50000])
            log(f"Saved {name} changelog ({len(content)} bytes)")

    log("=== KB Dep Changelog finished ===")


if __name__ == "__main__":
    main()
