#!/usr/bin/env python3
"""
KB Fix Rollback — undo a verified fix if it caused new problems.
Stores rollback snapshots before applying fixes.
"""
import json, sys, shutil, os
from datetime import datetime
from pathlib import Path

KB_PATH = "/root/.hermes/error-knowledge-base.json"
SNAPSHOT_DIR = Path("/root/.hermes/snapshots")
ROLLBACK_LOG = Path("/root/.hermes/state/kb_rollback_log.json")


def read_kb():
    with open(KB_PATH) as f:
        return json.load(f)


def write_kb(kb):
    with open(KB_PATH, "w") as f:
        json.dump(kb, f, indent=2)


def create_snapshot(reason="pre-rollback"):
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    snap_file = SNAPSHOT_DIR / f"kb_{ts}_{reason}.json"
    shutil.copy2(KB_PATH, snap_file)
    return snap_file


def log_rollback(entry_id, fix_applied, reason, snapshot_file):
    log_file = ROLLBACK_LOG
    if log_file.exists():
        with open(log_file) as f:
            log = json.load(f)
    else:
        log = {"rollbacks": []}

    log["rollbacks"].append({
        "timestamp": datetime.now().isoformat(),
        "entry_id": entry_id,
        "fix_undone": fix_applied,
        "reason": reason,
        "snapshot": str(snapshot_file),
    })
    log_file.parent.mkdir(parents=True, exist_ok=True)
    with open(log_file, "w") as f:
        json.dump(log, f, indent=2)


def find_rollback_entry(entry_id):
    kb = read_kb()
    for err in kb.get("errors", []):
        if err.get("id") == entry_id or err.get("signature", "").startswith(entry_id[:30]):
            return err, kb
    return None, kb


def apply_rollback(entry_id):
    kb = read_kb()
    entry = None
    for err in kb.get("errors", []):
        if err.get("id") == entry_id or err.get("signature", "").startswith(entry_id[:30]):
            entry = err
            break

    if not entry:
        print(f"Entry not found: {entry_id}")
        return False

    fix = entry.get("fix_applied", "")
    if not fix:
        print("No fix was applied to this entry — nothing to rollback.")
        return False

    # Create snapshot before rollback
    snap = create_snapshot(reason=f"rollback_{entry_id[:20]}")

    # Reset entry fields
    entry["status"] = "rollback"
    entry["fix_applied"] = None
    entry["fix_type"] = "rollback"
    entry["verified"] = False
    entry["last_rollback"] = datetime.now().isoformat()
    entry["rollback_reason"] = "manual"

    write_kb(kb)
    log_rollback(entry_id, fix, "manual", snap)
    print(f"Rolled back: {entry_id}")
    print(f"  Fix removed: {fix[:80]}")
    print(f"  Snapshot: {snap}")
    return True


def main():
    if len(sys.argv) < 2:
        print("Usage: kb_fix_rollback.py <entry_id>")
        print("  Lists latest applied fixes, then rolls back selected one.")
        print("  Run without args to list recent applied fixes.")
        kb = read_kb()
        print("\nRecent applied fixes:")
        count = 0
        for err in kb.get("errors", []):
            fix = err.get("fix_applied")
            if fix and count < 10:
                print(f"  [{err.get('id', err.get('signature','')[:30])}] {fix[:70]}")
                count += 1
        return

    entry_id = sys.argv[1]
    reason = sys.argv[2] if len(sys.argv) > 2 else "manual"
    apply_rollback(entry_id)


if __name__ == "__main__":
    main()
