#!/usr/bin/env python3
"""
Improvement Evaluator — Week-over-week delta tracking.
Measures: KB growth, fix rate, health change, new capabilities added.
Writes to improvement_history.json for trend analysis.
"""
import json, subprocess, os, sys
from pathlib import Path
from datetime import datetime, timedelta

HERMES      = Path("/root/.hermes")
KB_FILE     = HERMES / "error-knowledge-base.json"
STATE_DIR   = HERMES / "state"
HIST_FILE   = STATE_DIR / "improvement_history.json"
LOG_FILE    = HERMES / "logs/improvement_eval.log"

def log(msg):
    print(f"[IMPROVE {datetime.now().strftime('%H:%M:%S')}] {msg}")

def load_json(path):
    try:
        return json.load(open(path))
    except:
        return {}

def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)

def kb_snapshot():
    kb = load_json(KB_FILE)
    errors = kb.get("errors", [])
    v_types = ['verified','manual_verified','canary_verified','cross_verified','self_healed']
    total    = len(errors)
    verified = sum(1 for e in errors if e.get("verified") in v_types)
    auto_fix = sum(1 for e in errors if e.get("auto_fixed") in [True, "true"])
    health   = round(verified * 100 / max(total, 1), 1)

    # Count by component
    components = {}
    for e in errors:
        comp = e.get("component", "unknown")
        components[comp] = components.get(comp, 0) + 1

    return {
        "total":    total,
        "verified": verified,
        "auto_fix": auto_fix,
        "health":   health,
        "components": components,
    }

def cron_snapshot():
    """Count active cron jobs."""
    jobs_data = load_json(STATE_DIR / "cron_state.json")
    if not jobs_data:
        return {"active": 0, "total": 0}
    jobs = jobs_data.get("jobs", [])
    active = sum(1 for j in jobs if j.get("enabled") and not j.get("paused_at"))
    return {"active": active, "total": len(jobs)}

def audit_snapshot():
    state = load_json(STATE_DIR / "kb_self_audit_state.json")
    runs  = state.get("runs", [])
    if not runs:
        return {}
    last = runs[-1]
    # Count gaps found vs fixed across all runs
    gaps_found  = sum(r.get("gaps", 0) for r in runs[-7:])   # last 7 runs
    gaps_fixed  = sum(r.get("fixed", 0) for r in runs[-7:])
    return {
        "gaps_found_7d":  gaps_found,
        "gaps_fixed_7d": gaps_fixed,
        "fix_rate":      round(gaps_fixed / max(gaps_found, 1) * 100, 1),
        "last_run":      last.get("ts", ""),
    }

def gemgyms_health():
    r = subprocess.run(
        "curl -s -o /dev/null -w '%{http_code}' https://gemgyms.com --max-time 8 --fail 2>/dev/null || echo '---'",
        shell=True, capture_output=True, text=True
    )
    return r.stdout.strip()

def compute_delta(prev, curr):
    """Compute week-over-week delta."""
    delta = {}
    for key in curr:
        if isinstance(curr[key], (int, float)) and key in prev:
            delta[key] = round(curr[key] - prev[key], 2)
            delta[f"{key}_direction"] = "up" if delta[key] > 0 else "down" if delta[key] < 0 else "same"
    return delta

def main():
    log("=== Improvement Evaluator START ===")

    history = load_json(HIST_FILE)
    history.setdefault("snapshots", [])

    curr = {
        "ts":         datetime.now().isoformat(),
        "kb":         kb_snapshot(),
        "crons":      cron_snapshot(),
        "audit":      audit_snapshot(),
        "gemgyms":    gemgyms_health(),
    }

    # Delta vs previous snapshot
    prev_snap = history["snapshots"][-1] if history["snapshots"] else {}
    delta = {}
    if prev_snap:
        delta = compute_delta(prev_snap.get("kb", {}), curr["kb"])
        delta.update(compute_delta(prev_snap.get("audit", {}), curr["audit"]))

    curr["delta"] = delta
    history["snapshots"].append(curr)
    history["snapshots"] = history["snapshots"][-52:]   # keep 1 year of weekly
    history["last_update"] = datetime.now().isoformat()

    with open(HIST_FILE, "w") as f:
        json.dump(history, f, indent=2, default=str)

    # Summary printout
    print()
    print("=" * 55)
    print("  📈 IMPROVEMENT EVALUATION — this week vs last")
    print("=" * 55)

    kb = curr["kb"]
    prev_kb = prev_snap.get("kb", {}) if prev_snap else {}
    d = delta

    print(f"  KB Entries:       {kb['total']} ({('+' if d.get('total',0)>0 else '')}{d.get('total','0')})")
    print(f"  Verified:         {kb['verified']} ({('+' if d.get('verified',0)>0 else '')}{d.get('verified','0')})")
    print(f"  Health %:         {kb['health']}% ({('+' if d.get('health',0)>0 else '')}{d.get('health','0')})")
    print(f"  Auto-fixes:       {kb['auto_fix']} ({('+' if d.get('auto_fix',0)>0 else '')}{d.get('auto_fix','0')})")
    print(f"  Crons active:     {curr['crons']['active']}/{curr['crons']['total']}")
    print(f"  gemgyms.com:      HTTP {curr['gemgyms']}")

    audit = curr.get("audit", {})
    if audit:
        print(f"  Audit fix rate:   {audit.get('fix_rate','?')}% ({audit.get('gaps_fixed_7d','?')}/{audit.get('gaps_found_7d','?')})")

    if prev_snap:
        print()
        print("  Summary:", end=" ")
        if d.get("health_direction") == "up":
            print("✅ KB HEALTH IMPROVED")
        elif d.get("health_direction") == "down":
            print("⚠️  KB HEALTH DROPPED")
        else:
            print("➡️  KB HEALTH STABLE")
    print("=" * 55)

    log("=== Improvement Evaluator END ===")

if __name__ == "__main__":
    main()
