#!/usr/bin/env python3
"""
KB Consolidate — Merge errors[] and knowledge_base[] into a single canonical array.
Deduplicates by signature. Sets verified status correctly.
Run this once; it's idempotent.
"""
import json, fcntl
from pathlib import Path
from datetime import datetime

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_consolidate.log")
STATE_FILE = Path("/root/.hermes/state/kb_consolidate.json")

V_TYPES = {'verified','manual_verified','canary_verified','cross_verified','self_healed'}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[CONSOLIDATE {ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def read_kb():
    with open(KB_FILE) as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(f)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def write_kb(kb):
    with open(KB_FILE, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, f, indent=2, default=str)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def main():
    log("=== KB Consolidate START ===")
    kb = read_kb()

    errors_arr   = kb.get("errors", [])
    kb_arr       = kb.get("knowledge_base", [])

    log(f"  errors[]:        {len(errors_arr)} entries")
    log(f"  knowledge_base[]:{len(kb_arr)} entries")

    # Index existing by signature
    by_sig = {}
    for e in kb_arr:
        sig = e.get("signature","")
        if sig:
            by_sig[sig] = e

    # Merge from errors[] — newer/winner for duplicates
    merged_count = 0
    for e in errors_arr:
        sig = e.get("signature","")
        if not sig:
            continue
        if sig in by_sig:
            # Keep the one with higher verification status
            existing = by_sig[sig]
            e_v = e.get("verified","")
            x_v = existing.get("verified","")
            # Prefer the more-verified one
            if e_v in V_TYPES and x_v not in V_TYPES:
                by_sig[sig] = e
                merged_count += 1
            elif e_v not in V_TYPES and x_v in V_TYPES:
                pass  # keep existing
            else:
                # Same status — prefer the one with more fields
                if len(e) > len(existing):
                    by_sig[sig] = e
        else:
            by_sig[sig] = e
            merged_count += 1

    canonical = list(by_sig.values())

    # Update canonical "verified" field for consistent reporting
    for e in canonical:
        if e.get("verified") in V_TYPES:
            e["verified"] = "true"
        elif e.get("verified") == "false":
            pass
        # Normalize success_count
        if isinstance(e.get("success_count"), str):
            try:
                e["success_count"] = int(e["success_count"])
            except:
                e["success_count"] = 0

    # Write back
    kb["knowledge_base"] = canonical
    kb["errors"]         = canonical   # keep both in sync
    kb["updated"]        = datetime.now().isoformat()

    write_kb(kb)

    verified = sum(1 for e in canonical if e.get("verified") in V_TYPES)
    log(f"  Merged:          {merged_count} new/changed entries")
    log(f"  Canonical KB:    {len(canonical)} total, {verified} verified")

    # Stats
    state = {
        "timestamp": datetime.now().isoformat(),
        "total": len(canonical),
        "verified": verified,
        "health_pct": round(verified * 100 / max(len(canonical), 1), 1),
        "merged": merged_count,
        "source_errors": len(errors_arr),
        "source_kb": len(kb_arr),
    }
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)

    log("=== KB Consolidate DONE ===")
    print()
    print(f"  ✅ KB consolidated: {len(canonical)} entries, {verified} verified ({state['health_pct']}% health)")

if __name__ == "__main__":
    main()
