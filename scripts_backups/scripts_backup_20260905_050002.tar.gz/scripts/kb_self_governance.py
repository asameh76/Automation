#!/usr/bin/env python3
"""
KB Self-Governance — defines and enforces safety boundaries for autonomous actions.
What the system can do without asking vs what requires human approval.
"""
import json, sys
from datetime import datetime
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
POLICY_FILE = Path("/root/.hermes/state/kb_governance_policy.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_governance.log")
STATE_FILE = Path("/root/.hermes/state/kb_self_governance.json")

# ─── Policy Definition ───────────────────────────────────────────────────────

POLICY = {
    "version": "1.0",
    "last_updated": datetime.now().isoformat(),

    # Actions the system can take WITHOUT asking
    "autonomous_actions": [
        "read_logs",
        "write_kb",
        "run_kb_scripts",
        "apply_verified_fix",
        "research_error",
        "deduplicate_kb",
        "auto_tag_entries",
        "prune_stale_entries",
        "generate_synthetic_entry",
        "verify_fix",
        "predict_failure",
        "evolve_kb_entry",
        "register_cron",
        "create_systemd_unit",
        "send_telegram_message",
        "run_health_check",
        "backup_kb",
        "generate_new_script",
        "apply_script_fix",
    ],

    # Actions that REQUIRE human approval first
    "approval_required": [
        "delete_any_file",
        "remove_cron",
        "disable_service",
        "stop_docker_container",
        "modify_dns",
        "change_cloudflare_settings",
        "modify_firewall",
        "reset_password",
        "access_other_users_data",
        "make_network_request_external",
        "spend_credits",
        "delete_kb_entry",
        "modify_kb_governance_policy",
    ],

    # Risk thresholds
    "risk_thresholds": {
        "max_fix_attempts_per_error": 5,
        "max_scripts_generated_per_hour": 10,
        "max_kb_size_growth_mb_per_day": 100,
        "max_concurrent_self_modifications": 3,
        "confidence_threshold_for_autofix": 0.85,
        "confidence_threshold_for_autofix_critical": 0.95,
    },

    # Critical components — do not modify without explicit approval
    "critical_paths": [
        "/etc/systemd/system/",
        "/etc/passwd",
        "/etc/shadow",
        "/root/.ssh/",
        "/root/.hermes/auth/",
        "/root/.hermes/config.yaml",
    ],

    # Allowed telegram chat IDs for sending messages
    "allowed_telegram_chats": ["864983959"],  # Ahmed Sameh's Telegram ID
}


# ─── Core Logic ───────────────────────────────────────────────────────────────

def read_policy():
    if POLICY_FILE.exists():
        with open(POLICY_FILE) as f:
            return json.load(f)
    return dict(POLICY)


def write_policy(policy):
    POLICY_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(POLICY_FILE, "w") as f:
        json.dump(policy, f, indent=2)


def check_action(action, params=None):
    """
    Check if an action is allowed autonomously or needs approval.
    Returns: (allowed: bool, reason: str, approval_type: str)
    """
    policy = read_policy()

    if action in policy.get("approval_required", []):
        return False, f"'{action}' requires explicit human approval", "approval_required"

    if action in policy.get("autonomous_actions", []):
        return True, f"'{action}' is autonomous", "autonomous"

    # Unknown action — default to asking
    return False, f"Unknown action '{action}' — defaulting to approval required", "unknown"


def check_critical_path(path):
    """Check if a path is critical and should not be modified."""
    policy = read_policy()
    for crit in policy.get("critical_paths", []):
        if path.startswith(crit):
            return False, f"Path '{path}' is critical — requires approval", "critical_path"
    return True, "Path OK", "safe"


def enforce_risk_limits(action_type):
    """Check if action would breach risk thresholds."""
    policy = read_policy()
    state_file = STATE_FILE

    if state_file.exists():
        state = json.loads(state_file.read_text())
    else:
        state = {"action_counts": {}, "timestamps": []}

    limits = policy.get("risk_thresholds", {})
    now = datetime.now()

    # Clean old timestamps (last hour)
    cutoff = now.timestamp() - 3600
    state["timestamps"] = [ts for ts in state.get("timestamps", [])
                          if float(ts) > cutoff]

    # Check per-action limits
    if action_type == "generate_script":
        limit = limits.get("max_scripts_generated_per_hour", 10)
        count = sum(1 for ts in state["timestamps"] if "generate_script" in str(ts))
        if count >= limit:
            return False, f"Script generation limit reached ({limit}/hour)", "risk_limit"

    state["timestamps"].append(now.timestamp())
    state["action_counts"][action_type] = state["action_counts"].get(action_type, 0) + 1

    state_file.parent.mkdir(parents=True, exist_ok=True)
    with open(state_file, "w") as f:
        json.dump(state, f, indent=2)

    return True, "Within limits", "ok"


def log_decision(action, params, allowed, reason):
    """Log governance decisions for audit trail."""
    entry = {
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "params": str(params)[:200] if params else None,
        "allowed": allowed,
        "reason": reason,
    }
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")


def request_approval(action, params, reason):
    """Send approval request to user via Telegram."""
    try:
        import subprocess
        msg = f"🔒 *Governance Approval Required*\n\n`{action}`\nReason: {reason}\n\nParams: {str(params)[:200] if params else 'None'}\n\nReply with `approve {action}` or `deny {action}`"
        subprocess.run(
            ["python3", "-c",
             f"from hermes_tools import send_message; send_message('{msg}')"],
            capture_output=True, timeout=10
        )
    except:
        pass


def main():
    if len(sys.argv) < 2:
        # Run governance check on all active mechanisms
        policy = read_policy()
        print(f"Governance Policy v{policy.get('version','?')} — {len(policy.get('autonomous_actions',[]))} autonomous, {len(policy.get('approval_required',[]))} requires approval")
        print(f"\nAutonomous actions ({len(policy['autonomous_actions'])}):")
        for a in policy["autonomous_actions"]:
            print(f"  ✅ {a}")
        print(f"\nApproval required ({len(policy['approval_required'])}):")
        for a in policy["approval_required"]:
            print(f"  🔒 {a}")
        print(f"\nRisk limits:")
        for k, v in policy.get("risk_thresholds", {}).items():
            print(f"  {k}: {v}")
        return

    action = sys.argv[1]
    params = sys.argv[2] if len(sys.argv) > 2 else None

    allowed, reason, flag = check_action(action, params)

    if not allowed:
        if flag in ("approval_required", "unknown"):
            request_approval(action, params, reason)
            print(f"BLOCKED: {reason} — approval requested")
        else:
            print(f"DENIED: {reason}")
        sys.exit(1)

    ok, reason, flag = enforce_risk_limits(action)
    if not ok:
        print(f"RISK LIMIT: {reason}")
        sys.exit(1)

    log_decision(action, params, allowed, reason)
    print(f"APPROVED: {action} — {reason}")


if __name__ == "__main__":
    main()
