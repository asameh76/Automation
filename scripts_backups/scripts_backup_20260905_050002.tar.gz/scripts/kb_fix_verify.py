#!/usr/bin/env python3
"""
KB Fix Verify - Auto-verify KB fixes by running them safely (dry-run or sandbox),
then update KB entries with verified=true/false.

Workflow:
  1. Read KB entries in 'investigate' status with applied fixes
  2. Classify each fix by type (shell, python, api, docker, etc.)
  3. Run safe verification (dry-run / sandbox) for each fix type
  4. Set verified=true on the fix if verification passes, verified=false if it fails
  5. Promote entry to 'verified' status when all its fixes are verified
  6. Write updated KB back
"""

import json
import subprocess
import datetime
import fcntl
import tempfile
import os
import re
from pathlib import Path

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE = Path("/root/.hermes/state/kb_fix_verify.json")
LOG_FILE = Path("/root/.hermes/logs/kb_fix_verify.log")

# Shell commands considered safe for dry-run / sandbox verification
SAFE_DRY_COMMANDS = {
    "docker": ["ps", "images", "inspect", "logs", "stats"],
    "systemctl": ["status", "show"],
    "nginx": ["-t", "-T"],
    "curl": [],  # safe read-only commands
    "git": ["status", "diff", "log", "show"],
    "ls": [], "cat": [], "head": [], "tail": [], "grep": [], "rg": [],
    "find": [], "stat": [], "wc": [], "du": [], "df": [],
    "ps": [], "top": [], "free": [], "uptime": [],
    "ping": [], "nslookup": [], "dig": [],
    "netstat": [], "ss": [], "ip": [],
}

# Commands that are NEVER safe to run even in dry-run
BLOCKED_COMMANDS = {
    "rm", "dd", "mkfs", "fdisk", "parted",
    "shutdown", "reboot", "init", "poweroff",
    ">:", ">|", "tee",
}

SANDBOX_TIMEOUT = 10  # seconds


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


# ── Command safety ────────────────────────────────────────────────────────────

def _base_cmd(cmd):
    """Return the leading binary name from a command list."""
    if not cmd:
        return ""
    return os.path.basename(str(cmd[0]))


def is_dangerous(cmd):
    """Return True if any part of cmd is a known destructive operation."""
    if not cmd:
        return True
    flat = " ".join(str(c) for c in cmd)
    for blocked in BLOCKED_COMMANDS:
        if re.search(r'\b' + blocked + r'\b', flat):
            return True
    return False


def is_safe_readonly(cmd):
    """Return True if the command is a known safe/read-only operation."""
    base = _base_cmd(cmd)
    return base in SAFE_DRY_COMMANDS


def build_dry_run(cmd):
    """
    Given a real command list, build the equivalent dry-run / safe version.
    Returns (dry_cmd, explanation) or (None, None) if not reducible.
    """
    if not cmd:
        return None, None
    base = _base_cmd(cmd)

    if base in ("docker",):
        sub = cmd[1] if len(cmd) > 1 else ""
        if sub in ("restart", "stop", "start", "rm", "prune"):
            return None, None  # skip dangerous docker ops
        # docker inspect / logs / stats are read-only
        return cmd[:2] + ["--format", "{{.Status}}"], f"docker {sub} (readonly)"

    if base in ("systemctl",):
        sub = cmd[1] if len(cmd) > 1 else ""
        if sub in ("start", "stop", "restart", "enable", "disable", "kill"):
            return None, None
        return cmd[:2], f"systemctl {sub} (readonly)"

    if base in ("nginx",):
        return ["nginx", "-t"], "nginx -t (config test)"

    if base in SAFE_DRY_COMMANDS:
        return cmd, f"{base} (readonly)"

    return None, None


# ── Verification engines ─────────────────────────────────────────────────────

def verify_shell(cmd, env_override=None):
    """Run a shell command in dry-run / sandbox mode. Returns (pass, detail)."""
    if is_dangerous(cmd):
        return False, "command is blocked/destructive"

    dry_cmd, info = build_dry_run(cmd)
    if dry_cmd is None:
        return False, f"no safe dry-run available for {info}"

    env = os.environ.copy()
    if env_override:
        env.update(env_override)

    try:
        result = subprocess.run(
            dry_cmd,
            capture_output=True,
            text=True,
            timeout=SANDBOX_TIMEOUT,
            env=env,
            shell=False,
        )
        if result.returncode == 0:
            out = result.stdout.strip()[:200] if result.stdout else "(no output)"
            return True, f"PASS {info}: {out}"
        else:
            err = result.stderr.strip()[:200] if result.stderr else "(no stderr)"
            return False, f"FAIL {info}: exit {result.returncode} — {err}"
    except subprocess.TimeoutExpired:
        return False, f"TIMEOUT after {SANDBOX_TIMEOUT}s"
    except Exception as e:
        return False, f"ERROR: {e}"


def verify_python(code_snippet):
    """Syntax-check a Python snippet in isolation. Returns (pass, detail)."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False
    ) as f:
        f.write(code_snippet)
        tmp = f.name
    try:
        result = subprocess.run(
            ["python3", "-m", "py_compile", tmp],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            return True, "PASS python syntax check"
        else:
            return False, f"FAIL python syntax: {result.stderr.strip()[:150]}"
    except Exception as e:
        return False, f"ERROR: {e}"
    finally:
        os.unlink(tmp)


def verify_api_call(url, method="GET", headers=None):
    """Dry-run an HTTP API call (actually run it against the URL). Returns (pass, detail)."""
    cmd = ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "-X", method]
    if headers:
        for k, v in headers.items():
            cmd += ["-H", f"{k}: {v}"]
    cmd.append(url)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        code = result.stdout.strip()
        try:
            code_int = int(code)
        except ValueError:
            return False, f"unexpected curl output: {code}"
        # 2xx and 3xx are acceptable
        if 200 <= code_int < 400:
            return True, f"PASS HTTP {method} {url} → {code}"
        else:
            return False, f"FAIL HTTP {method} {url} → {code}"
    except subprocess.TimeoutExpired:
        return False, "TIMEOUT"
    except Exception as e:
        return False, f"ERROR: {e}"


# ── Per-fix verification ─────────────────────────────────────────────────────

def verify_fix(fix):
    """
    Verify a single fix object.
    Returns (verified: bool, detail: str).
    Fix objects look like:
      { "action": { "type": "shell|python|api|...", "command": [...] }, ... }
    """
    action = fix.get("action", {})
    fix_type = action.get("type", "shell")
    cmd = action.get("command", [])

    if fix_type == "shell":
        if not cmd:
            return False, "no command in shell action"
        return verify_shell(cmd)

    elif fix_type == "python":
        code = action.get("code", "")
        if not code:
            return False, "no code in python action"
        return verify_python(code)

    elif fix_type == "api":
        url = action.get("url", "")
        method = action.get("method", "GET")
        headers = action.get("headers", {})
        if not url:
            return False, "no url in api action"
        return verify_api_call(url, method, headers)

    else:
        return False, f"unknown fix type: {fix_type}"


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    log("=== KB Fix Verify started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])
    stats = {
        "entries_checked": 0,
        "fixes_verified": 0,
        "fixes_passed": 0,
        "fixes_failed": 0,
        "entries_promoted": 0,
        "skipped_no_fixes": 0,
        "skipped_dangerous": 0,
    }
    verified_entries = []

    for entry in entries:
        # Only process investigate entries that have applied fixes
        if entry.get("status") != "investigate":
            continue
        fixes = entry.get("fixes", [])
        applied_fixes = [f for f in fixes if f.get("applied") is True]
        if not applied_fixes:
            stats["skipped_no_fixes"] += 1
            continue

        stats["entries_checked"] += 1
        entry_changed = False

        for fix in fixes:
            if fix.get("verified") is not None:
                # already verified, skip
                continue
            if not fix.get("applied"):
                continue

            # Danger-check the action before attempting any run
            action = fix.get("action", {})
            cmd = action.get("command", [])
            if cmd and is_dangerous(cmd):
                fix["verified"] = False
                fix["verified_at"] = datetime.datetime.now().isoformat()
                fix["verification_detail"] = "blocked: destructive command"
                stats["skipped_dangerous"] += 1
                entry_changed = True
                continue

            verified, detail = verify_fix(fix)
            fix["verified"] = verified
            fix["verified_at"] = datetime.datetime.now().isoformat()
            fix["verification_detail"] = detail
            stats["fixes_verified"] += 1
            if verified:
                stats["fixes_passed"] += 1
            else:
                stats["fixes_failed"] += 1
            entry_changed = True
            log(f"  fix [{entry.get('error','')[:40]}] → {detail[:100]}")

        # Promote entry to verified if ALL its applied fixes are verified=true
        if entry_changed:
            still_investigate = [
                f for f in fixes
                if f.get("applied") and f.get("verified") is not True
            ]
            if not still_investigate:
                entry["status"] = "verified"
                entry["verified_at"] = datetime.datetime.now().isoformat()
                stats["entries_promoted"] += 1
                log(f"Promoted: {entry.get('error','')[:60]}")

        if entry_changed:
            verified_entries.append(entry.get("error", ""))

    if stats["entries_checked"] > 0 or stats["skipped_no_fixes"] > 0:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        **stats,
    }
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Fix Verify: "
        f"checked={stats['entries_checked']} "
        f"verified={stats['fixes_verified']} "
        f"passed={stats['fixes_passed']} "
        f"failed={stats['fixes_failed']} "
        f"promoted={stats['entries_promoted']} ===")


if __name__ == "__main__":
    main()
