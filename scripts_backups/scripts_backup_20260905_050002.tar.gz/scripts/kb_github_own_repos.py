#!/usr/bin/env python3
"""
KB GitHub Own-Repo Monitor — scrapes Ahmed's actual repos for issues, PRs,
and CI failures to learn from his own project's errors.
Repos: asameh76/Automation, asameh76/Gersy-Hermes

Fetches via GitHub public REST API (no auth needed for public repos,
rate-limited to 60/hr — fine for this use case).
"""
import json, urllib.request, urllib.parse, re, os
from pathlib import Path
from datetime import datetime

KB_FILE   = Path("/root/.hermes/error-knowledge-base.json")
STATE_FILE = Path("/root/.hermes/state/kb_github_own_repos.json")
LOG_FILE  = Path("/root/.hermes/logs/kb_github_own_repos.log")

OWN_REPOS = [
    {"owner": "asameh76", "repo": "Automation"},
    {"owner": "asameh76", "repo": "Gersy-Hermes"},
]

V_TYPES = {'verified','manual_verified','canary_verified','cross_verified','self_healed'}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[GH-REPO {ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def read_kb():
    try:
        return json.load(open(KB_FILE))
    except:
        return {"errors": []}

def write_kb(kb):
    with open(KB_FILE, "w") as f:
        json.dump(kb, f, indent=2, default=str)

def read_state():
    try:
        return json.load(open(STATE_FILE))
    except:
        return {"last_run": None, "last_issue_ids": {}}

def write_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)

def gh_fetch(url):
    """Fetch a GitHub API URL. Returns (data, status_code)."""
    try:
        req = urllib.request.Request(url, headers={
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "Hermes-KB-Agent"
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read()), resp.getcode()
    except urllib.error.HTTPError as e:
        return None, e.code
    except Exception as e:
        log(f"Fetch error: {e}")
        return None, 0

def fetch_issues(owner, repo, state="all", per_page=30):
    """Fetch issues/PRs from a repo."""
    q = urllib.parse.quote(f"repo:{owner}/{repo} is:issue")
    url = f"https://api.github.com/search/issues?q={q}&state={state}&per_page={per_page}"
    data, code = gh_fetch(url)
    if data:
        return data.get("items", [])
    return []

def fetch_workflow_runs(owner, repo):
    """Fetch recent workflow runs."""
    url = f"https://api.github.com/repos/{owner}/{repo}/actions/runs?per_page=20"
    data, code = gh_fetch(url)
    if data:
        return data.get("workflow_runs", [])
    return []

def extract_labels(issue):
    return [l.get("name","") for l in issue.get("labels", [])]

def extract_fix_from_issue(issue):
    """Pull potential fix/solution from issue body."""
    body = issue.get("body", "") or ""
    lines = body.split("\n")[:30]

    # Look for structured fix sections
    for pattern in [
        r"(?i)^###?\s*fix[:\s]*(.+)$",
        r"(?i)^###?\s*solution[:\s]*(.+)$",
        r"(?i)^###?\s*resolution[:\s]*(.+)$",
        r"(?i)^###?\s*how to reproduce[:\s]*(.+)$",
        r"(?i)^\*\*fix:\*\* (.+)$",
        r"(?i)^\*\*solution:\*\* (.+)$",
        r"(?i)^-\s+([a-z].+\.(py|sh|js|ts|go|rb)$)",  # code snippet as fix
    ]:
        for line in lines:
            m = re.search(pattern, line.strip())
            if m:
                return m.group(1).strip()[:120]

    # Fallback: look for stack traces (useful for error matching)
    stack_pattern = re.compile(r"^\s+at\s+(\S+)\s+\(([^:]+):(\d+)\)")
    stacks = []
    for line in lines:
        m = stack_pattern.match(line)
        if m:
            stacks.append(f"{m.group(2)}:{m.group(3)} {m.group(1)}")
    if stacks:
        return f"Stack trace: {stacks[0][:80]}"

    return None

def workflow_failures_to_entries(owner, repo, runs):
    """Convert failed workflow runs into KB entries."""
    entries = []
    for run in runs:
        if run.get("conclusion") != "failure":
            continue
        name = run.get("name", "")
        branch = run.get("head_branch", "")
        html_url = run.get("html_url", "")
        created = run.get("created_at", "")[:10]
        # Get failure reason from jobs
        jobs_url = run.get("jobs_url", "")
        if jobs_url:
            jobs_data, _ = gh_fetch(jobs_url)
            if jobs_data:
                for job in jobs_data.get("jobs", []):
                    if job.get("conclusion") == "failure":
                        failures = job.get("failure_reason", "") or ""
                        title = job.get("name", "")
                        entries.append({
                            "signature": f"github_ci_failure_{owner}_{repo}_{run.get('id','')}",
                            "error": f"CI failure: {name} / {title} on {branch}",
                            "component": "github_ci",
                            "fix": f"Check workflow run: {html_url}",
                            "fix_type": "investigate",
                            "source": f"github:{owner}/{repo}",
                            "correlation_confidence": "medium",
                            "tech_stack": "github_actions",
                            "first_seen": created,
                            "last_seen": created,
                            "occurrence_count": 1,
                            "auto_fixed": "false",
                            "success_count": 0,
                            "fail_count": 0,
                        })
    return entries

def main():
    log("=== GitHub Own-Repo Monitor START ===")
    kb    = read_kb()
    state = read_state()
    last_ids = state.get("last_issue_ids", {})

    existing_sigs = {e.get("signature","") for e in kb.get("errors", [])}
    new_entries = 0

    for repo_info in OWN_REPOS:
        owner = repo_info["owner"]
        repo  = repo_info["repo"]
        key   = f"{owner}/{repo}"
        log(f"  Scanning {key}...")

        # 1. Fetch recent closed issues (resolved bugs)
        issues = fetch_issues(owner, repo, state="closed", per_page=30)
        log(f"    {len(issues)} closed issues")

        for issue in issues:
            iid  = issue.get("id")
            num  = issue.get("number")
            title = issue.get("title","")
            html_url = issue.get("html_url","")
            created  = issue.get("created_at","")[:10]
            labels   = extract_labels(issue)

            # Skip non-bug issues
            if not any(l in labels for l in ["bug","fix","error","failure","breaking"]):
                # Also skip if title doesn't look like a problem
                if not any(x in title.lower() for x in ["error","fail","bug","fix","broken","wrong","issue"]):
                    continue

            sig = f"github_issue_{owner}_{repo}_{num}"
            if sig in existing_sigs:
                continue

            fix = extract_fix_from_issue(issue)
            kb_entry = {
                "signature": sig,
                "error": title[:120],
                "component": "github_issue",
                "fix": fix or "Investigate this resolved issue for applicable fix",
                "fix_type": "hypothesis",
                "source": f"github:{owner}/{repo}#{num}",
                "correlation_confidence": "medium" if fix else "low",
                "tech_stack": "github",
                "first_seen": created,
                "last_seen": datetime.now().strftime("%Y-%m-%d"),
                "occurrence_count": 1,
                "auto_fixed": "false",
                "success_count": 0,
                "fail_count": 0,
                "url": html_url,
                "labels": labels,
                "verified": "false",
            }
            kb["errors"].append(kb_entry)
            existing_sigs.add(sig)
            new_entries += 1
            log(f"    + New issue KB entry: {title[:60]}")

        # 2. Fetch failed CI runs
        runs = fetch_workflow_runs(owner, repo)
        for entry in workflow_failures_to_entries(owner, repo, runs):
            if entry["signature"] not in existing_sigs:
                kb["errors"].append(entry)
                existing_sigs.add(entry["signature"])
                new_entries += 1
                log(f"    + CI failure: {entry['error'][:60]}")

    kb["updated"] = datetime.now().isoformat()
    write_kb(kb)

    state["last_run"] = datetime.now().isoformat()
    write_state(state)

    log(f"=== GitHub Own-Repo Monitor END: {new_entries} new KB entries ===")
    print(f"  ✅ {new_entries} new entries from GitHub repos")

if __name__ == "__main__":
    main()
