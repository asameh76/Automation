#!/usr/bin/env python3
"""Kanban tracker for Hermes evolution ops — shows what's real vs removed."""
import json
from pathlib import Path
from datetime import datetime

# Operational ideas — backed by real, running scripts
OPERATIONAL = [
    # Core
    {"id": 2,  "name": "Cron job scheduling",            "script": "hermes cron",                           "note": "Native — 17 active jobs"},
    {"id": 16, "name": "Performance benchmarking",        "script": "system-health-check.py",                "note": "Disk/mem/health cron"},
    {"id": 18, "name": "SLA monitoring",                "script": "system-health-check.py",                "note": "Disk/mem/health cron"},
    {"id": 19, "name": "Certificate expiry monitoring",  "script": "gateway-watchdog.sh",                   "note": "Active cron"},
    {"id": 21, "name": "Log aggregation",               "script": "anomaly-daemon.py",                     "note": "9 sources, event-bus"},
    {"id": 22, "name": "Alert fatigue reduction",       "script": "anomaly-daemon.py",                     "note": "SPIKE_THRESHOLD, dedup"},
    {"id": 24, "name": "Natural language interface",    "script": "Hermes core",                           "note": "Native"},
    {"id": 27, "name": "Self-documenting code",         "script": "system-health-check.py",                "note": "Health report output"},
    {"id": 36, "name": "Make.com + RSS automation",     "script": "daily-article.py",                      "note": "Active cron (2x)"},
    # Advanced
    {"id": 28, "name": "Recursive self-improvement",     "script": "evolution-engine.py",                  "note": "op_autogenesis"},
    {"id": 30, "name": "Meta-learning",                 "script": "evolution-engine.py",                  "note": "op_meta_learning"},
    {"id": 31, "name": "Evolutionary search",           "script": "evolution-engine.py",                  "note": "op_fix_drift_detector (replaced)"},
    {"id": 35, "name": "Kanban agent",                  "script": "kanban-ideas.py",                       "note": "This file"},
    # Enhancement
    {"id": 7,  "name": "Anomaly detection",             "script": "anomaly-daemon.py",                     "note": "SPIKE_THRESHOLD, ERROR_WINDOW"},
    {"id": 10, "name": "Self-healing scripts",         "script": "anomaly-daemon.py",                     "note": "DAEMON_SELF_HEAL, FIX_HANDLERS"},
    # Framework
    {"id": 26, "name": "Automated reporting",           "script": "weekly-evolution-report.py",           "note": "Stub — not active"},
    {"id": 37, "name": "Weekly evolution report",       "script": "weekly-evolution-report.py",           "note": "Stub — not active"},
]

# Ideas that were mapped to stubs — now removed
REMOVED = [
    {"id": 1,  "name": "Error KB auto-search",           "script": "github-error-fix.py"},
    {"id": 3,  "name": "Auto-apply fixes",              "script": "auto-patch-dependencies.py"},
    {"id": 4,  "name": "Rollback on failure",           "script": "auto-rollback-on-fix.py"},
    {"id": 5,  "name": "Correlation across systems",    "script": "cross-system-error-correlation.py"},
    {"id": 6,  "name": "Predictive failure detection",  "script": "predictive-failure-detection.py"},
    {"id": 8,  "name": "Dependency mapping",            "script": "dependency-mapping.py"},
    {"id": 9,  "name": "Auto-patch dependencies",      "script": "auto-patch-dependencies.py"},
    {"id": 11, "name": "Auto-rollback on fix",          "script": "auto-rollback-on-fix.py"},
    {"id": 12, "name": "Cross-system error correlation","script": "cross-system-error-correlation.py"},
    {"id": 13, "name": "Predictive failure detection",  "script": "predictive-failure-detection.py"},
    {"id": 14, "name": "Chaos engineering",             "script": "self-healing-config.py"},
    {"id": 15, "name": "Security scanning",             "script": "skill-auto-updater.py"},
    {"id": 17, "name": "Cost optimization",           "script": "weekly-evolution-report.py"},
    {"id": 20, "name": "Secret rotation",              "script": "N/A — no rotating secrets"},
    {"id": 23, "name": "Autonomous agent orchestration","script": "multi-agent-orchestrator.py"},
    {"id": 25, "name": "Visual dashboard",             "script": "unified-dashboard.py"},
    {"id": 29, "name": "Interoceptive AI",             "script": "interoceptive-ai.py"},
    {"id": 32, "name": "Compound product loop",        "script": "compound-product-loop.py"},
    {"id": 33, "name": "5-floor self-driving board",  "script": "5floor-self-driving.py"},
    {"id": 34, "name": "Obsidian memory vault",       "script": "obsidian-memory-vault.py"},
]

SCRIPTS_DIR = Path("/root/.hermes/scripts")
KB = Path("/root/.hermes/error-knowledge-base.json")


def load_kb():
    if KB.exists():
        try:
            return json.loads(KB.read_text())
        except Exception:
            return {"errors": []}
    return {"errors": []}


def main():
    kb = load_kb()
    errors = kb.get("errors", [])
    total_errors = len(errors)
    verified = sum(1 for e in errors if e.get("verified") == "true")
    script_count = len(list(SCRIPTS_DIR.glob("*.py")) + list(SCRIPTS_DIR.glob("*.sh")))

    print("=" * 70)
    print("  HERMES EVOLUTION IDEAS — REAL VS REMOVED")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')} UTC")
    print(f"  Operational: {len(OPERATIONAL)}  |  Removed stubs: {len(REMOVED)}")
    print(f"  Scripts: {script_count} (was 62, pruned to 16)")
    print(f"  KB: {total_errors} entries ({verified} verified)")
    print("=" * 70)

    print(f"\n  ┌─ OPERATIONAL ({len(OPERATIONAL)}) ─────────────────────────────────────")
    for idea in sorted(OPERATIONAL, key=lambda x: x["id"]):
        print(f"  │ ✅  #{idea['id']:02d} {idea['name']:<35} {idea['script']}")
        print(f"  │      → {idea['note']}")
    print(f"  └{'─' * 60}")

    print(f"\n  ┌─ REMOVED ({len(REMOVED)}) ─────────────────────────────────────────────")
    for idea in sorted(REMOVED, key=lambda x: x["id"]):
        print(f"  │ ❌  #{idea['id']:02d} {idea['name']:<35} {idea['script']}")
    print(f"  └{'─' * 60}")

    print(f"\n  System is lean: {script_count} scripts, all with real consumers.")
    print(f"  9 evolution ops in evolution-engine.py, all operational.")


if __name__ == "__main__":
    main()
