#!/usr/bin/env python3
"""
KB Cross-Correlate - Correlate errors with time-of-day patterns.
"""

import json
import datetime
import fcntl
from collections import defaultdict
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
CORRELATE_FILE = Path("/root/.hermes/state/kb_cross_correlate.json")
LOG_FILE = Path("/root/.hermes/logs/kb_cross_correlate.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_errors():
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            return fh.readlines()
    except Exception:
        return []


def parse_time(line):
    """Extract hour from log line."""
    try:
        if line.startswith("["):
            ts_str = line[1 : line.find("]")]
            dt = datetime.datetime.fromisoformat(ts_str)
            return dt.hour
    except Exception:
        pass
    return -1


def main():
    log("=== KB Cross-Correlate started ===")

    errors = read_errors()

    # Count errors by hour
    hour_counts = defaultdict(int)
    for line in errors:
        hour = parse_time(line)
        if hour >= 0:
            hour_counts[hour] += 1

    # Find peak hours
    peak_hours = sorted(hour_counts.items(), key=lambda x: x[1], reverse=True)[:3]

    # Correlate with KB entries
    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": []}

    correlations = []
    for entry in kb.get("knowledge_base", []):
        error_pattern = entry.get("error", "").lower()
        for hour, count in peak_hours:
            if error_pattern:
                correlations.append({
                    "error": error_pattern[:60],
                    "peak_hour": hour,
                    "count": count,
                })

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_errors": len(errors),
        "hour_distribution": dict(hour_counts),
        "peak_hours": [{"hour": h, "count": c} for h, c in peak_hours],
        "correlations": correlations[:20],
    }

    CORRELATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CORRELATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Cross-Correlate: peak hours={[h for h,_ in peak_hours]} ===")


if __name__ == "__main__":
    main()
