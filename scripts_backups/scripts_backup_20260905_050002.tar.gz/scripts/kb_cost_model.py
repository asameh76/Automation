#!/usr/bin/env python3
"""
KB Cost Model - Fix Cost Model.
"""

import json
import datetime
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
COST_FILE = Path("/root/.hermes/state/kb_cost_model.json")
LOG_FILE = Path("/root/.hermes/logs/kb_cost_model.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE) as fh:
        return json.load(fh)


def compute_cost(fix):
    """Compute cost of applying a fix."""
    cost = 0
    action = fix.get("action", {})

    # Time cost
    if action.get("type") == "restart":
        cost += 5
    elif action.get("type") == "redeploy":
        cost += 10
    else:
        cost += 1

    # Risk cost
    if action.get("type") in ("restart", "redeploy"):
        cost += 3
    else:
        cost += 1

    return cost


def main():
    log("=== KB Cost Model started ===")

    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": []}

    entries = kb.get("knowledge_base", [])
    total_cost = 0
    fix_costs = []

    for entry in entries:
        for fix in entry.get("fixes", []):
            cost = compute_cost(fix)
            total_cost += cost
            fix_costs.append({
                "fix": fix.get("description", "")[:60],
                "cost": cost,
            })

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_cost": total_cost,
        "fix_costs": fix_costs,
        "avg_cost": round(total_cost / len(fix_costs), 2) if fix_costs else 0,
    }

    COST_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(COST_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Cost Model: total cost={total_cost} ===")


if __name__ == "__main__":
    main()
