#!/usr/bin/env python3
"""
KB Self-Test - Self-Testing.
"""

import json
import subprocess
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
TEST_FILE = Path("/root/.hermes/state/kb_self_test.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_test.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def test_kb_structure():
    """Test KB has proper structure."""
    try:
        kb = read_kb()
        if "knowledge_base" not in kb:
            return False, "Missing knowledge_base key"
        if not isinstance(kb["knowledge_base"], list):
            return False, "knowledge_base is not a list"
        return True, "Structure OK"
    except Exception as e:
        return False, str(e)


def test_kb_entries():
    """Test KB entries have required fields."""
    try:
        kb = read_kb()
        for i, entry in enumerate(kb.get("knowledge_base", [])[:10]):
            if "error" not in entry:
                return False, f"Entry {i} missing 'error'"
            if "status" not in entry:
                return False, f"Entry {i} missing 'status'"
        return True, "Entries OK"
    except Exception as e:
        return False, str(e)


def main():
    log("=== KB Self-Test started ===")

    tests = []
    results = []

    # Run tests
    passed, msg = test_kb_structure()
    tests.append({"name": "structure", "passed": passed, "message": msg})
    if passed:
        results.append(True)
    else:
        results.append(False)

    passed, msg = test_kb_entries()
    tests.append({"name": "entries", "passed": passed, "message": msg})
    if passed:
        results.append(True)
    else:
        results.append(False)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "tests": tests,
        "all_passed": all(results),
    }

    TEST_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TEST_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    passed_count = sum(results)
    total = len(results)
    log(f"=== KB Self-Test: {passed_count}/{total} passed ===")


if __name__ == "__main__":
    main()
