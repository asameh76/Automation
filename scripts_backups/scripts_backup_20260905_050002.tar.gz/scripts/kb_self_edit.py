#!/usr/bin/env python3
"""
KB Self-Edit - Self-editing curiosity loop.
Uses subprocess to call LLM for KB gap analysis.
Reads errors.log.
"""

import json
import os
import subprocess
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
GAP_FILE = Path("/root/.hermes/state/kb_gaps.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_edit.log")
OLLAMA_URL = "http://localhost:11434/api/generate"


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_errors():
    """Read recent errors from errors.log."""
    if not ERRORS_LOG.exists():
        return []
    try:
        with open(ERRORS_LOG) as fh:
            lines = fh.readlines()
        # Return last 100 lines
        return lines[-100:]
    except Exception as e:
        log(f"Error reading errors.log: {e}")
        return []


def call_llm(prompt, model="llama3.2"):
    """Call local LLM via ollama."""
    try:
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
        }
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", OLLAMA_URL, "-d", json.dumps(payload)],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            resp = json.loads(result.stdout)
            return resp.get("response", "")
        return ""
    except Exception as e:
        log(f"LLM call failed: {e}")
        return ""


def analyze_gaps(kb, errors):
    """Analyze KB gaps using LLM."""
    if not errors:
        return []

    errors_text = "".join(errors[-20:])
    kb_summary = {
        "entries": len(kb.get("knowledge_base", [])),
        "verified": sum(1 for e in kb.get("knowledge_base", []) if e.get("status") == "verified"),
        "investigate": sum(1 for e in kb.get("knowledge_base", []) if e.get("status") == "investigate"),
    }

    prompt = f"""Analyze this KB system for gaps.
KB state: {json.dumps(kb_summary)}
Recent errors:
{errors_text}

Identify:
1. Missing error patterns not in KB
2. KB entries that need more evidence
3. Patterns that keep recurring

Return a JSON list of gap descriptions (max 5)."""

    response = call_llm(prompt)
    if not response:
        return []

    try:
        # Try to extract JSON from response
        start = response.find("[")
        end = response.rfind("]") + 1
        if start >= 0 and end > start:
            gaps = json.loads(response[start:end])
            return gaps
    except Exception:
        pass

    return []


def main():
    log("=== KB Self-Edit started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    errors = read_errors()
    gaps = analyze_gaps(kb, errors)

    gap_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "gaps": gaps,
        "errors_analyzed": len(errors),
    }

    GAP_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(GAP_FILE, "w") as fh:
        json.dump(gap_state, fh, indent=2)

    log(f"=== KB Self-Edit finished: found {len(gaps)} gaps ===")


if __name__ == "__main__":
    main()
