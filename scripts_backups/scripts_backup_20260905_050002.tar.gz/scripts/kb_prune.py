#!/usr/bin/env python3
"""
KB Prune - KB Self-Optimization.
Prunes stale, duplicate entries.
Reads/writes error-knowledge-base.json.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_prune.log")

STALE_DAYS = 30


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def is_duplicate(entry, seen_errors):
    """Check if entry is duplicate of another."""
    error_key = entry.get("error", "").lower().strip()
    if error_key in seen_errors:
        return True
    seen_errors.add(error_key)
    return False


def is_stale(entry):
    """Check if entry is stale."""
    updated = entry.get("updated_at", entry.get("created_at", ""))
    if not updated:
        return False
    try:
        updated_dt = datetime.datetime.fromisoformat(updated)
        age = datetime.datetime.now() - updated_dt
        return age.days >= STALE_DAYS
    except Exception:
        return False


def main():
    log("=== KB Prune started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])
    original_count = len(entries)

    seen_errors = set()
    pruned_duplicates = 0
    pruned_stale = 0
    kept = []

    for entry in entries:
        if is_duplicate(entry, seen_errors):
            pruned_duplicates += 1
            continue
        if is_stale(entry) and entry.get("status") != "verified":
            pruned_stale += 1
            continue
        kept.append(entry)

    kb["knowledge_base"] = kept
    kb["version"] = kb.get("version", "1.0")
    kb["updated"] = datetime.datetime.now().isoformat()

    write_kb(kb)

    log(f"=== KB Prune: {original_count} -> {len(kept)} (duplicates:{pruned_duplicates}, stale:{pruned_stale}) ===")


if __name__ == "__main__":
    main()
