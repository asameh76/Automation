#!/usr/bin/env python3
"""
KB Self-Heal - KB Self-Healing Executor
Applies fixes from KB to system (docker, systemctl commands).
Has audit trail. Safe command allowlist.
"""

import json
import os
import subprocess
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
AUDIT_FILE = Path("/root/.hermes/state/kb_self_heal_audit.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_heal.log")


# Safe command allowlist
SAFE_COMMANDS = {
    "docker": ["restart", "stop", "start", "ps", "logs", "inspect", "pull"],
    "systemctl": ["restart", "stop", "start", "status", "is-active"],
    "nginx": ["reload", "restart", "stop"],
    "service": ["restart", "stop", "start"],
}


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_audit(audit):
    with open(AUDIT_FILE, "w") as fh:
        json.dump(audit, fh, indent=2)


def is_safe_command(cmd, subcmd):
    """Check if command is in allowlist."""
    if cmd not in SAFE_COMMANDS:
        return False
    return subcmd in SAFE_COMMANDS[cmd]


def run_safe_command(cmd_list):
    """Run a command only if it's in the allowlist."""
    if not cmd_list:
        return None, "Empty command"
    cmd = cmd_list[0]
    subcmd = cmd_list[1] if len(cmd_list) > 1 else ""
    if not is_safe_command(cmd, subcmd):
        return None, f"Command not in allowlist: {cmd} {subcmd}"
    try:
        result = subprocess.run(
            cmd_list,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode, result.stdout
    except Exception as e:
        return None, str(e)


def apply_fix(fix, audit):
    """Apply a single fix from KB."""
    fix_type = fix.get("type", "unknown")
    target = fix.get("target", "")
    action = fix.get("action", {})
    command = action.get("command", [])

    if not isinstance(command, list):
        command = [command]

    timestamp = datetime.datetime.now().isoformat()
    entry = {
        "timestamp": timestamp,
        "fix_type": fix_type,
        "target": target,
        "command": command,
        "status": "pending",
    }

    if fix_type == "systemd_service" and command:
        code, out = run_safe_command(command)
        entry["returncode"] = code
        entry["output"] = out[:500] if out else ""
        entry["status"] = "applied" if code == 0 else "failed"

    elif fix_type == "docker_action" and command:
        code, out = run_safe_command(command)
        entry["returncode"] = code
        entry["output"] = out[:500] if out else ""
        entry["status"] = "applied" if code == 0 else "failed"

    elif fix_type == "nginx_reload":
        code, out = run_safe_command(["nginx", "-s", "reload"])
        entry["returncode"] = code
        entry["output"] = out[:500] if out else ""
        entry["status"] = "applied" if code == 0 else "failed"

    else:
        entry["status"] = "skipped"
        entry["output"] = f"Unknown fix type: {fix_type}"

    audit["entries"].append(entry)
    return entry["status"] == "applied"


def main():
    log("=== KB Self-Heal started ===")
    STATE_DIR = Path("/root/.hermes/state")
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    # Load audit
    if AUDIT_FILE.exists():
        with open(AUDIT_FILE) as fh:
            audit = json.load(fh)
    else:
        audit = {"entries": [], "last_run": None}

    audit["last_run"] = datetime.datetime.now().isoformat()

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    fixes_applied = 0
    fixes_failed = 0

    for entry in kb.get("knowledge_base", []):
        if entry.get("status") != "verified":
            continue
        for fix in entry.get("fixes", []):
            if fix.get("applied"):
                continue
            success = apply_fix(fix, audit)
            if success:
                fix["applied"] = True
                fix["applied_at"] = datetime.datetime.now().isoformat()
                fixes_applied += 1
            else:
                fixes_failed += 1

    write_audit(audit)

    # Write updated KB
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    log(f"=== KB Self-Heal finished: {fixes_applied} applied, {fixes_failed} failed ===")


if __name__ == "__main__":
    main()
