#!/usr/bin/env python3
"""
KB NL Query - Natural Language Query interface.
"""

import json
import sys
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")


def read_kb():
    with open(KB_FILE) as fh:
        return json.load(fh)


def query_kb(nl_query):
    """Simple keyword-based query."""
    kb = read_kb()
    query_lower = nl_query.lower()
    results = []
    for entry in kb.get("knowledge_base", []):
        error = entry.get("error", "").lower()
        tags = [t.lower() for t in entry.get("tags", [])]
        if query_lower in error or query_lower in tags:
            results.append(entry)
    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: kb_nl_query.py <query>")
        print("Example: kb_nl_query.py 'docker nginx error'")
        return

    query = " ".join(sys.argv[1:])
    results = query_kb(query)

    print(f"Found {len(results)} results for: {query}")
    for r in results:
        print(f"\n- {r.get('error','')[:80]}")
        print(f"  Status: {r.get('status','')}")
        print(f"  Tags: {', '.join(r.get('tags',[]))}")


if __name__ == "__main__":
    main()
