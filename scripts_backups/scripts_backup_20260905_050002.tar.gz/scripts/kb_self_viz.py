#!/usr/bin/env python3
"""
KB Self-Viz - Self-Visualization/dashboard.
"""

import json
import datetime
from pathlib import Path


STATE_DIR = Path("/root/.hermes/state")
VIZ_FILE = Path("/root/.hermes/state/kb_self_viz.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_viz.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def load_json(path):
    if not path.exists():
        return {}
    try:
        with open(path) as fh:
            return json.load(fh)
    except Exception:
        return {}


def main():
    log("=== KB Self-Viz started ===")

    # Aggregate state files
    audit = load_json(STATE_DIR / "kb_audit.json")
    predictions = load_json(STATE_DIR / "kb_predictions.json")
    benchmark = load_json(STATE_DIR / "kb_benchmark.json")
    fbl = load_json(STATE_DIR / "kb_feedback_loop.json")
    certify = load_json(STATE_DIR / "kb_certify.json")

    viz = {
        "timestamp": datetime.datetime.now().isoformat(),
        "summary": {
            "total_entries": audit.get("total_entries", 0),
            "verified": audit.get("verified", 0),
            "coverage": audit.get("coverage", 0),
            "accuracy": benchmark.get("current_accuracy", 0),
            "confidence_avg": certify.get("avg_confidence", 0),
        },
        "predictions": predictions.get("predictions", []),
        "feedback_loop": {
            "applied": fbl.get("applied_fixes_count", 0),
            "validated": fbl.get("validated_count", 0),
        },
    }

    VIZ_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(VIZ_FILE, "w") as fh:
        json.dump(viz, fh, indent=2)

    log("=== KB Self-Viz updated ===")


if __name__ == "__main__":
    main()
