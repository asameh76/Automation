#!/usr/bin/env python3
"""
KB Evolution - KB Evolutionary Mechanisms.
Mutation, crossover, fitness.
Uses Counter, defaultdict, deepcopy.
"""

import json
import random
import datetime
import fcntl
from copy import deepcopy
from collections import Counter, defaultdict
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
EVOLUTION_FILE = Path("/root/.hermes/state/kb_evolution.json")
LOG_FILE = Path("/root/.hermes/logs/kb_evolution.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def compute_fitness(entry):
    """Compute fitness score for a KB entry."""
    score = 0
    status = entry.get("status", "unknown")
    if status == "verified":
        score += 10
    elif status == "investigate":
        score += 5

    fixes = entry.get("fixes", [])
    score += len(fixes) * 2

    for fix in fixes:
        if fix.get("applied"):
            score += 3
        if fix.get("verified"):
            score += 5
        if fix.get("evidence"):
            score += 1

    return score


def mutate(entry):
    """Mutate a KB entry."""
    mutated = deepcopy(entry)
    mutations = [
        ("error", lambda v: v + " [variant]"),
        ("status", lambda v: "investigate" if v == "new" else v),
        ("priority", lambda v: min(10, v + 1) if isinstance(v, int) else 5),
    ]
    field, func = random.choice(mutations)
    if field in mutated:
        try:
            mutated[field] = func(mutated[field])
        except Exception:
            pass
    return mutated


def crossover(entry_a, entry_b):
    """Crossover two KB entries."""
    child = deepcopy(entry_a)
    # Swap some fields
    if random.random() < 0.5:
        child["error"] = entry_b.get("error", entry_a.get("error"))
    if random.random() < 0.5:
        child["fixes"] = entry_b.get("fixes", entry_a.get("fixes"))
    if random.random() < 0.5:
        child["tags"] = entry_b.get("tags", entry_a.get("tags"))
    return child


def evolve_population(entries, generations=3, population_size=20):
    """Evolve the KB population."""
    population = list(entries)
    best_sofar = None
    best_fitness_sofar = 0

    for gen in range(generations):
        # Compute fitness
        fitness_scores = [(e, compute_fitness(e)) for e in population]
        fitness_scores.sort(key=lambda x: x[1], reverse=True)

        best_entry, best_fitness = fitness_scores[0]
        if best_fitness > best_fitness_sofar:
            best_fitness_sofar = best_fitness
            best_sofar = deepcopy(best_entry)

        # Selection
        selected = [e for e, _ in fitness_scores[: population_size // 2]]

        # Crossover and mutation
        new_population = list(selected)
        while len(new_population) < population_size:
            if random.random() < 0.3 and len(selected) >= 2:
                child = crossover(random.choice(selected), random.choice(selected))
            else:
                child = mutate(random.choice(selected))
            new_population.append(child)

        population = new_population

    return best_sofar, best_fitness_sofar, population


def main():
    log("=== KB Evolution started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])
    if len(entries) < 3:
        log("Not enough entries for evolution")
        return

    best, fitness, population = evolve_population(entries, generations=3, population_size=max(20, len(entries)))

    evolution_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "generations": 3,
        "best_fitness": fitness,
        "population_size": len(population),
        "best_entry_error": best.get("error", "")[:80] if best else None,
    }

    EVOLUTION_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(EVOLUTION_FILE, "w") as fh:
        json.dump(evolution_state, fh, indent=2)

    log(f"=== KB Evolution: best fitness={fitness} ===")


if __name__ == "__main__":
    main()
