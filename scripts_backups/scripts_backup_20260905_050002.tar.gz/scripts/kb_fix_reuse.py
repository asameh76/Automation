#!/usr/bin/env python3
"""
KB Fix Reuse - When a fix works, auto-apply it to similar/new errors.

Workflow:
  1. Read KB entries
  2. Collect verified=true entries (proven fixes)
  3. Find unverified errors with similar error_message or same component
  4. For each unverified error, find the best matching verified fix
  5. Apply the proven fix (mark as applied, increment reuse count)
  6. Write updated KB back
  7. Log what was done
"""

import json
import datetime
import fcntl
import re
from pathlib import Path
from difflib import SequenceMatcher

KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
LOG_FILE = Path("/root/.hermes/logs/kb_fix_reuse.log")
STATE_FILE = Path("/root/.hermes/state/kb_fix_reuse.json")

# Minimum similarity ratio to consider reusing a fix
SIMILARITY_THRESHOLD = 0.6

# Components that are "close enough" to reuse fixes across
COMPONENT_ALIASES = {
    "docker": ["containerd", "dockerd", "docker-compose"],
    "nginx": ["apache", "httpd"],
    "postgres": ["postgresql", "pg"],
    "redis": ["valkey"],
    "gateway": ["hermes-gateway", "gateway-service"],
    "errors.log": ["errors", "error-log", "error_log"],
}


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def similarity(a, b):
    """Return similarity ratio between two strings (0.0 to 1.0)."""
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def normalise_error_msg(msg):
    """Strip timestamps, IDs, noise from error messages for comparison."""
    if not msg:
        return ""
    # Remove common noise patterns
    msg = re.sub(r'\d{4}[-_]\d{2}[-_]\d{2}[-_]', '', msg)  # dates
    msg = re.sub(r'[a-f0-9]{8,}', '<ID>', msg)            # hex IDs
    msg = re.sub(r'\d{3}[-_]\d{6,}', '<ID>', msg)          # numeric IDs
    msg = re.sub(r'https?://\S+', '<URL>', msg)             # URLs
    msg = re.sub(r'[A-Fa-f0-9]{6,}', '<HEX>', msg)         # long hex
    msg = re.sub(r'\s+', ' ', msg)                          # collapse whitespace
    return msg.strip().lower()


def component_related(c1, c2):
    """Return True if component c1 is related to (same family as) c2."""
    if not c1 or not c2:
        return False
    c1, c2 = c1.lower(), c2.lower()
    if c1 == c2:
        return True
    for canon, aliases in COMPONENT_ALIASES.items():
        all_names = [canon] + aliases
        if c1 in all_names and c2 in all_names:
            return True
    return False


def build_signature_key(entry):
    """Extract the best text key from a KB entry for similarity matching."""
    parts = []
    if entry.get("signature"):
        parts.append(entry["signature"])
    if entry.get("component"):
        parts.append(entry["component"])
    if entry.get("correlation_type"):
        parts.append(entry["correlation_type"])
    # Also use fix text if present
    fix = entry.get("fix", "")
    if fix and len(fix) > 10:
        parts.append(normalise_error_msg(fix))
    return " | ".join(parts)


def find_verified_fixes(kb):
    """Return list of KB entries where verified=true and fix is present."""
    verified = []
    for entry in kb.get("errors", []):
        v = entry.get("verified", False)
        fix = entry.get("fix", "")
        if (v is True or v == "true") and fix:
            verified.append(entry)
    return verified


def find_unverified_errors(kb):
    """Return list of KB entries where verified != true (not yet proven)."""
    unverified = []
    for entry in kb.get("errors", []):
        v = entry.get("verified", False)
        if v is not True and v != "true":
            unverified.append(entry)
    return unverified


def score_fix_for_error(fix_entry, error_entry):
    """Score how well a verified fix suits an unverified error (0.0 to 1.0)."""
    score = 0.0

    # Same component = strong signal
    fix_comp = fix_entry.get("component", "")
    err_comp = error_entry.get("component", "")
    if component_related(fix_comp, err_comp):
        score += 0.4
    elif fix_comp and err_comp and fix_comp.lower() == err_comp.lower():
        score += 0.5

    # Fix was successful (high success_rate)
    sr = fix_entry.get("success_rate", 0.0)
    score += min(sr, 1.0) * 0.2

    # Occurrence count - fixes used many times are more reliable
    occ = fix_entry.get("occurrence_count", 0)
    score += min(occ / 20.0, 1.0) * 0.1

    # Total uses
    uses = fix_entry.get("total_uses", 0)
    score += min(uses / 10.0, 1.0) * 0.1

    # Similarity of error messages
    fix_sig = normalise_error_msg(fix_entry.get("signature", ""))
    err_sig = normalise_error_msg(error_entry.get("signature", ""))
    if fix_sig and err_sig:
        msg_sim = similarity(fix_sig, err_sig)
        score += msg_sim * 0.2

    return score


def apply_fix_to_error(error_entry, fix_entry, score):
    """Return a modified copy of error_entry with the fix applied."""
    updated = dict(error_entry)

    # Inherit the fix
    updated["fix"] = fix_entry["fix"]
    updated["fix_type"] = "reused_from_" + fix_entry.get("fix_type", "verified")

    # Mark as reused (not yet verified)
    updated["verified"] = "false"
    updated["reused_from"] = fix_entry.get("signature", "")

    # Record fix reuse
    reuse_history = updated.get("fix_reuse_history", [])
    reuse_history.append({
        "from_sig": fix_entry.get("signature", ""),
        "score": round(score, 4),
        "component": fix_entry.get("component", ""),
        "applied_at": datetime.datetime.now().isoformat(),
    })
    updated["fix_reuse_history"] = reuse_history

    # Increment the source fix's reuse counter
    # (caller handles updating the source fix in-place)

    return updated


def run():
    log("=== KB Fix Reuse started ===")

    kb = read_kb()
    errors = kb.get("errors", [])
    log(f"Total KB entries: {len(errors)}")

    verified_fixes = find_verified_fixes(kb)
    log(f"Verified (proven) fixes: {len(verified_fixes)}")

    unverified_errors = find_unverified_errors(kb)
    log(f"Unverified errors: {len(unverified_errors)}")

    if not verified_fixes:
        log("No verified fixes found. Nothing to do.")
        return

    if not unverified_errors:
        log("No unverified errors found. Nothing to do.")
        return

    # Track changes
    fix_applied_count = 0
    best_score_count = 0
    reused_sigs = []

    for err_entry in unverified_errors:
        err_sig = err_entry.get("signature", "<no-sig>")

        # Skip entries that already have a non-trivial fix assigned
        if err_entry.get("fix") and len(err_entry.get("fix", "")) > 5:
            # Already has a fix — only upgrade if we find a MUCH better one
            current_fix = err_entry.get("fix", "")

        # Find best matching verified fix
        best_score = 0.0
        best_fix = None

        for fix_entry in verified_fixes:
            score = score_fix_for_error(fix_entry, err_entry)
            if score > best_score:
                best_score = score
                best_fix = fix_entry

        if best_score < SIMILARITY_THRESHOLD:
            log(f"  SKIP {err_sig[:60]}: no fix above threshold (best={best_score:.3f})")
            continue

        # Apply the fix
        updated = apply_fix_to_error(err_entry, best_fix, best_score)

        # Replace in the errors list
        for i, e in enumerate(errors):
            if e.get("signature") == err_sig:
                errors[i] = updated
                break

        # Increment reuse counter on source fix
        src_sig = best_fix.get("signature", "")
        for i, e in enumerate(errors):
            if e.get("signature") == src_sig:
                errors[i]["total_uses"] = errors[i].get("total_uses", 0) + 1
                errors[i]["reuse_count"] = errors[i].get("reuse_count", 0) + 1
                break

        fix_applied_count += 1
        best_score_count += 1
        reused_sigs.append((err_sig[:60], src_sig[:60], round(best_score, 3)))
        log(f"  APPLIED fix '{src_sig[:40]}' → '{err_sig[:40]}' (score={best_score:.3f})")

    # Write updated KB
    kb["errors"] = errors
    write_kb(kb)

    # Save run state
    state = {
        "run_at": datetime.datetime.now().isoformat(),
        "verified_fixes_count": len(verified_fixes),
        "unverified_errors_count": len(unverified_errors),
        "fix_applied_count": fix_applied_count,
        "reused": reused_sigs,
    }
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Fix Reuse complete: {fix_applied_count} fix(es) applied ===")


if __name__ == "__main__":
    run()
