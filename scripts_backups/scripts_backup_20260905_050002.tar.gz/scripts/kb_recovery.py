#!/usr/bin/env python3
"""
KB Recovery - KB Corruption Recovery.
Auto-restores KB from capsule backups if file is corrupted.
Uses tarfile.
"""

import json
import tarfile
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
CAPSULE_DIR = Path("/root/.hermes/capsule")
LOG_FILE = Path("/root/.hermes/logs/kb_recovery.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def is_kb_corrupted():
    """Check if KB file is corrupted."""
    if not KB_FILE.exists():
        return True
    try:
        with open(KB_FILE) as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
            try:
                json.load(fh)
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        return False
    except Exception:
        return True


def find_latest_backup():
    """Find the most recent capsule backup."""
    if not CAPSULE_DIR.exists():
        return None
    backups = list(CAPSULE_DIR.glob("capsule-*.tar.gz"))
    if not backups:
        return None
    backups.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return backups[0]


def restore_from_backup(backup_path):
    """Restore KB from a capsule backup."""
    log(f"Restoring KB from {backup_path}")
    try:
        with tarfile.open(backup_path, "r:gz") as tar:
            # Find the KB file in the archive
            for member in tar.getmembers():
                if "error-knowledge-base" in member.name:
                    tar.extract(member, PATH="/tmp/kb_restore/")
                    restored = Path("/tmp/kb_restore") / member.name
                    if restored.exists():
                        with open(restored) as src:
                            data = json.load(src)
                        with open(KB_FILE, "w") as dst:
                            fcntl.flock(dst.fileno(), fcntl.LOCK_EX)
                            try:
                                json.dump(data, dst, indent=2)
                            finally:
                                fcntl.flock(dst.fileno(), fcntl.LOCK_UN)
                        log(f"Successfully restored KB from {backup_path}")
                        return True
        return False
    except Exception as e:
        log(f"Restore failed: {e}")
        return False


def main():
    log("=== KB Recovery started ===")

    if not is_kb_corrupted():
        log("KB file is healthy, no recovery needed")
        return

    log("KB file is corrupted, searching for backup...")
    backup = find_latest_backup()
    if backup:
        success = restore_from_backup(backup)
        if success:
            log("=== KB Recovery: SUCCESS ===")
        else:
            log("=== KB Recovery: FAILED ===")
    else:
        log("No capsule backup found")
        # Create empty KB
        empty_kb = {"knowledge_base": [], "version": "1.0", "created": datetime.datetime.now().isoformat()}
        with open(KB_FILE, "w") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try:
                json.dump(empty_kb, fh, indent=2)
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        log("Created new empty KB")


if __name__ == "__main__":
    main()
