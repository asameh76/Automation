#!/usr/bin/env python3
"""
KB Simple Report - Simple report generation.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
REPORT_FILE = Path("/root/.hermes/state/kb_simple_report.json")
LOG_FILE = Path("/root/.hermes/logs/kb_simple_report.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB Simple Report started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    entries = kb.get("knowledge_base", [])

    report = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_entries": len(entries),
        "verified": sum(1 for e in entries if e.get("status") == "verified"),
        "investigate": sum(1 for e in entries if e.get("status") == "investigate"),
        "new": sum(1 for e in entries if e.get("status") == "new"),
        "by_tag": {},
    }

    for entry in entries:
        for tag in entry.get("tags", []):
            report["by_tag"][tag] = report["by_tag"].get(tag, 0) + 1

    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(REPORT_FILE, "w") as fh:
        json.dump(report, fh, indent=2)

    log(f"=== KB Simple Report: {report['total_entries']} entries ===")


if __name__ == "__main__":
    main()
