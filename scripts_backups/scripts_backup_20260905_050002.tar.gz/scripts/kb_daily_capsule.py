#!/usr/bin/env python3
"""KB Daily Capsule — comprehensive full backup twice per day."""
import json, tarfile, gzip, io, shutil
from datetime import datetime
from pathlib import Path

BACKUP_DIR = "/root/backups"
Path(BACKUP_DIR).mkdir(exist_ok=True)

def create_daily_capsule():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    capsule = f"{BACKUP_DIR}/kb_daily_{ts}.tar.gz"
    
    kb_files = [
        "/root/.hermes/error-knowledge-base.json",
        "/root/.hermes/state/evolution-state.json",
        "/root/.hermes/state/kb_archive.json",
        "/root/.hermes/state/kb_healer_state.json",
        "/root/.hermes/state/kb_predictor_state.json",
        "/root/.hermes/state/kb_llm_session.json",
        "/root/.hermes/backups/",
    ]
    
    with tarfile.open(capsule, "w:gz") as tar:
        for path in kb_files:
            p = Path(path)
            if p.is_file():
                with open(p, "rb") as f:
                    data = f.read()
                info = tarfile.TarInfo(name=str(p).replace("/", "_").replace(".","_"))
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
            elif p.is_dir():
                for f in p.glob("*"):
                    if f.is_file() and f.suffix == ".tar.gz":
                        with open(f, "rb") as fd:
                            data = fd.read()
                        info = tarfile.TarInfo(name=f"backups_{f.name}")
                        info.size = len(data)
                        tar.addfile(info, io.BytesIO(data))
    
    size = round(Path(capsule).stat().st_size / 1024)
    
    # Keep last 20 (10 days at 2x/day)
    all_capsules = sorted(Path(BACKUP_DIR).glob("kb_daily_*.tar.gz"))
    while len(all_capsules) > 20:
        all_capsules[0].unlink()
        all_capsules = all_capsules[1:]
    
    # Also save to dated folder
    date_dir = Path(BACKUP_DIR) / datetime.now().strftime("%Y-%m-%d")
    date_dir.mkdir(exist_ok=True)
    shutil.copy(capsule, date_dir / f"kb_{datetime.now().strftime('%H%M%S')}.tar.gz")
    
    print(f"[DAILY] Full capsule: {capsule} ({size}KB)")
    return capsule

if __name__ == "__main__":
    create_daily_capsule()
