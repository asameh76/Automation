#!/usr/bin/env python3
"""
KB Self-Awareness - Detect new services/components.
Has service fingerprints for hermes-gateway, postiz, temporal, nginx, docker.
Writes to /root/.hermes/state/kb_self_awareness.json
"""

import json
import os
import subprocess
import datetime
from pathlib import Path


STATE_FILE = Path("/root/.hermes/state/kb_self_awareness.json")
LOG_FILE = Path("/root/.hermes/logs/kb_self_awareness.log")


# Service fingerprints
SERVICE_FINGERPRINTS = {
    "hermes-gateway": {
        "process_name": "hermes-gateway",
        "ports": [8000, 8080, 3000],
        "files": ["/root/.hermes/gateway/main.py", "/root/.hermes/gateway/app.py"],
        "docker_image": None,
    },
    "postiz": {
        "process_name": "postiz",
        "ports": [3000, 5000],
        "files": ["/root/postiz/", "/app/"],
        "docker_image": "postiz/postiz",
    },
    "temporal": {
        "process_name": "temporal",
        "ports": [7233, 7234],
        "files": ["/usr/local/bin/temporal"],
        "docker_image": "temporalio/server",
    },
    "nginx": {
        "process_name": "nginx",
        "ports": [80, 443],
        "files": ["/etc/nginx/nginx.conf"],
        "docker_image": None,
    },
    "docker": {
        "process_name": "dockerd",
        "ports": [2375, 2376],
        "files": ["/var/run/docker.sock"],
        "docker_image": None,
    },
}


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def check_process(name):
    """Check if a process is running."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def check_port(port):
    """Check if a port is listening."""
    try:
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return str(port) in result.stdout
    except Exception:
        return False


def check_file(path):
    """Check if a file exists."""
    return Path(path).exists()


def check_docker_image(image):
    """Check if a docker image exists."""
    try:
        result = subprocess.run(
            ["docker", "images", "-q", image],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return bool(result.stdout.strip())
    except Exception:
        return False


def detect_service(name, fingerprint):
    """Detect a single service."""
    status = "unknown"
    checks = {}

    # Check process
    has_process = check_process(fingerprint["process_name"])
    checks["process"] = has_process
    if has_process:
        status = "running"

    # Check ports
    open_ports = [p for p in fingerprint["ports"] if check_port(p)]
    checks["ports"] = open_ports
    if open_ports:
        status = "running"

    # Check files
    existing_files = [f for f in fingerprint["files"] if check_file(f)]
    checks["files"] = existing_files

    # Check docker image
    if fingerprint["docker_image"]:
        has_image = check_docker_image(fingerprint["docker_image"])
        checks["docker_image"] = has_image
        if has_image:
            status = "running"

    return {
        "name": name,
        "status": status,
        "checks": checks,
        "last_checked": datetime.datetime.now().isoformat(),
    }


def main():
    log("=== KB Self-Awareness started ===")

    state = {
        "last_scan": datetime.datetime.now().isoformat(),
        "services": {},
        "new_services": [],
        "missing_services": [],
    }

    prev_state = {}
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as fh:
                prev_state = json.load(fh)
        except Exception:
            pass

    prev_services = set(prev_state.get("services", {}).keys())

    for name, fingerprint in SERVICE_FINGERPRINTS.items():
        result = detect_service(name, fingerprint)
        state["services"][name] = result

        if name not in prev_services:
            if result["status"] == "running":
                state["new_services"].append(name)
                log(f"NEW SERVICE DETECTED: {name}")

        if result["status"] != "running" and name in prev_services:
            state["missing_services"].append(name)
            log(f"SERVICE MISSING: {name}")

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Self-Awareness finished: {len(state['new_services'])} new, {len(state['missing_services'])} missing ===")


if __name__ == "__main__":
    main()
