#!/usr/bin/env python3
"""
KB Predictor - KB Prediction Engine.
Analyzes trends, forecasts failures.
Reads system metrics (disk, mem, load, docker stats).
Writes to kb_predictions.json.
"""

import json
import datetime
import subprocess
import fcntl
from pathlib import Path


PREDICTIONS_FILE = Path("/root/.hermes/state/kb_predictions.json")
LOG_FILE = Path("/root/.hermes/logs/kb_predictor.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def get_disk_usage():
    """Get disk usage percent."""
    try:
        result = subprocess.run(
            ["df", "-h", "/"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        lines = result.stdout.strip().split("\n")
        if len(lines) >= 2:
            parts = lines[1].split()
            if len(parts) >= 5:
                usage_str = parts[4].replace("%", "")
                return int(usage_str)
    except Exception:
        pass
    return 0


def get_memory_usage():
    """Get memory usage percent."""
    try:
        with open("/proc/meminfo") as fh:
            lines = fh.readlines()
        mem_total = 0
        mem_available = 0
        for line in lines:
            if line.startswith("MemTotal:"):
                mem_total = int(line.split()[1])
            elif line.startswith("MemAvailable:"):
                mem_available = int(line.split()[1])
        if mem_total > 0:
            return int(((mem_total - mem_available) / mem_total) * 100)
    except Exception:
        pass
    return 0


def get_load_average():
    """Get load average."""
    try:
        with open("/proc/loadavg") as fh:
            parts = fh.read().split()
        return [float(parts[i]) for i in range(3)]
    except Exception:
        return [0.0, 0.0, 0.0]


def get_docker_stats():
    """Get docker stats for running containers."""
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}|{{.Status}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        containers = []
        for line in result.stdout.strip().split("\n"):
            if line:
                parts = line.split("|")
                if len(parts) >= 2:
                    containers.append({"name": parts[0], "status": parts[1]})
        return containers
    except Exception:
        return []


def forecast_disk_full(threshold=85):
    """Forecast if disk will fill up soon."""
    usage = get_disk_usage()
    return {
        "type": "disk_full",
        "current_usage": usage,
        "threshold": threshold,
        "predicted": usage >= threshold,
    }


def forecast_memory_pressure(threshold=85):
    """Forecast memory pressure."""
    usage = get_memory_usage()
    return {
        "type": "memory_pressure",
        "current_usage": usage,
        "threshold": threshold,
        "predicted": usage >= threshold,
    }


def forecast_load_spike(threshold=4.0):
    """Forecast load spike."""
    load = get_load_average()
    predicted = load[0] >= threshold
    return {
        "type": "load_spike",
        "current_load": load[0],
        "threshold": threshold,
        "predicted": predicted,
    }


def forecast_docker_down():
    """Forecast docker container issues."""
    containers = get_docker_stats()
    unhealthy = [c for c in containers if "Up" not in c.get("status", "")]
    return {
        "type": "docker_down",
        "total": len(containers),
        "unhealthy": len(unhealthy),
        "predicted": len(unhealthy) > 0,
    }


def main():
    log("=== KB Predictor started ===")

    predictions = []
    predictions.append(forecast_disk_full())
    predictions.append(forecast_memory_pressure())
    predictions.append(forecast_load_spike())
    predictions.append(forecast_docker_down())

    data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "predictions": predictions,
        "metrics": {
            "disk_usage": get_disk_usage(),
            "memory_usage": get_memory_usage(),
            "load_average": get_load_average(),
            "docker_containers": len(get_docker_stats()),
        },
    }

    PREDICTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(PREDICTIONS_FILE, "w") as fh:
        json.dump(data, fh, indent=2)

    predicted_count = sum(1 for p in predictions if p.get("predicted"))
    log(f"=== KB Predictor: {predicted_count}/{len(predictions)} predicted issues ===")


if __name__ == "__main__":
    main()
