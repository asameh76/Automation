#!/usr/bin/env python3
"""
kb_status.py — One-shot system status report
Run manually or via: hermes run kb_status.py
"""
import subprocess, json, os, sys, fcntl
from pathlib import Path
from datetime import datetime

HERMES_DIR = Path("/root/.hermes")
SCRIPTS_DIR = HERMES_DIR / "scripts"
STATE_DIR = HERMES_DIR / "state"
KB_FILE = HERMES_DIR / "error-knowledge-base.json"
KEYS_FILE = Path("/root/.hermes-keys/.env")

def run(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return r.stdout.strip()

def read_json(path):
    try:
        return json.load(open(path))
    except:
        return None

def kb_stats():
    kb = read_json(KB_FILE) or {}
    errors = kb.get("errors", [])
    v_types = ['verified','manual_verified','canary_verified','cross_verified','self_healed']
    v = sum(1 for e in errors if e.get("verified") in v_types)
    total = len(errors)
    health = round(v * 100 / max(total, 1), 1)
    return total, v, health

def disk():
    out = run("df -h / | tail -1")
    try:
        parts = out.split()
        used_pct = int(parts[4].rstrip('%'))
        return f"{used_pct}%"
    except:
        return "?"

def gemgyms():
    code = run("curl -s -o /dev/null -w '%{http_code}' https://gemgyms.com --max-time 8 --fail 2>/dev/null || echo '---'")
    return "✅ UP" if code == "200" else f"❌ HTTP {code}"

def services():
    out = run("systemctl is-active hermes-gateway.service caddy.service postiz.service 2>/dev/null || echo 'unknown'")
    lines = [l.strip() for l in out.splitlines() if l.strip()]
    statuses = []
    for line in lines:
        if line == "active":
            statuses.append("✅")
        else:
            statuses.append(f"❌ {line}")
    return " ".join(statuses) if statuses else "?"

def cron_count():
    # Count active crons
    state_file = STATE_DIR / "cron_state.json"
    if state_file.exists():
        data = read_json(state_file)
        if data:
            jobs = data.get("jobs", [])
            active = sum(1 for j in jobs if j.get("enabled") and not j.get("paused_at"))
            return f"{active}/{len(jobs)}"
    return "?"

def last_kb_combined():
    log_file = HERMES_DIR / "logs" / "kb_combined.log"
    if log_file.exists():
        lines = open(log_file).readlines()
        for line in reversed(lines):
            if "finished" in line.lower():
                # Extract timestamp from line
                import re
                m = re.search(r'\[(.{19})', line)
                if m:
                    return m.group(1)
    return "?"

def kb_growth():
    state = read_json(STATE_DIR / "kb_self_audit_state.json") or {}
    runs = state.get("runs", [])
    if len(runs) >= 2:
        first = runs[0]
        last = runs[-1]
        first_ts = first.get("ts", "")
        last_ts = last.get("ts", "")
        gaps_first = first.get("gaps", 0)
        gaps_last = last.get("gaps", 0)
        return f"{gaps_first}→{gaps_last} gaps"
    return "?"

def main():
    total, verified, health = kb_stats()
    disk_pct = disk()
    gemgyms_status = gemgyms()
    svc_status = services()
    cron_info = cron_count()
    last_combined = last_kb_combined()
    
    print("=" * 40)
    print(f"  🧠 KB:       {total} entries | {health}% health")
    print(f"  💾 Disk:     {disk_pct} used")
    print(f"  🌐 gemgyms:  {gemgyms_status}")
    print(f"  ⚙️  Services: {svc_status}")
    print(f"  ⏰ Crons:    {cron_info} active")
    print(f"  🔄 KB Comb:  {last_combined}")
    print(f"  📉 Audit:    {kb_growth()}")
    print("=" * 40)

if __name__ == "__main__":
    main()
