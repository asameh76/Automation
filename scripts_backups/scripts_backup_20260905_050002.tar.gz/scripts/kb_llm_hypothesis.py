#!/usr/bin/env python3
"""
KB LLM Hypothesis - LLM Hypothesis Generator.
Uses ollama at localhost:11434.
"""

import json
import subprocess
import datetime
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
HYP_FILE = Path("/root/.hermes/state/kb_llm_hypothesis.json")
LOG_FILE = Path("/root/.hermes/logs/kb_llm_hypothesis.log")
OLLAMA_URL = "http://localhost:11434/api/generate"


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE) as fh:
        return json.load(fh)


def call_llm(prompt, model="llama3.2"):
    """Call local LLM via ollama."""
    try:
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
        }
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", OLLAMA_URL, "-d", json.dumps(payload)],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            resp = json.loads(result.stdout)
            return resp.get("response", "")
    except Exception as e:
        log(f"LLM call failed: {e}")
    return ""


def main():
    log("=== KB LLM Hypothesis started ===")

    try:
        kb = read_kb()
    except Exception:
        kb = {"knowledge_base": []}

    entries = kb.get("knowledge_base", [])
    if not entries:
        log("No KB entries to analyze")
        return

    # Create summary for LLM
    summary = []
    for entry in entries[-10:]:
        summary.append({
            "error": entry.get("error", "")[:100],
            "status": entry.get("status", ""),
            "fixes": len(entry.get("fixes", [])),
            "tags": entry.get("tags", []),
        })

    prompt = f"""Analyze these KB entries and generate hypotheses about root causes:

{json.dumps(summary, indent=2)}

Generate hypotheses as JSON list with keys: type, description, confidence (0-1).
Return max 5 hypotheses."""

    response = call_llm(prompt)
    hypotheses = []
    try:
        start = response.find("[")
        end = response.rfind("]") + 1
        if start >= 0 and end > start:
            hypotheses = json.loads(response[start:end])
    except Exception:
        log(f"Could not parse LLM response")

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "hypotheses": hypotheses,
    }

    HYP_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(HYP_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB LLM Hypothesis: {len(hypotheses)} hypotheses generated ===")


if __name__ == "__main__":
    main()
