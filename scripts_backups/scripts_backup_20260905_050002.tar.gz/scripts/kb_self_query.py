#!/usr/bin/env python3
"""
KB Self-Query - KB Self-Query.
"""

import json
import sys
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def query_kb(keyword):
    """Query KB by keyword."""
    kb = read_kb()
    results = []
    for entry in kb.get("knowledge_base", []):
        error = entry.get("error", "").lower()
        tags = [t.lower() for t in entry.get("tags", [])]
        if keyword.lower() in error or keyword.lower() in tags:
            results.append(entry)
    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: kb_self_query.py <keyword>")
        return

    keyword = sys.argv[1]
    results = query_kb(keyword)

    print(f"Found {len(results)} results for '{keyword}':")
    for r in results:
        print(f"\n- {r.get('error','')[:80]}")
        print(f"  Status: {r.get('status','')}")


if __name__ == "__main__":
    main()
