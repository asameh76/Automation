#!/usr/bin/env python3
"""
KB Benchmark - Self-Benchmarking.
Tracks prediction accuracy.
Reads kb_predictions.json and kb_audit.json.
"""

import json
import datetime
import fcntl
from pathlib import Path


PREDICTIONS_FILE = Path("/root/.hermes/state/kb_predictions.json")
AUDIT_FILE = Path("/root/.hermes/state/kb_audit.json")
BENCHMARK_FILE = Path("/root/.hermes/state/kb_benchmark.json")
LOG_FILE = Path("/root/.hermes/logs/kb_benchmark.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def load_json(path):
    if not path.exists():
        return {}
    try:
        with open(path) as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as fh:
        json.dump(data, fh, indent=2)


def compute_accuracy():
    """Compute prediction accuracy from predictions and audit."""
    predictions = load_json(PREDICTIONS_FILE)
    audit = load_json(AUDIT_FILE)

    pred_list = predictions.get("predictions", [])
    if not pred_list:
        return 1.0, 0, {}

    correct = 0
    total = len(pred_list)

    accuracy_by_type = {}
    for pred in pred_list:
        ptype = pred.get("type", "unknown")
        if ptype not in accuracy_by_type:
            accuracy_by_type[ptype] = {"correct": 0, "total": 0}
        accuracy_by_type[ptype]["total"] += 1

        predicted = pred.get("predicted_occurrence", False)
        actual = pred.get("actual_occurrence", False)
        if predicted == actual:
            correct += 1
            accuracy_by_type[ptype]["correct"] += 1

    accuracy = correct / total if total > 0 else 0.0

    for ptype, vals in accuracy_by_type.items():
        if vals["total"] > 0:
            vals["accuracy"] = vals["correct"] / vals["total"]

    return accuracy, total, accuracy_by_type


def main():
    log("=== KB Benchmark started ===")

    accuracy, total, by_type = compute_accuracy()

    benchmark = load_json(BENCHMARK_FILE)
    history = benchmark.get("history", [])

    snapshot = {
        "timestamp": datetime.datetime.now().isoformat(),
        "accuracy": accuracy,
        "predictions_evaluated": total,
        "accuracy_by_type": by_type,
    }

    history.append(snapshot)
    # Keep last 100 snapshots
    history = history[-100:]

    benchmark["history"] = history
    benchmark["last_run"] = snapshot["timestamp"]
    benchmark["current_accuracy"] = accuracy

    save_json(BENCHMARK_FILE, benchmark)

    log(f"=== KB Benchmark: accuracy={accuracy:.2%} ({total} predictions) ===")


if __name__ == "__main__":
    main()
