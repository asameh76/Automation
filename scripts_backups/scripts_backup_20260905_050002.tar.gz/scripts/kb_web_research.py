#!/usr/bin/env python3
"""KB Web Research — searches internet sources for errors using direct HTTP."""
import json, sys, re, urllib.request, urllib.parse
from datetime import datetime

KB_PATH = "/root/.hermes/error-knowledge-base.json"
LOCK_FILE = "/root/.hermes/state/kb_manager.lock"
RESULTS_FILE = "/root/.hermes/state/kb_research_results.json"

SOURCES = {
    "stackoverflow": "site:stackoverflow.com {q}",
    "serverfault": "site:serverfault.com {q}",
    "digitalocean": "site:digitalocean.com/community {q}",
    "github": "site:github.com {q} error fix solution",
    "reddit": "site:reddit.com/r/sysadmin {q}",
    "superuser": "site:superuser.com {q}",
}

def read_kb():
    import fcntl
    with open(LOCK_FILE, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            with open(KB_PATH) as fh:
                return json.load(fh)
        except Exception:
            return {"errors": []}
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def write_kb(kb):
    import fcntl
    with open(LOCK_FILE, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            with open(KB_PATH, "w") as fh:
                json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

def search_duckduckgo(query, limit=5):
    """Search via DuckDuckGo HTML (no API key needed)."""
    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
        results = []
        for m in re.finditer(r'<a class="result__a" href="([^"]+)"[^>]*>([^<]+)</a>', html):
            results.append({"url": m.group(1), "title": re.sub(r'<[^>]+>', "", m.group(2))})
            if len(results) >= limit:
                break
        return results
    except Exception:
        return []

def search_github(query, limit=5):
    """Search GitHub API for issues/PRs (public, no token needed)."""
    url = f"https://api.github.com/search/issues?q={urllib.parse.quote(query)}+in:title&per_page={limit}"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/vnd.github.v3+json", "User-Agent": "hermes-kb"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        return [{"url": i["html_url"], "title": i["title"]} for i in data.get("items", [])]
    except Exception:
        return []

def fetch_url(url, char_limit=6000):
    """Fetch and extract text content from a URL."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode("utf-8", errors="ignore")
        # Extract visible text
        text = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:char_limit]
    except Exception:
        return ""

def extract_commands(content):
    """Extract actionable shell commands from content."""
    commands = []
    for cmd in re.findall(r'`([^`\n]{5,150})`', content):
        if any(x in cmd for x in ["sudo ", "systemctl", "docker ", "nginx ", "redis", "psql", "chmod ", "apt ", "yum ", "pip ", "service ", "kill ", "pkill", "curl ", "wget", "mkdir ", "chown ", "iptables"]):
            commands.append(cmd.strip()[:120])
    return list(dict.fromkeys(commands))[:10]

def research_error(query, add_to_kb=False):
    """Research an error across all web sources."""
    results = {}

    # DuckDuckGo search across sources
    for source, tmpl in SOURCES.items():
        ddg_query = tmpl.format(q=query)
        items = search_duckduckgo(ddg_query, limit=3)
        if items:
            results[source] = items

    # Also try GitHub API directly
    gh_results = search_github(f"{query} error fix", limit=5)
    if gh_results:
        results["github_api"] = gh_results

    all_commands = []
    solution = ""

    # Fetch top results to extract commands/solutions
    priority = ["stackoverflow", "serverfault", "digitalocean", "github_api", "superuser"]
    for src in priority:
        if src in results and results[src]:
            for item in results[src][:2]:
                url = item.get("url", "")
                if not url:
                    continue
                content = fetch_url(url)
                if not content:
                    continue
                all_commands.extend(extract_commands(content))
                # Get first substantial paragraph as potential solution
                if not solution:
                    paras = [p.strip() for p in content.split(".") if len(p.strip()) > 80]
                    if paras:
                        solution = paras[0][:200]

    # Deduplicate commands
    seen = set()
    unique = []
    for c in all_commands:
        key = c[:50]
        if key not in seen:
            seen.add(key)
            unique.append(c)

    output = {
        "query": query,
        "timestamp": datetime.now().isoformat(),
        "sources_found": list(results.keys()),
        "total_results": sum(len(v) for v in results.values()),
        "commands": unique[:8],
        "solution": solution,
        "all_results": {s: [{"title": i.get("title", ""), "url": i.get("url", "")} for i in items] for s, items in results.items()}
    }

    with open(RESULTS_FILE, "w") as f:
        json.dump(output, f, indent=2)

    if add_to_kb:
        kb = read_kb()
        entry_id = f"webresearch_{query[:30].replace(' ','_').lower()}"
        existing = [e for e in kb.get("errors", []) if e.get("id") == entry_id]
        if not existing:
            kb["errors"].append({
                "id": entry_id,
                "timestamp": datetime.now().isoformat(),
                "error_type": "researched",
                "error_message": f"RESEARCH:{query}",
                "component": "internet",
                "fix_type": "hypothesis",
                "solution": solution or "; ".join(unique[:3]),
                "source": "web_research",
                "commands": unique[:5],
                "findings_count": output["total_results"],
                "self_healed": False,
                "verified": False
            })
            write_kb(kb)

    return output

if __name__ == "__main__":
    query = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "python exception handling"
    add = "--add-kb" in sys.argv
    result = research_error(query, add_to_kb=add)
    print(f"Sources: {result.get('sources_found', [])}")
    print(f"Total results: {result.get('total_results', 0)}")
    if result.get("commands"):
        print("Commands found:")
        for c in result["commands"][:5]:
            print(f"  {c[:80]}")
    if result.get("solution"):
        print(f"Solution: {result['solution'][:100]}")
    print(f"\nFull results: {RESULTS_FILE}")
