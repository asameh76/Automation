#!/bin/bash
set -euo pipefail

# Load credentials from .env
source /root/.hermes-keys/.env 2>/dev/null || true

# Validate required env vars
if [ -z "$CLOUDFLARE_ACCOUNT_ID" ] || [ -z "$CF_ACCESS_KEY_ID" ] || [ -z "$CF_SECRET_ACCESS_KEY" ]; then
    echo "ERROR: Missing Cloudflare R2 credentials in .env" >&2
    exit 1
fi

R2_REMOTE="cloudflare_hermes"
R2_BUCKET="gem-gyms76"
R2_PATH="${R2_REMOTE}:${R2_BUCKET}/backups/latest"
BACKUP_DATE=$(date +%Y%m%d_%H%M%S)

echo "[$BACKUP_DATE] Starting R2 sync..."

# Sync only the critical directories (not large venvs, node_modules, docker)
rclone sync /root/.hermes/scripts \
    "$R2_PATH/scripts/" \
    --fast-list \
    2>&1

rclone sync /root/.hermes/skills \
    "$R2_PATH/skills/" \
    --fast-list \
    2>&1

rclone sync /root/.hermes-keys \
    "$R2_PATH/keys/" \
    --fast-list \
    2>&1

# Metadata
echo "{\"timestamp\": \"$(date -Iseconds)\", \"source\": \"hermes\", \"type\": \"sync\"}" > /tmp/backup_meta.json
rclone copy /tmp/backup_meta.json "$R2_PATH/" 2>&1
rm -f /tmp/backup_meta.json

echo "[$BACKUP_DATE] R2 sync completed successfully"
exit 0
