#!/usr/bin/env python3
"""
KB Accelerate Promotion - Accelerate KB entry promotion.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ACCEL_FILE = Path("/root/.hermes/state/kb_accelerate_promotion.json")
LOG_FILE = Path("/root/.hermes/logs/kb_accelerate_promotion.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def main():
    log("=== KB Accelerate Promotion started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    promoted = 0
    for entry in kb.get("knowledge_base", []):
        if entry.get("status") == "investigate":
            fixes = entry.get("fixes", [])
            has_applied_fix = any(f.get("applied") for f in fixes)
            has_evidence = any(f.get("evidence") for f in fixes)
            if has_applied_fix and has_evidence:
                entry["status"] = "verified"
                entry["verified_at"] = datetime.datetime.now().isoformat()
                entry["promotion_reason"] = "accelerated"
                promoted += 1

    if promoted > 0:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "promoted": promoted,
    }

    ACCEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(ACCEL_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Accelerate Promotion: {promoted} entries promoted ===")


if __name__ == "__main__":
    main()
