#!/usr/bin/env python3
"""
KB Self-Model — builds a complete self-portrait of the entire KB system.
Scans scripts/, cron/, skills/, state/, profiles/ and writes a JSON catalog to
/root/.hermes/state/kb_self_model.json.

Run manually or schedule daily via cron.
"""

import json
import os
import subprocess
import re
import datetime
import ast
from pathlib import Path

# ── paths ────────────────────────────────────────────────────────────────────
HERMES_ROOT = Path("/root/.hermes")
SCRIPTS_DIR = HERMES_ROOT / "scripts"
STATE_DIR   = HERMES_ROOT / "state"
CRON_DIR    = HERMES_ROOT / "cron"
SKILLS_DIR  = HERMES_ROOT / "skills"
PROFILES_DIR = HERMES_ROOT / "profiles"
OUTPUT_FILE = STATE_DIR / "kb_self_model.json"

# ── helpers ───────────────────────────────────────────────────────────────────

def log(msg: str):
    ts = datetime.datetime.now().isoformat()
    print(f"[{ts}] kb_self_model: {msg}")


def read_json(path: Path, default=None):
    try:
        with open(path) as fh:
            return json.load(fh)
    except Exception:
        return default if default is not None else {}


def get_file_stamp(path: Path) -> str | None:
    try:
        return datetime.datetime.fromtimestamp(path.stat().st_mtime).isoformat()
    except Exception:
        return None


def extract_py_docstring(path: Path) -> str:
    """Pull the module-level docstring from a .py file."""
    try:
        with open(path, encoding="utf-8") as fh:
            src = fh.read(4096)          # only need the top of the file
        tree = ast.parse(src)
        doc = ast.get_docstring(tree)
        return (doc or "").strip()
    except Exception:
        return ""


def extract_sh_description(path: Path) -> str:
    """Pull the first block comment from a .sh file."""
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.readlines()
        # collect leading contiguous comment lines
        parts = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("#"):
                parts.append(stripped.lstrip("#").strip())
            elif parts:
                break            # past the comment block
            else:
                break
        return " ".join(parts).strip()
    except Exception:
        return ""


# ── scanner: scripts/ ─────────────────────────────────────────────────────────

def scan_scripts() -> dict:
    scripts = {}
    for p in sorted(SCRIPTS_DIR.iterdir()):
        if p.name.startswith("_") or p.name.startswith("."):
            continue
        if p.suffix not in (".py", ".sh"):
            continue
        rel = p.relative_to(HERMES_ROOT)
        if p.suffix == ".py":
            desc   = extract_py_docstring(p)
            size   = p.stat().st_size
            stamp  = get_file_stamp(p)
            # try to detect cron-like behaviour from code
            cron_like = bool(
                re.search(r"cron|schedule|jobs\.json|ticker|heartbeat", desc + open(p).read(8192), re.I)
            )
            scripts[str(rel)] = {
                "type":        "python",
                "path":        str(p),
                "description": desc[:300],
                "size_bytes":  size,
                "modified":    stamp,
                "likely_cron": cron_like,
            }
        else:
            desc   = extract_sh_description(p)
            size   = p.stat().st_size
            stamp  = get_file_stamp(p)
            scripts[str(rel)] = {
                "type":        "shell",
                "path":        str(p),
                "description": desc[:300],
                "size_bytes":  size,
                "modified":    stamp,
                "likely_cron": False,
            }
    return scripts


# ── scanner: cron/jobs.json ───────────────────────────────────────────────────

def scan_crons() -> dict:
    jobs = read_json(CRON_DIR / "jobs.json", {"jobs": []})
    parsed = {}
    for j in jobs.get("jobs", []):
        jid = j.get("id", "?")
        parsed[jid] = {
            "name":            j.get("name", ""),
            "schedule":        j.get("schedule", {}).get("display", "?"),
            "schedule_kind":   j.get("schedule", {}).get("kind", "?"),
            "enabled":         j.get("enabled", False),
            "state":           j.get("state", ""),
            "last_run":        j.get("last_run_at"),
            "last_status":     j.get("last_status", ""),
            "last_error":      j.get("last_error"),
            "next_run":        j.get("next_run_at"),
            "repeat_completed":j.get("repeat", {}).get("completed", 0),
            "script":          j.get("script"),
            "model":           j.get("model"),
            "origin":          j.get("deliver", "?"),
        }
    return parsed


# ── scanner: mechanism registry ─────────────────────────────────────────────

def scan_mechanisms() -> dict:
    return read_json(STATE_DIR / "mechanism_registry.json", {})


# ── scanner: state/*.json files ─────────────────────────────────────────────

def scan_state_files() -> dict:
    result = {}
    for p in sorted(STATE_DIR.glob("kb_*.json")):
        if p.name == "kb_self_model.json":
            continue
        key = p.stem
        d   = read_json(p, {})
        entry_count = None
        # some state files have a top-level "entries" or "count" field
        if isinstance(d, dict):
            entry_count = d.get("count") or d.get("total") or d.get("entry_count")
            # walk nested
            if entry_count is None:
                for v in d.values():
                    if isinstance(v, dict) and ("count" in v or "total" in v):
                        entry_count = v.get("count") or v.get("total")
                        break
        result[key] = {
            "size_bytes": p.stat().st_size,
            "modified":   get_file_stamp(p),
            "top_keys":   list(d.keys())[:10] if isinstance(d, dict) else type(d).__name__,
            "entry_count": entry_count,
        }
    return result


# ── scanner: skills/ ──────────────────────────────────────────────────────────

def scan_skills() -> dict:
    result = {}
    if not SKILLS_DIR.exists():
        return result
    for cat_dir in sorted(SKILLS_DIR.iterdir()):
        if cat_dir.name.startswith("."):
            continue
        if not cat_dir.is_dir():
            continue
        skill_md = cat_dir / "SKILL.md"
        if skill_md.exists():
            try:
                text = skill_md.read_text(encoding="utf-8")
                # grab title from first H1
                title_match = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
                title = title_match.group(1).strip() if title_match else ""
                # grab description from YAML frontmatter description field
                desc_match  = re.search(r'^\s*description:\s*(.+)$', text, re.MULTILINE)
                description = desc_match.group(1).strip() if desc_match else ""
                result[cat_dir.name] = {
                    "category":  cat_dir.name,
                    "path":      str(skill_md),
                    "title":     title,
                    "description": description,
                    "modified":  get_file_stamp(skill_md),
                }
            except Exception:
                result[cat_dir.name] = {"category": cat_dir.name, "path": str(skill_md)}
        else:
            # subdirectory with files
            result[cat_dir.name] = {
                "category": cat_dir.name,
                "path":     str(cat_dir),
                "files":    [f.name for f in sorted(cat_dir.iterdir()) if not f.name.startswith(".")],
            }
    return result


# ── scanner: profiles/ ───────────────────────────────────────────────────────

def scan_profiles() -> dict:
    result = {}
    if not PROFILES_DIR.exists():
        return result
    for p in sorted(PROFILES_DIR.iterdir()):
        if p.name.startswith("."):
            continue
        if not p.is_dir():
            continue
        result[p.name] = {
            "path":           str(p),
            "subdirs":        [d.name for d in sorted(p.iterdir()) if d.is_dir() and not d.name.startswith(".")],
            "modified":       get_file_stamp(p),
        }
    return result


# ── scanner: evolution ops ────────────────────────────────────────────────────

def scan_evolution() -> dict:
    evo_state = read_json(STATE_DIR / "kb_healer_state.json", {})
    evo_ops   = read_json(STATE_DIR / "kb_self_viz.json", {})
    # count entries in the evolution engine log
    evo_log = HERMES_ROOT / "evolutionary-search.log"
    evo_log_lines = 0
    if evo_log.exists():
        try:
            evo_log_lines = len(evo_log.read_text().splitlines())
        except Exception:
            pass
    return {
        "healer_state_keys":   list(evo_state.keys())[:10],
        "self_viz_keys":       list(evo_ops.keys())[:10],
        "evolution_log_lines": evo_log_lines,
    }


# ── scanner: system info ─────────────────────────────────────────────────────

def scan_system() -> dict:
    info = {
        "hermes_root":    str(HERMES_ROOT),
        "disk_usage_mb":  None,
        "state_db_size_mb": None,
        "profiles":       list(scan_profiles().keys()),
        "total_scripts":  0,
        "total_state_files": 0,
        "total_cron_jobs": 0,
        "total_skills":   0,
    }
    try:
        du = subprocess.run(
            ["du", "-sm", str(HERMES_ROOT)], capture_output=True, text=True, timeout=30
        )
        info["disk_usage_mb"] = int(du.stdout.split()[0]) if du.returncode == 0 else None
    except Exception:
        pass
    db = HERMES_ROOT / "state.db"
    if db.exists():
        info["state_db_size_mb"] = round(db.stat().st_size / 1_048_576, 1)
    # counts
    info["total_scripts"]     = len(list(SCRIPTS_DIR.iterdir()))
    info["total_state_files"] = len(list(STATE_DIR.glob("kb_*.json")))
    info["total_cron_jobs"]   = len(read_json(CRON_DIR / "jobs.json", {"jobs": []}).get("jobs", []))
    info["total_skills"]     = len(scan_skills())
    return info


# ── scanner: health / uptime ─────────────────────────────────────────────────

def scan_health() -> dict:
    awareness = read_json(STATE_DIR / "kb_self_awareness.json", {})
    health    = read_json(STATE_DIR / "kb_health_monitor.json", {})
    return {
        "services":    awareness.get("services", {}),
        "last_scan":   awareness.get("last_scan"),
        "health_keys": list(health.keys())[:10],
    }


# ── main ─────────────────────────────────────────────────────────────────────

def build_model() -> dict:
    log("Scanning scripts …")
    scripts = scan_scripts()

    log("Scanning cron jobs …")
    crons = scan_crons()

    log("Scanning mechanisms …")
    mechanisms = scan_mechanisms()

    log("Scanning state files …")
    state_files = scan_state_files()

    log("Scanning skills …")
    skills = scan_skills()

    log("Scanning profiles …")
    profiles = scan_profiles()

    log("Scanning evolution state …")
    evolution = scan_evolution()

    log("Scanning system info …")
    system = scan_system()

    log("Scanning health …")
    health = scan_health()

    model = {
        "generated_at":        datetime.datetime.now().isoformat(),
        "hermes_version":      "unknown",
        "system":              system,
        "scripts":             scripts,
        "cron_jobs":           crons,
        "mechanisms":          mechanisms,
        "state_files":         state_files,
        "skills":              skills,
        "profiles":            profiles,
        "evolution":           evolution,
        "health":              health,
    }

    # version from config.yaml if present
    cfg = read_json(HERMES_ROOT / "config.yaml")
    if cfg:
        model["hermes_version"] = cfg.get("version", "unknown")

    return model


def main():
    log("=== Building KB self-model ===")
    model = build_model()

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, "w") as fh:
        json.dump(model, fh, indent=2)

    sz = OUTPUT_FILE.stat().st_size
    log(f"=== Done → {OUTPUT_FILE} ({sz} bytes), "
        f"{model['system']['total_scripts']} scripts, "
        f"{model['system']['total_cron_jobs']} cron jobs, "
        f"{model['system']['total_skills']} skills ===")

    # quick sanity print
    print(json.dumps(model, indent=2)[:3000])


if __name__ == "__main__":
    main()
