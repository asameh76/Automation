#!/usr/bin/env python3
"""
KB Self-Replication — fully automatic backup to GitHub + R2.
Backs up KB, scripts, and state to GitHub (gists + repo commits) and R2.
"""
import json, subprocess, sys, os, hashlib, tempfile
from datetime import datetime
from pathlib import Path

HERMES_KEYS = Path("/root/.hermes-keys/.env")
BACKUP_DIR  = Path("/root/.hermes/backups")
GIST_TOKEN_FILE = Path("/root/.hermes/.gist_token")
KB_FILE    = Path("/root/.hermes/error-knowledge-base.json")
SCRIPTS_DIR = Path("/root/.hermes/scripts")
STATE_FILE  = Path("/root/.hermes/state/kb_self_model.json")

REPOS = [
    "asameh76/Automation",
    "asameh76/Gersy-Hermes",
]

# ── credential sourcing ────────────────────────────────────────────────────────

def _source_env():
    """Load variables from /root/.hermes-keys/.env into os.environ."""
    if not HERMES_KEYS.exists():
        return
    for line in HERMES_KEYS.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip().strip('"'))


def get_github_token():
    _source_env()
    # 1. explicit env var
    t = os.environ.get("GITHUB_TOKEN", "")
    if t:
        return t
    # 2. gist token file
    if GIST_TOKEN_FILE.exists():
        return GIST_TOKEN_FILE.read_text().strip()
    return ""


def get_r2_conf():
    _source_env()
    return {
        "endpoint":   os.environ.get("R2_ENDPOINT",   ""),
        "access_key": os.environ.get("CF_ACCESS_KEY_ID", ""),
        "secret_key": os.environ.get("CF_SECRET_ACCESS_KEY", ""),
        "bucket":     os.environ.get("CF_BUCKET", ""),
        "account_id": os.environ.get("CLOUDFLARE_ACCOUNT_ID", ""),
    }


# ── R2 backup via AWS CLI ──────────────────────────────────────────────────────

def r2_backup(local_path: Path, r2_key: str) -> tuple[str, str]:
    conf = get_r2_conf()
    if not conf["access_key"] or not conf["secret_key"] or not conf["bucket"]:
        return "", "r2_credentials_missing"

    # R2 endpoint (S3-compatible)
    endpoint = conf["endpoint"]
    if not endpoint and conf["account_id"]:
        endpoint = f"https://{conf['account_id']}.r2.cloudflarestorage.com"

    # Write a mini credentials file (narrow scope)
    cred_file = BACKUP_DIR / ".r2creds"
    cred_file.parent.mkdir(parents=True, exist_ok=True)
    cred_file.write_text(
        f"[default]\naws_access_key_id={conf['access_key']}\n"
        f"aws_secret_access_key={conf['secret_key']}\n"
    )
    try:
        result = subprocess.run(
            [
                "aws", "s3", "cp", str(local_path),
                f"s3://{conf['bucket']}/{r2_key}",
                "--endpoint-url", endpoint,
                "--profile", "default",
                "--no-verify-ssl",   # CF R2 uses custom cert
            ],
            capture_output=True, text=True, timeout=60,
            env={**os.environ, "AWS_SHARED_CREDENTIALS_FILE": str(cred_file)},
        )
        if result.returncode == 0:
            url = f"https://{conf['bucket']}.{conf['account_id']}.r2.dev/{r2_key}"
            return url, "ok"
        return "", result.stderr[:120]
    except FileNotFoundError:
        return "", "aws_cli_not_found"
    finally:
        cred_file.unlink(missing_ok=True)


# ── GitHub Gist backup ────────────────────────────────────────────────────────

def gist_backup(content: str, filename: str, description: str):
    token = get_github_token()
    if not token:
        return None, "no_token"

    import urllib.request
    data = json.dumps({
        "description": description,
        "public": False,
        "files": {filename: {"content": content}},
    }).encode()

    req = urllib.request.Request(
        "https://api.github.com/gists",
        data=data,
        headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "hermes-kb",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
            return result.get("html_url", ""), "ok"
    except Exception as e:
        return None, str(e)[:80]


# ── GitHub repo commit backup ──────────────────────────────────────────────────

def git_repo_backup(repo: str, content: str, filename: str, message: str) -> tuple[str, str]:
    """
    Create/update a single file in a GitHub repo via the Contents API.
    Returns (html_url, status).
    """
    token = get_github_token()
    if not token:
        return "", "no_token"

    import urllib.request

    # Detect default branch
    api_base = f"https://api.github.com/repos/{repo}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "hermes-kb",
    }

    try:
        # Get branch / default branch
        req = urllib.request.Request(f"{api_base}", headers=headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            repo_info = json.loads(resp.read())
        branch = repo_info.get("default_branch", "main")
        branch_url = f"{api_base}/branches/{branch}"

        # Get current commit SHA
        req = urllib.request.Request(branch_url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            branch_data = json.loads(resp.read())
        commit_sha = branch_data["commit"]["sha"]
        tree_sha   = branch_data["commit"]["commit"]["tree"]["sha"]
    except Exception as e:
        return "", f"repo_fetch:{str(e)[:40]}"

    # Encode content base64 (works for both text and binary)
    import base64
    encoded = base64.b64encode(content.encode("latin-1")).decode()

    # Create blob
    blob_data = json.dumps({"content": encoded, "encoding": "base64"}).encode()
    req = urllib.request.Request(
        f"{api_base}/git/blobs",
        data=blob_data,
        headers={**headers, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            blob = json.loads(resp.read())
        blob_sha = blob["sha"]
    except Exception as e:
        return "", f"blob_create:{str(e)[:40]}"

    # Create new tree
    tree_data = json.dumps({
        "base_tree": tree_sha,
        "tree": [{
            "path": filename,
            "mode": "100644",
            "type": "blob",
            "sha": blob_sha,
        }],
    }).encode()
    req = urllib.request.Request(
        f"{api_base}/git/trees",
        data=tree_data,
        headers={**headers, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            tree = json.loads(resp.read())
        new_tree_sha = tree["sha"]
    except Exception as e:
        return "", f"tree_create:{str(e)[:40]}"

    # Create commit
    commit_data = json.dumps({
        "message": message,
        "tree": new_tree_sha,
        "parents": [commit_sha],
    }).encode()
    req = urllib.request.Request(
        f"{api_base}/git/commits",
        data=commit_data,
        headers={**headers, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            commit = json.loads(resp.read())
        new_commit_sha = commit["sha"]
    except Exception as e:
        return "", f"commit_create:{str(e)[:40]}"

    # Update reference
    ref_data = json.dumps({"sha": new_commit_sha}).encode()
    req = urllib.request.Request(
        f"{api_base}/git/refs/heads/{branch}",
        data=ref_data,
        headers={**headers, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            json.loads(resp.read())
    except Exception as e:
        return "", f"ref_update:{str(e)[:40]}"

    html_url = f"https://github.com/{repo}/blob/{branch}/{filename}"
    return html_url, "ok"


# ── Scripts folder backup (full disaster recovery) ──────────────────────────

SCRIPTS_EXCLUDE = {
    "__pycache__", ".pytest_cache", "node_modules",
    "venv", ".venv", "env/", ".env/",
}


def _scripts_tarball(timestamp: str) -> tuple[Path, str]:
    """Create a tarball of scripts/ and return (path, hash)."""
    import tarfile, io
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for root, dirs, files in os.walk(SCRIPTS_DIR):
            # Prune excluded dirs in-place
            dirs[:] = [d for d in dirs if d not in SCRIPTS_EXCLUDE]
            for file in files:
                fp = Path(root) / file
                tar.add(fp, arcname=str(fp.relative_to(SCRIPTS_DIR.parent)))
    buf.seek(0)
    content = buf.read()
    h = hashlib.md5(content).hexdigest()
    path = BACKUP_DIR / f"scripts_backup_{timestamp}.tar.gz"
    path.write_bytes(content)
    return path, h


def scripts_backup(timestamp: str) -> dict:
    """Backup scripts/ to R2 + GitHub repos. Returns results dict."""
    tar_path, tar_hash = _scripts_tarball(timestamp)
    print(f"[REPLICATE] Scripts: {tar_path} ({tar_path.stat().st_size // 1024}KB)")
    results = {}

    # R2
    r2_key = f"scripts_backups/scripts_backup_{timestamp}.tar.gz"
    r2_url, r2_status = r2_backup(tar_path, r2_key)
    if r2_url:
        print(f"[REPLICATE] Scripts R2: {r2_url}")
        results["r2"] = r2_url
    else:
        print(f"[REPLICATE] Scripts R2 failed: {r2_status}")

    # GitHub repos
    token = get_github_token()
    if token:
        tar_content = tar_path.read_bytes()
        for repo in REPOS:
            filename = f"scripts_backups/scripts_backup_{timestamp}.tar.gz"
            repo_url, repo_status = git_repo_backup(
                repo, tar_content.decode("latin-1"), filename,
                f"Scripts backup {timestamp} [automated]",
            )
            if repo_url:
                print(f"[REPLICATE] Scripts {repo}: {repo_url}")
                results[f"github:{repo}"] = repo_url
            else:
                print(f"[REPLICATE] Scripts {repo} failed: {repo_status}")
    return results


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    _source_env()

    if not KB_FILE.exists():
        print("[REPLICATE] KB file missing, skipping.")
        return

    kb_content = KB_FILE.read_text()
    kb_hash    = hashlib.md5(kb_content.encode()).hexdigest()

    # Skip if unchanged
    state_file = BACKUP_DIR / "replication_state.json"
    if state_file.exists():
        state = json.loads(state_file.read_text())
        if state.get("last_kb_hash") == kb_hash:
            print("[REPLICATE] No changes since last backup, skipping.")
            return

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    # ── local backup ──────────────────────────────────────────────────────────
    backup_file = BACKUP_DIR / f"kb_backup_{timestamp}.json"
    backup_file.write_text(kb_content)
    print(f"[REPLICATE] Local: {backup_file}")

    results = {}

    # ── R2 backup ─────────────────────────────────────────────────────────────
    r2_key = f"kb_backups/kb_backup_{timestamp}.json"
    r2_url, r2_status = r2_backup(backup_file, r2_key)
    if r2_url:
        print(f"[REPLICATE] R2: {r2_url}")
        results["r2"] = r2_url
    else:
        print(f"[REPLICATE] R2 failed: {r2_status}")

    # ── Gist backup ───────────────────────────────────────────────────────────
    gist_url, gist_status = gist_backup(
        kb_content,
        f"kb_backup_{timestamp}.json",
        f"Hermes KB backup {timestamp}",
    )
    if gist_url:
        print(f"[REPLICATE] Gist: {gist_url}")
        results["gist"] = gist_url
    else:
        print(f"[REPLICATE] Gist failed: {gist_status}")

    # ── GitHub repo backup (one file per repo) ─────────────────────────────────
    token = get_github_token()
    if token:
        for repo in REPOS:
            filename = f"kb_backups/kb_backup_{timestamp}.json"
            repo_url, repo_status = git_repo_backup(
                repo, kb_content, filename,
                f"KB backup {timestamp} [automated]",
            )
            if repo_url:
                print(f"[REPLICATE] {repo}: {repo_url}")
                results[f"github:{repo}"] = repo_url
            else:
                print(f"[REPLICATE] {repo} failed: {repo_status}")
    else:
        print("[REPLICATE] GitHub token missing, skipping repo push.")

    # ── update state ──────────────────────────────────────────────────────────
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(json.dumps({
        "last_backup":   timestamp,
        "last_kb_hash": kb_hash,
        "backup_file":  str(backup_file),
        "results":      results,
    }, indent=2))

    # ── scripts backup (always runs — full disaster recovery) ─────────────────
    scripts_results = scripts_backup(timestamp)
    if scripts_results:
        results["scripts"] = scripts_results

    print(f"[REPLICATE] Done: {timestamp}")


if __name__ == "__main__":
    main()
