#!/usr/bin/env python3
"""
KB Capture Fix - KB Auto-Capture.
Watches errors.log and session.log for manual fixes.
"""

import json
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
ERRORS_LOG = Path("/root/.hermes/logs/errors.log")
SESSION_LOG = Path("/root/.hermes/logs/session.log")
CAPTURE_FILE = Path("/root/.hermes/state/kb_capture.json")
LOG_FILE = Path("/root/.hermes/logs/kb_capture_fix.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def read_log(path):
    if not path.exists():
        return []
    try:
        with open(path) as fh:
            return fh.readlines()
    except Exception:
        return []


def detect_manual_fixes(lines):
    """Detect manual fixes from log lines."""
    fixes = []
    fix_markers = [
        "[FIX]",
        "[MANUAL_FIX]",
        "[RESOLVED]",
        "applied fix",
        "manually fixed",
    ]
    for i, line in enumerate(lines):
        lower = line.lower()
        for marker in fix_markers:
            if marker.lower() in lower:
                # Extract the error context (5 lines before)
                start = max(0, i - 5)
                context = "".join(lines[start : i + 1])
                fixes.append({
                    "marker": marker,
                    "context": context,
                    "line": i,
                    "timestamp": datetime.datetime.now().isoformat(),
                })
                break
    return fixes


def main():
    log("=== KB Capture Fix started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    error_lines = read_log(ERRORS_LOG)
    session_lines = read_log(SESSION_LOG)

    error_fixes = detect_manual_fixes(error_lines)
    session_fixes = detect_manual_fixes(session_lines)

    all_fixes = error_fixes + session_fixes

    new_captures = 0
    for fix_data in all_fixes:
        new_entry = {
            "error": fix_data["context"][:200],
            "status": "investigate",
            "fixes": [
                {
                    "description": "Manual fix detected",
                    "applied": True,
                    "applied_at": fix_data["timestamp"],
                    "evidence": fix_data["context"][:500],
                }
            ],
            "created_at": fix_data["timestamp"],
            "source": "auto_capture",
        }
        kb["knowledge_base"].append(new_entry)
        new_captures += 1

    if new_captures > 0:
        write_kb(kb)
        log(f"Captured {new_captures} manual fixes")

    capture_state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "error_fixes": len(error_fixes),
        "session_fixes": len(session_fixes),
        "new_captures": new_captures,
    }

    CAPTURE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CAPTURE_FILE, "w") as fh:
        json.dump(capture_state, fh, indent=2)

    log(f"=== KB Capture Fix: {new_captures} captures ===")


if __name__ == "__main__":
    main()
