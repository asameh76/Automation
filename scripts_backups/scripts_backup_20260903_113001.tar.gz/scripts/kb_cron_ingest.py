#!/usr/bin/env python3
"""
KB Cron Ingest - Ingest from crontab into KB.
"""

import json
import subprocess
import datetime
import fcntl
from pathlib import Path


KB_FILE = Path("/root/.hermes/error-knowledge-base.json")
CRON_STATE_FILE = Path("/root/.hermes/state/kb_cron_ingest.json")
LOG_FILE = Path("/root/.hermes/logs/kb_cron_ingest.log")


def log(msg):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


def read_kb():
    with open(KB_FILE, "r") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_SH)
        try:
            return json.load(fh)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def write_kb(kb):
    with open(KB_FILE, "w") as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            json.dump(kb, fh, indent=2)
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def get_crontab():
    """Get current crontab entries."""
    try:
        result = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout
    except Exception:
        pass
    return ""


def main():
    log("=== KB Cron Ingest started ===")

    try:
        kb = read_kb()
    except Exception as e:
        log(f"ERROR: Could not read KB: {e}")
        return

    crontab = get_crontab()
    if not crontab:
        log("No crontab entries found")
        return

    lines = [l.strip() for l in crontab.split("\n") if l.strip() and not l.startswith("#")]

    new_entries = 0
    for line in lines:
        entry = {
            "error": f"Cron job issue: {line[:100]}",
            "status": "investigate",
            "fixes": [],
            "tags": ["cron", "scheduled"],
            "created_at": datetime.datetime.now().isoformat(),
            "source": "cron_ingest",
        }
        kb["knowledge_base"].append(entry)
        new_entries += 1

    if new_entries > 0:
        write_kb(kb)

    state = {
        "timestamp": datetime.datetime.now().isoformat(),
        "crontab_lines": len(lines),
        "new_entries": new_entries,
    }

    CRON_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CRON_STATE_FILE, "w") as fh:
        json.dump(state, fh, indent=2)

    log(f"=== KB Cron Ingest: {new_entries} entries added ===")


if __name__ == "__main__":
    main()
