#!/usr/bin/env python3
"""
KB Auto-Research — systemd-triggered research on new/unresolved KB errors.
Watches /root/.hermes/error-knowledge-base.json for errors that have no
research results and fires kb_web_research.py for each one.
"""
import json, sys, subprocess, os
from datetime import datetime

KB_PATH = "/root/.hermes/error-knowledge-base.json"
STATE_FILE = "/root/.hermes/state/kb_auto_research.state"
LOCK_FILE = "/root/.hermes/state/kb_auto_research.lock"
RESEARCH_SCRIPT = "/root/.hermes/scripts/kb_web_research.py"

RESOLVED_STATES = {"verified", "self_healed", "false_positive"}


def read_kb():
    with open(KB_PATH) as f:
        return json.load(f)


def read_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return set(json.load(f).get("researched_ids", []))
    return set()


def write_state(ids):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump({"researched_ids": list(ids), "last_run": datetime.now().isoformat()}, f, indent=2)


def acquire_lock():
    os.makedirs(os.path.dirname(LOCK_FILE), exist_ok=True)
    try:
        with open(LOCK_FILE, "x") as f:
            f.write(str(os.getpid()))
        return True
    except FileExistsError:
        return False


def release_lock():
    try:
        os.unlink(LOCK_FILE)
    except FileNotFoundError:
        pass


def main():
    if not acquire_lock():
        print("Already running, skipping.")
        return

    try:
        kb = read_kb()
        state = read_state()

        errors = kb.get("errors", [])
        errors.extend(kb.get("knowledge_base", []))
        if not errors:
            return

        researched = set(state)
        new_count = 0

        for entry in errors:
            eid = entry.get("id") or entry.get("signature", "")
            msg = entry.get("error_message") or entry.get("error", "")
            status = entry.get("status", "")
            source = entry.get("source", "")

            if not msg or eid in researched:
                continue
            if status in RESOLVED_STATES:
                continue
            if "researched" in source.lower():
                continue

            # Build query — prefer short error message or signature
            query = entry.get("error_message", "")[:120].strip()
            if not query:
                query = entry.get("signature", "")[:120].strip()
            if not query:
                continue

            print(f"Researching [{eid[:30]}]: {query[:60]}")

            result = subprocess.run(
                [sys.executable, RESEARCH_SCRIPT, query, "--add-kb"],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode == 0:
                researched.add(eid)
                new_count += 1
                print(f"  ✓ Done")
            else:
                print(f"  ✗ Failed: {result.stderr[:100]}")

        write_state(researched)
        print(f"Auto-research complete: {new_count} new entries researched")

    finally:
        release_lock()


if __name__ == "__main__":
    main()
