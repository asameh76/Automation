#!/usr/bin/env python3
"""
KB Survival Capsule — builds + rotates + delivers the full identity capsule.
Called at the END of every kb_combined.py run so the capsule is always fresh.
Stores: .env, memory/, config.yaml, profiles/, cron/, skills/, KB, recovery plan.
"""
import os
import json
import hashlib
import subprocess
import datetime
import zipfile
import tarfile
import tempfile
import shutil
from pathlib import Path

# ── paths ───────────────────────────────────────────────────────────────────────
HERMES_KEYS   = Path("/root/.hermes-keys/.env")
HERMES_DIR    = Path("/root/.hermes")
CAPSULE_DIR   = Path("/root")          # /root/survival-capsule.*
BACKUP_DIR    = HERMES_DIR / "backups"
LOG_FILE      = HERMES_DIR / "logs" / "survival-capsule.log"
R2_REMOTE     = "cloudflare_hermes"
R2_BUCKET     = "gem-gyms76/backups/survival-capsule"

SOURCES = [
    (HERMES_KEYS,          "hermes-keys/.env"),
    (HERMES_DIR / "SOUL.md",               "hermes/SOUL.md"),
    (HERMES_DIR / "config.yaml",           "hermes/config.yaml"),
    (HERMES_DIR / "error-knowledge-base.json", "hermes/error-knowledge-base.json"),
    (HERMES_DIR / "event-bus.jsonl",       "hermes/event-bus.jsonl"),
    (Path("/root/recovery-plan.md"),       "recovery-plan.md"),
    (Path("/root/daily-article.py"),       "daily-article.py"),
]

PROFILES_SRC  = HERMES_DIR / "profiles"
CRON_SRC      = HERMES_DIR / "cron"
SKILLS_SRC    = HERMES_DIR / "skills"
SYSTEMD_SRC   = Path("/root/.config/systemd/user")

SCRIPTS_LIST  = [
    "anomaly-daemon.py",
    "evolution-engine.py",
    "system-health-check.py",
    "kanban-ideas.py",
    "survival-capsule-rotate.sh",
    "restore-capsule.sh",
    "kb_self_replicate.py",
    "kb_combined.py",
    "kb_self_heal.py",
    "kb_self_certify.py",
    "kb_feedback_loop.py",
    "kb_prune.py",
    "kb_predictor.py",
    "kb_verify_engine.py",
    "kb_self_edit.py",
    "kb_capture_fix.py",
    "kb_self_evaluate.py",
]

# ── logging ─────────────────────────────────────────────────────────────────────
def log(msg: str):
    ts = datetime.datetime.now().isoformat()
    line = f"[{ts}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as fh:
        fh.write(line + "\n")


# ── env sourcing ────────────────────────────────────────────────────────────────
def source_env():
    if not HERMES_KEYS.exists():
        return {}
    env = {}
    for line in HERMES_KEYS.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        env[k.strip()] = v.strip().strip('"')
    return env


# ── core: build capsule contents in tmp dir ─────────────────────────────────────
def build_capsule_src(tmpdir: Path) -> Path:
    src = tmpdir / "capsule_contents"
    src.mkdir(parents=True)

    # Plain files
    for src_path, dst_rel in SOURCES:
        if src_path.exists():
            dst = src / dst_rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dst)

    # hermes/memory/
    mem_src = HERMES_DIR / "memory"
    if mem_src.exists() and mem_src.is_dir():
        mem_dst = src / "hermes" / "memory"
        shutil.copytree(mem_src, mem_dst, dirs_exist_ok=True)

    # hermes/profiles/default/
    prof_src = PROFILES_SRC / "default"
    if prof_src.exists():
        prof_dst = src / "hermes" / "profiles" / "default"
        shutil.copytree(prof_src, prof_dst, dirs_exist_ok=True)

    # hermes/scripts/ (allowlisted)
    scripts_dst = src / "hermes" / "scripts"
    scripts_dst.mkdir(parents=True)
    for name in SCRIPTS_LIST:
        fp = HERMES_DIR / "scripts" / name
        if fp.exists():
            shutil.copy2(fp, scripts_dst / name)

    # hermes/cron/ (strip outputs — only keep structure)
    if CRON_SRC.exists():
        cron_dst = src / "hermes" / "cron"
        shutil.copytree(CRON_SRC, cron_dst, dirs_exist_ok=True)
        # Remove heavy cron outputs
        for root, _dirs, files in os.walk(cron_dst):
            for f in files:
                if f.endswith((".md", ".jsonl")):
                    (Path(root) / f).unlink(missing_ok=True)

    # hermes/skills/
    if SKILLS_SRC.exists():
        skills_dst = src / "hermes" / "skills"
        shutil.copytree(SKILLS_SRC, skills_dst, dirs_exist_ok=True)

    # systemd units
    if SYSTEMD_SRC.exists():
        sysd_dst = src / "systemd" / "user"
        sysd_dst.mkdir(parents=True)
        for f in SYSTEMD_SRC.glob("*.service"):
            shutil.copy2(f, sysd_dst / f.name)

    return src


# ── archive helpers ─────────────────────────────────────────────────────────────
def make_zip(src_dir: Path, out_path: Path):
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                fp = Path(root) / file
                zf.write(fp, fp.relative_to(src_dir.parent))
    return out_path.stat().st_size


def make_tar(src_dir: Path, out_path: Path):
    with tarfile.open(out_path, "w:gz") as tf:
        tf.add(src_dir, arcname="capsule_contents")
    return out_path.stat().st_size


# ── rotate existing capsules ────────────────────────────────────────────────────
def rotate(capsule_base: str):
    for ext in (".tar.gz", ".zip"):
        for i in [2, 1]:
            prev = CAPSULE_DIR / f"{capsule_base}.{i}{ext}"
            nxt  = CAPSULE_DIR / f"{capsule_base}.{i+1}{ext}"
            if prev.exists():
                shutil.move(str(prev), str(nxt))
        cur = CAPSULE_DIR / f"{capsule_base}{ext}"
        nxt = CAPSULE_DIR / f"{capsule_base}.1{ext}"
        if cur.exists():
            shutil.move(str(cur), str(nxt))


# ── rclone upload ───────────────────────────────────────────────────────────────
def rclone_upload(local_path: Path, r2_key: str) -> bool:
    env = source_env()
    if not env.get("CLOUDFLARE_ACCOUNT_ID"):
        log("R2: no credentials, skipping upload")
        return False
    try:
        result = subprocess.run(
            ["rclone", "copy", str(local_path),
             f"{R2_REMOTE}:{R2_BUCKET}/", "--quiet"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            log(f"R2 upload OK: {local_path.name}")
            return True
        else:
            log(f"R2 upload FAIL: {result.stderr[:100]}")
            return False
    except FileNotFoundError:
        log("rclone not found")
        return False
    except Exception as e:
        log(f"R2 upload ERROR: {e}")
        return False


# ── Telegram delivery (direct Bot API) ─────────────────────────────────────────
def telegram_send_document(filepath: Path, caption: str, chat_id: str = "864983959") -> bool:
    """
    Send a document directly via Telegram Bot API (no hermes CLI needed).
    Uses the bot token from HERMES_KEYS.
    """
    env = source_env()
    token = env.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        log("Telegram: no bot token, skipping delivery")
        return False

    import urllib.request
    import urllib.parse

    url = f"https://api.telegram.org/bot{token}/sendDocument"

    boundary = "----FormBoundary7MA4YWxkTrZu0gW"
    body_parts = []

    # chat_id
    body_parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}")
    # caption
    body_parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n{caption}")
    # document
    with open(filepath, "rb") as f:
        file_data = f.read()
    import base64
    encoded = base64.b64encode(file_data).decode()
    body_parts.append(
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; "
        f'filename="{filepath.name}"\r\nContent-Type: application/octet-stream\r\n\r\n'
        f"{file_data.decode('latin-1')}"
    )
    body_parts.append(f"--{boundary}--")

    body = "\r\n".join(body_parts).encode("latin-1")

    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Authorization": f"Bot {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read())
            if result.get("ok"):
                log(f"Telegram delivery OK: {filepath.name}")
                return True
            else:
                log(f"Telegram delivery FAIL: {result.get('description')}")
                return False
    except Exception as e:
        log(f"Telegram delivery ERROR: {e}")
        return False


# ── main ───────────────────────────────────────────────────────────────────────
def main():
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log(f"KB Survival Capsule started — {ts}")

    CAPSULE_DIR.mkdir(parents=True, exist_ok=True)
    CAPSULE_BASE = "survival-capsule"

    tmpdir = None
    try:
        tmpdir = tempfile.mkdtemp(prefix="capsule_")
        tmpdir = Path(tmpdir)

        # Build
        log("Building capsule contents...")
        capsule_src = build_capsule_src(tmpdir)

        # Create archives
        zip_path = tmpdir / f"{CAPSULE_BASE}.zip"
        tar_path = tmpdir / f"{CAPSULE_BASE}.tar.gz"

        log("Creating zip...")
        zip_size = make_zip(capsule_src, zip_path)
        log(f"  zip: {zip_size // 1024} KB")

        log("Creating tar.gz...")
        tar_size = make_tar(capsule_src, tar_path)
        log(f"  tar.gz: {tar_size // 1024} KB")

        # Rotate existing
        log("Rotating existing capsules...")
        rotate(CAPSULE_BASE)

        # Move new capsules in place
        shutil.move(str(zip_path), str(CAPSULE_DIR / f"{CAPSULE_BASE}.zip"))
        shutil.move(str(tar_path), str(CAPSULE_DIR / f"{CAPSULE_BASE}.tar.gz"))

        # R2 upload (zip — for hermes import)
        latest_zip = CAPSULE_DIR / f"{CAPSULE_BASE}.zip"
        rclone_upload(latest_zip, f"{CAPSULE_BASE}.zip")

        # Telegram delivery (zip — user can download from mobile)
        caption = f"📦 KB Survival Capsule {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
        telegram_send_document(latest_zip, caption)

        log(f"KB Survival Capsule completed — {CAPSULE_DIR / f'{CAPSULE_BASE}.zip'}")

    except Exception as e:
        log(f"KB Survival Capsule ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if tmpdir and Path(tmpdir).exists():
            shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
